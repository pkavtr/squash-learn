package com.cotiviti.c2i.utils.property;

import java.util.HashMap;
import java.util.Map;

import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.boot.context.properties.EnableConfigurationProperties;
import org.springframework.stereotype.Component;

@Component
@EnableConfigurationProperties
@ConfigurationProperties(prefix="default")
public class C2iConfigProperties {
	
	Map<String, Object> properties;
	
	public Map<String, Object> getProperties() {
		
		return properties;
	}
	
	public void setProperties(HashMap<String, Object> properties) {
		
		this.properties = properties;
	}
	
	public Map<String, Object> getFormattedProperties() {
		
		Map<String, Object> prop = new HashMap<String, Object>();
		this.properties.forEach((key, value) -> prop.put(key.replace("-", "."), value));
		return prop;
	} 
}