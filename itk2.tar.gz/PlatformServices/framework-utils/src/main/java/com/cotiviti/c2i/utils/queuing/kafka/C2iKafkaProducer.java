package com.cotiviti.c2i.utils.queuing.kafka;

import java.util.HashMap;
import java.util.Map;

import org.apache.kafka.clients.producer.KafkaProducer;
import org.apache.kafka.clients.producer.Producer;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.boot.context.properties.EnableConfigurationProperties;
import org.springframework.stereotype.Component;

@Component
@EnableConfigurationProperties
@ConfigurationProperties(prefix="default")
public class C2iKafkaProducer<K, V> {
	
	Map<String, Object> properties;
	private String topicName;
	
	public C2iKafkaProducer() {
		
		//this.topicName = (String) this.properties.get("topicName");
	}
	
	public Producer<K, V> createProducer() {
		
		this.topicName = (String) this.properties.get("topicName");
        return new KafkaProducer<K, V>(this.getFormattedProperties());
    }

	public String getTopicName() {
		return topicName;
	}
	
	public Map<String, Object> getProperties() {
		
		return properties;
	}
	
	public void setProperties(HashMap<String, Object> properties) {
		
		this.properties = properties;
	}
	
	public Map<String, Object> getFormattedProperties() {
		
		Map<String, Object> prop = new HashMap<String, Object>();
		this.properties.forEach((key, value) -> prop.put(key.replace("-", "."), value));
		return prop;
	} 
}