package com.cotiviti.c2i.utils.queuing.kafka;

import java.util.Collections;
import java.util.Map;

import org.apache.kafka.clients.consumer.Consumer;
import org.apache.kafka.clients.consumer.KafkaConsumer;

public class C2iKafkaConsumer<K, V>{
    
	private Map<String, Object> properties;
	private String topicName;
	
	public C2iKafkaConsumer(Map<String, Object> props) {
		
		this.properties = props;
		this.topicName = (String) props.get("topicName");
	}
	
    public Consumer<K, V> createConsumer() {
    	
		Consumer<K, V> clientConsumer = new KafkaConsumer<K, V>(this.properties);
		clientConsumer.subscribe(Collections.singletonList(this.topicName));
		return clientConsumer;
    }

	public String getTopicName() {
		return topicName;
	}
}