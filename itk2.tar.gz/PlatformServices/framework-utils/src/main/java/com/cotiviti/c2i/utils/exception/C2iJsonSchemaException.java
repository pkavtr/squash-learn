package com.cotiviti.c2i.utils.exception;

public class C2iJsonSchemaException extends RuntimeException {

	private static final long serialVersionUID = 4344032408612615709L;

	public C2iJsonSchemaException() {
        super();
    }

    public C2iJsonSchemaException(String msg) {
        super(msg);
    }

    public C2iJsonSchemaException(String message, Throwable cause) {
        super(message, cause);
    }

    public C2iJsonSchemaException(Throwable cause) {
        super(cause);
    }
}
