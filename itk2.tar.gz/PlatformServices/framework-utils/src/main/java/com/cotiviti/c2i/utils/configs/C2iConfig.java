package com.cotiviti.c2i.utils.configs;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Map;

import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.config.BeanPostProcessor;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Import;
import org.springframework.core.Ordered;
import org.springframework.core.annotation.Order;
import org.springframework.core.io.FileSystemResource;
import org.springframework.security.config.annotation.authentication.builders.AuthenticationManagerBuilder;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.builders.WebSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.config.annotation.web.configuration.WebSecurityConfigurerAdapter;
import org.springframework.security.config.http.SessionCreationPolicy;
import org.springframework.security.core.userdetails.User;
import org.springframework.security.kerberos.authentication.KerberosAuthenticationProvider;
import org.springframework.security.kerberos.authentication.KerberosServiceAuthenticationProvider;
import org.springframework.security.kerberos.authentication.sun.SunJaasKerberosClient;
import org.springframework.security.kerberos.authentication.sun.SunJaasKerberosTicketValidator;
import org.springframework.security.kerberos.web.authentication.SpnegoAuthenticationProcessingFilter;
import org.springframework.security.kerberos.web.authentication.SpnegoEntryPoint;
import org.springframework.security.web.authentication.www.BasicAuthenticationFilter;
import org.springframework.stereotype.Component;
import org.springframework.util.Assert;

import com.cotiviti.c2i.utils.controllers.FrameworkController;
import com.cotiviti.c2i.utils.processors.C2iJsonRequestBodyArgumentResolverRegisteringBeanPostProcessor;
import com.cotiviti.c2i.utils.property.C2iConfigProperties;
import com.cotiviti.c2i.utils.services.DummyUserDetailsService;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.google.common.base.Predicates;

import lombok.extern.slf4j.Slf4j;
import springfox.documentation.builders.ParameterBuilder;
import springfox.documentation.builders.PathSelectors;
import springfox.documentation.builders.RequestHandlerSelectors;
import springfox.documentation.schema.ModelRef;
import springfox.documentation.service.Parameter;
import springfox.documentation.spi.DocumentationType;
import springfox.documentation.spring.web.plugins.Docket;
import springfox.documentation.swagger2.annotations.EnableSwagger2;

/**
 * This class sets up all the necessary plumbing for c2i web service to work
 * correctly.
 * 
 * Since we are using spring boot, the main class that starts the spring boot
 * application should extend this class and it will inject all required bean or
 * configuration into the application.
 * 
 * @author kchen
 *
 */
@Slf4j // Lombok annotation for logging
@Configuration
@EnableSwagger2
@Import(FrameworkController.class)
public class C2iConfig {

	private static Logger log = LoggerFactory.getLogger(C2iConfig.class);

	private static final String DEFAULT_SWAGGER_BASE_PACKAGE = "com.cotiviti.c2i";

	@Component
	@Order(Ordered.HIGHEST_PRECEDENCE)
	public class CorsFilter implements Filter {

		@Override
		public void doFilter(ServletRequest req, ServletResponse res, FilterChain chain)
				throws IOException, ServletException {
			final HttpServletResponse response = (HttpServletResponse) res;
			Map<String, Object> corsFilterProps = corsFilterProperties().getProperties();

                        // Iterate through the corsFilter property and set them on the response header
                        for(Map.Entry<String, Object> entry: corsFilterProps.entrySet())
                                response.setHeader("Access-Control-" + entry.getKey(), entry.getValue().toString());

			if ("OPTIONS".equalsIgnoreCase(((HttpServletRequest) req).getMethod())) {
				response.setStatus(HttpServletResponse.SC_OK);
			} else {
				chain.doFilter(req, res);
			}
		}

		@Override
		public void destroy() {
		}

		@Override
		public void init(FilterConfig config) throws ServletException {
		}
	}

	/**
	 * This bean is used to enforce the standard that not returning null element in
	 * the response. It can be set through application.yml file in custom service
	 * but we enforce it in the library level so as long as this class being
	 * imported, the application will use the standard.
	 * 
	 * @return
	 */
	@Bean
	public ObjectMapper buildObjectMapper() {
		return new ObjectMapper().setSerializationInclusion(Include.NON_NULL);
	}

	@Bean
	@ConfigurationProperties(prefix = "cors-filter")
	public C2iConfigProperties corsFilterProperties() {
		C2iConfigProperties prop = new C2iConfigProperties();
		return prop;
	}

	@Bean
	@ConfigurationProperties(prefix = "web-service")
	public C2iConfigProperties webServiceProperties() {
		C2iConfigProperties prop = new C2iConfigProperties();
		return prop;
	}

	/**
	 * This bean is used to setup the swagger UI to provide api docs for client side
	 * developers
	 * 
	 * API developers will need to specify the controller namespace in the
	 * application.yml file, under the key named webService.swaggerBasePackage, to
	 * allow swagger UI to scan through the controller to generate the api docs. All
	 * controllers should be placed in the same namespace.
	 * 
	 * @return
	 */
	@Bean
	public Docket api() {
		String swaggerBasePackage = (String) webServiceProperties().getProperties().get("swaggerBasePackage");
		if (swaggerBasePackage == null)
			swaggerBasePackage = DEFAULT_SWAGGER_BASE_PACKAGE;
		Parameter auth_parameter = new ParameterBuilder().name("authorization")
				.description("authorization header is optional for c2i request").modelRef(new ModelRef("string"))
				.parameterType("header").required(false).build();
		List<Parameter> list = new ArrayList<Parameter>();
		list.add(auth_parameter);
		return new Docket(DocumentationType.SWAGGER_2).select()
				.apis(RequestHandlerSelectors.basePackage(swaggerBasePackage))
				.apis(Predicates.not(RequestHandlerSelectors.basePackage("com.cotiviti.c2i.utils.controllers")))
				.paths(PathSelectors.any()).build().globalOperationParameters(list);
	}

	/**
	 * This is configuration class to setup kerberos authentication scheme
	 * 
	 * @author kchen
	 *
	 */
	@Configuration
	@EnableWebSecurity
	public class WebSecurityConfig extends WebSecurityConfigurerAdapter {
		private static final String DEFAULT_IGNORED_SECURITY = "/error,/v2/api-docs,/configuration/ui,/swagger-resources,/swagger-resources/**,"
				+ "/configuration/security,/swagger-ui.html,/webjars/**,/actuator/*";

		@Override
		protected void configure(HttpSecurity http) throws Exception {
			// @formatter:off
			http.exceptionHandling().authenticationEntryPoint(spnegoEntryPoint()).and().sessionManagement()
					.sessionCreationPolicy(SessionCreationPolicy.IF_REQUIRED).and().authorizeRequests()
					.antMatchers("/css/**", "/index").permitAll().anyRequest().authenticated().and().formLogin()
					.loginPage("/login").failureUrl("/login-error").and()
					.addFilterBefore(spnegoAuthenticationProcessingFilter(), BasicAuthenticationFilter.class);
			http.csrf().disable();
			// @formatter:on
		}

		@Override
		public void configure(WebSecurity web) throws Exception {
			Map<String, Object> props = webServiceProperties().getProperties();
			String defaultIgnoredSecurity = (String) props.get("default-ignored-security");
			if (defaultIgnoredSecurity == null)
				defaultIgnoredSecurity = DEFAULT_IGNORED_SECURITY;
			String sis = defaultIgnoredSecurity + "," + (String) props.get("ignored-security");
			String[] arrayWithDuplicates = sis.split(",");

			// get rid of duplicated elements in the ignored security list
			int noOfUniqueElements = arrayWithDuplicates.length;
			for (int i = 0; i < noOfUniqueElements; i++) {
				for (int j = i + 1; j < noOfUniqueElements; j++) {
					if (arrayWithDuplicates[i] == arrayWithDuplicates[j]) {
						arrayWithDuplicates[j] = arrayWithDuplicates[noOfUniqueElements - 1];
						noOfUniqueElements--;
						j--;
					}
				}
			}

			String[] arrayWithoutDuplicates = Arrays.copyOf(arrayWithDuplicates, noOfUniqueElements);

			web.ignoring().antMatchers(arrayWithoutDuplicates);
		}

		// @formatter:off
		@Autowired
		public void configureGlobal(AuthenticationManagerBuilder auth) throws Exception {
			auth.inMemoryAuthentication()
					.withUser(User.withDefaultPasswordEncoder().username("user").password("password").roles("USER"));
			auth.authenticationProvider(kerberosAuthenticationProvider())
					.authenticationProvider(kerberosServiceAuthenticationProvider());
		}
		// @formatter:on

		/**
		 * Below are all Kerberos related configuration
		 * 
		 * @return
		 */

		@Bean
		public SpnegoEntryPoint spnegoEntryPoint() {
			return new SpnegoEntryPoint("/login");
		}

		@Bean
		public KerberosAuthenticationProvider kerberosAuthenticationProvider() {
			KerberosAuthenticationProvider provider = new KerberosAuthenticationProvider();
			SunJaasKerberosClient client = new SunJaasKerberosClient();
			client.setDebug(true);
			provider.setKerberosClient(client);
			provider.setUserDetailsService(dummyUserDetailsService());
			return provider;
		}

		@Bean
		public SpnegoAuthenticationProcessingFilter spnegoAuthenticationProcessingFilter() {
			SpnegoAuthenticationProcessingFilter filter = new SpnegoAuthenticationProcessingFilter();
			try {
				filter.setAuthenticationManager(authenticationManagerBean());
			} catch (Exception e) {
				log.error("Failed to set AuthenticationManager on SpnegoAuthenticationProcessingFilter.", e);
			}
			return filter;
		}

		@Bean
		public KerberosServiceAuthenticationProvider kerberosServiceAuthenticationProvider() {
			KerberosServiceAuthenticationProvider provider = new KerberosServiceAuthenticationProvider();
			provider.setTicketValidator(sunJaasKerberosTicketValidator());
			provider.setUserDetailsService(dummyUserDetailsService());
			return provider;
		}

		@Bean
		public SunJaasKerberosTicketValidator sunJaasKerberosTicketValidator() {
			SunJaasKerberosTicketValidator ticketValidator = new SunJaasKerberosTicketValidator();
			Map<String, Object> props = webServiceProperties().getProperties();
			ticketValidator.setServicePrincipal((String) props.get("service-principal")); // At this point, it must be
																							// according to what we
			// were given in the commands from the first step.
			FileSystemResource fs = new FileSystemResource((String) props.get("keytab-location")); // Path to file
																									// tomcat.keytab
			log.info("Initializing Kerberos KEYTAB file path:" + (String) props.get("keytab-location"));
			Assert.notNull(fs.exists(), "*.keytab key must exist. Without that security is useless.");
			ticketValidator.setKeyTabLocation(fs);
			ticketValidator.setDebug(true); // Turn off when it will works properly,
			return ticketValidator;
		}

		@Bean
		public DummyUserDetailsService dummyUserDetailsService() {
			return new DummyUserDetailsService();
		}
	}

	@Bean
	static BeanPostProcessor c2iJsonRequestBodyArgumentResolverRegisteringBeanPostProcessor() {
		return new C2iJsonRequestBodyArgumentResolverRegisteringBeanPostProcessor();
	}
}
