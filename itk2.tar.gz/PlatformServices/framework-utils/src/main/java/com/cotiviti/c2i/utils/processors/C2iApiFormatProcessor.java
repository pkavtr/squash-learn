package com.cotiviti.c2i.utils.processors;

import java.util.Arrays;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import javax.annotation.processing.AbstractProcessor;
import javax.annotation.processing.Messager;
import javax.annotation.processing.RoundEnvironment;
import javax.lang.model.SourceVersion;
import javax.lang.model.element.Element;
import javax.lang.model.element.ElementKind;
import javax.lang.model.element.ExecutableElement;
import javax.lang.model.element.TypeElement;
import javax.lang.model.element.VariableElement;
import javax.tools.Diagnostic;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;

import com.cotiviti.c2i.utils.annotations.C2iApiFormat;

/**
 * This class checks if the api path is correctly defined based on c2i web service standard.
 * 
 * Currently, it checks if the path has the format of "^/v(\\d+)/(.*)".
 * 
 * @author kchen
 *
 */
public class C2iApiFormatProcessor extends AbstractProcessor {
	
	private static Logger log = LoggerFactory.getLogger(C2iApiFormatProcessor.class);	

	String pattern_str = "^/v(\\d+)/(.*)";
	Pattern pattern = Pattern.compile(pattern_str);
	
	@Override
	public boolean process(Set<? extends TypeElement> annotations, RoundEnvironment roundEnv) {
		
		Messager messager = processingEnv.getMessager();
		for (Element annotatedElement : roundEnv.getElementsAnnotatedWith(RequestMapping.class)) {
			if (annotatedElement.getKind() == ElementKind.CLASS) {
				log.info("Class: " + annotatedElement.toString());
				this.checkVersionAndMediaType(annotatedElement, messager, false, false);
			}
			else {
				log.info("Method: " + annotatedElement.toString());
				// if sending in stuff in request body, we mandate the request body to be in json format with @RequestBody
				List<? extends VariableElement> vels = ((ExecutableElement)annotatedElement).getParameters();
				Boolean consumesCheck = false;
				for (VariableElement vel: vels) {
					if (vel.getAnnotation(RequestBody.class) != null) {
						consumesCheck = true;
						break;
					}
				}
				this.checkVersionAndMediaType(annotatedElement, messager, true, consumesCheck);
			}
	    }
		
		return false;
	}

	@Override
    public SourceVersion getSupportedSourceVersion() {
        return SourceVersion.latestSupported();
    }

    @Override
    public Set<String> getSupportedAnnotationTypes() {
        return new HashSet<>(Arrays.asList(C2iApiFormat.class.getName()));
    }
    
    private void checkVersionAndMediaType(Element annotatedElement, Messager messager, Boolean mandatoryCheck, Boolean consumesCheck) {
    	
    	RequestMapping annotation = annotatedElement.getAnnotation(RequestMapping.class);
    	
    	if (consumesCheck) {
	    	// we only receive json format document
	    	if (annotation.consumes() == null || annotation.consumes().length != 1) {
	    		messager.printMessage(Diagnostic.Kind.ERROR,
	                    "The content type in @RequestMapping of " + annotatedElement.toString() + " method must be defined with consumes=\"application/json\" exactly.");
	    	}
	    	else {
	    		Boolean hasCorrectContextType = false;
	    		for (String consume: annotation.consumes()) {
	    			log.info("consume: " + consume);
	    			if (consume.toLowerCase().equals("application/json")) {
	    				hasCorrectContextType = true;
	    				break;
	    			}
	    		}
	    		
	    		if (!hasCorrectContextType)
	    			messager.printMessage(Diagnostic.Kind.ERROR,
	                        "The content type in @RequestMapping of " + annotatedElement.toString() + " method must be defined with consumes=\"application/json\" exactly.");
	    	}
    	}
    	
    	// we are only response with json format document
    	if (annotation.produces() == null || annotation.produces().length == 0) {
    		messager.printMessage(Diagnostic.Kind.ERROR,
                    "The accept type in @RequestMapping of " + annotatedElement.toString() + " method must be defined with produces=\"application/json\".");
    	}
    	else {
    		Boolean hasCorrectAcceptType = false;
    		for (String produce: annotation.produces()) {
    			log.info("produce: " + produce);
    			if (produce.toLowerCase().equals("application/json")) {
    				hasCorrectAcceptType = true;
    				break;
    			}
    		}
    		
    		if (!hasCorrectAcceptType)
    			messager.printMessage(Diagnostic.Kind.ERROR,
                        "The accept type in @RequestMapping of " + annotatedElement.toString() + " method must be defined with produces=\"application/json\".");
    	}
		
		// check if the value tag is empty first
		if (mandatoryCheck && (annotation.value() == null || annotation.value().length == 0)) {
			messager.printMessage(Diagnostic.Kind.ERROR,
                    "The request path in @RequestMapping of " + annotatedElement.toString() + " method must be defined with non-empty strings.  The format of a string should be \"^/v(\\d+)/(.*)\".");
		}
		else {
			for (String value: annotation.value()) {
				log.info("Annotation value: " + value);
				Matcher m = this.pattern.matcher(value);
				if (!m.find()) {
					//TODO - should use string formatter instead of string concat
					messager.printMessage(Diagnostic.Kind.ERROR,
	                        "The request path, \"" + value + "\", defined in @RequestMapping of " + annotatedElement.toString() + " method is not a valid format.  The format should be \"^/v(\\d+)/(.*)\".");
				}
			}
		}
    }
}
