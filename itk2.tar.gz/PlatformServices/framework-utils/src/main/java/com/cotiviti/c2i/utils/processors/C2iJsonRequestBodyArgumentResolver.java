package com.cotiviti.c2i.utils.processors;

import org.everit.json.schema.Schema;
import org.everit.json.schema.ValidationException;
import org.everit.json.schema.loader.SchemaLoader;
import org.json.JSONObject;
import org.json.JSONTokener;
import org.springframework.core.Conventions;
import org.springframework.core.MethodParameter;
import org.springframework.core.io.ClassPathResource;
import org.springframework.util.StreamUtils;
import org.springframework.validation.AbstractBindingResult;
import org.springframework.validation.BindingResult;
import org.springframework.validation.ObjectError;
import org.springframework.web.bind.support.WebDataBinderFactory;
import org.springframework.web.context.request.NativeWebRequest;
import org.springframework.web.context.request.WebRequest;
import org.springframework.web.method.support.HandlerMethodArgumentResolver;
import org.springframework.web.method.support.ModelAndViewContainer;

import com.cotiviti.c2i.utils.annotations.C2iJsonRequestBody;
import com.cotiviti.c2i.utils.exception.C2iJsonSchemaException;
import com.cotiviti.c2i.utils.exception.C2iJsonSchemaValidationException;
import com.cotiviti.c2i.utils.exception.C2iUnavailableJsonSchemaException;
import com.cotiviti.c2i.utils.exception.C2iValidationExceptionMediator;
import com.fasterxml.jackson.databind.ObjectMapper;

import javax.servlet.http.HttpServletRequest;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import java.lang.reflect.Type;

public class C2iJsonRequestBodyArgumentResolver implements HandlerMethodArgumentResolver {

	private Map<String, Schema> schemaCache = new ConcurrentHashMap<String, Schema>();

	private C2iValidationExceptionMediator validationExceptionMediator = new C2iValidationExceptionMediator();

    public C2iJsonRequestBodyArgumentResolver() {
    }

    @Override
    public Object resolveArgument(MethodParameter parameter, ModelAndViewContainer mavContainer, NativeWebRequest webRequest, WebDataBinderFactory binderFactory) throws Exception {
        
    	Type type = parameter.getGenericParameterType();
        String name = Conventions.getVariableNameForParameter(parameter);
        BindingResult bindingResult = (BindingResult) mavContainer.getModel().get(BindingResult.MODEL_KEY_PREFIX + name);
        if (bindingResult == null) {
            bindingResult = createBindingResult(webRequest);
            mavContainer.addAttribute(BindingResult.MODEL_KEY_PREFIX +  name, bindingResult);
        }
        String str = validate(parameter, webRequest, bindingResult, isThrowingExceptionOnValidationError(parameter));
        ObjectMapper mapper = new ObjectMapper();
        Object requestBodyAnnotatedReturnValue = mapper.readValue(str, (Class<?>) type);
        return requestBodyAnnotatedReturnValue;
    }

    private BindingResult createBindingResult(WebRequest webRequest) {
        return new WebRequestBindingResult(webRequest);
    }

    private boolean isThrowingExceptionOnValidationError(MethodParameter parameter) {
        C2iJsonRequestBody annotation = parameter.getParameterAnnotation(C2iJsonRequestBody.class);
        return annotation.strict();
    }

    private String validate(MethodParameter parameter, NativeWebRequest webRequest, BindingResult bindingResult, boolean throwExceptionOnSchemaValidationError) throws IOException {
        int beforeSchemaValidationErrorCount = bindingResult.getErrorCount();
        String requestBodyJson = getJsonPayload(webRequest);
        validateRequestBody(requestBodyJson, bindingResult, parameter);

        if (bindingResult.getErrorCount() > beforeSchemaValidationErrorCount && throwExceptionOnSchemaValidationError) {
        	    	StringBuilder sb = new StringBuilder();
	    		for (ObjectError br: bindingResult.getAllErrors()) {
	    			sb.append(br.getDefaultMessage()).append(", ");
	    		}
            throw new C2iJsonSchemaValidationException(bindingResult, sb.toString());
        }
        return requestBodyJson;
    }

    private void validateRequestBody(String json, BindingResult bindingResult, MethodParameter methodParameter) 
    		throws C2iJsonSchemaException {
    		
    	// TODO - we will make this to look for http resources such as any git repo or schema registry or ...
    	// currently, it only works for class path resources.
   		C2iJsonRequestBody annotation = methodParameter.getParameterAnnotation(C2iJsonRequestBody.class);
        String schemaPath = annotation.schemaPath();
        String fullSchemaPath;
        if (!schemaPath.isEmpty()) {
        		fullSchemaPath = "/" + schemaPath + ".json";
        } 
        else {
            String declaringClassName = methodParameter.getDeclaringClass().getSimpleName().toLowerCase();
            String methodName = methodParameter.getMethod().getName();
            fullSchemaPath = "/" + declaringClassName + "#" + methodName + ".json";
        }
        
        ClassPathResource jsonSchemaResource = null;
        try {
    		Schema schema = schemaCache.get(fullSchemaPath);
        	if (schema == null) {        		
	       		jsonSchemaResource = new ClassPathResource(fullSchemaPath);
	            JSONObject rawSchema = new JSONObject(new JSONTokener(jsonSchemaResource.getInputStream()));
	            
	            SchemaLoader loader = SchemaLoader.builder()
                    .schemaJson(rawSchema)
                    .draftV6Support()
                    .build();
	            schema = loader.load().build();
	            schemaCache.put(fullSchemaPath, schema);
    		}
    		JSONObject jsonObject = new JSONObject(new JSONTokener(json));
            schema.validate(jsonObject);
        } catch (ValidationException e) {
            this.validationExceptionMediator.convert(e, bindingResult);
        } catch (IOException e) {
            throw new C2iUnavailableJsonSchemaException(jsonSchemaResource, e);
        }
    }

    private String getJsonPayload(NativeWebRequest webRequest) throws IOException {
        HttpServletRequest httpServletRequest = webRequest.getNativeRequest(HttpServletRequest.class);
        return StreamUtils.copyToString(httpServletRequest.getInputStream(), StandardCharsets.UTF_8);
    }

    /**
     * Supports the @{@link C2iJsonRequestBody}-annotated method parameters.
     */
    @Override
    public boolean supportsParameter(MethodParameter parameter) {
        return parameter.hasParameterAnnotation(C2iJsonRequestBody.class);
    }

    public void setValidationExceptionMediator(C2iValidationExceptionMediator validationExceptionMediator) {
        this.validationExceptionMediator = validationExceptionMediator;
    }

    /**
     * Represents an internal binding result mapped
     * over an existing HTTP request with JSON body.
     */
    private static class WebRequestBindingResult extends AbstractBindingResult {

		private static final long serialVersionUID = 6611087312422744640L;
		private final WebRequest webRequest;

        protected WebRequestBindingResult(WebRequest webRequest) {
            super("request");
            this.webRequest = webRequest;
        }

        @Override
        public WebRequest getTarget() {
            return this.webRequest;
        }

        @Override
        protected Object getActualFieldValue(String field) {
            return this.webRequest.getParameter(field);
        }
    }
}
