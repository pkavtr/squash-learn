package com.cotiviti.c2i.utils.annotations;

import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

/**
 * Annotation to check if the @RequestMapping has correct value according to c2i Web Service Standard
 * 
 * All RestControllers have to have this annotation to allow checking if value in @RequestMapping is 
 * defined correctly
 * 
 * @author kchen
 *
 */
@Retention(RetentionPolicy.RUNTIME)
@Target({ElementType.TYPE, ElementType.METHOD})
public @interface C2iApiFormat {
	
}
