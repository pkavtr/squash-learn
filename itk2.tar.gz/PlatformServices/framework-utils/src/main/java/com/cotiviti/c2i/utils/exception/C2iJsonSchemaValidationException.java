package com.cotiviti.c2i.utils.exception;

import org.springframework.validation.Errors;

public class C2iJsonSchemaValidationException extends C2iJsonSchemaException {

	private static final long serialVersionUID = 4223627541020165381L;
	private Errors errors;

    public C2iJsonSchemaValidationException(Errors errors) {
        this.errors = errors;
    }

    public C2iJsonSchemaValidationException(Errors errors, String errMsg) {
    		super(errMsg);
    		this.errors = errors;
    }
    
    public Errors getBindingResult() {
        return this.errors;
    }
}
