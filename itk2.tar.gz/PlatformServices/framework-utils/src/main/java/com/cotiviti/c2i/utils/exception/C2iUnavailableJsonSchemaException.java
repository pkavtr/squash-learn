package com.cotiviti.c2i.utils.exception;

import org.springframework.core.io.Resource;

public class C2iUnavailableJsonSchemaException extends C2iJsonSchemaException {

	private static final long serialVersionUID = -4423386426489030771L;

	public C2iUnavailableJsonSchemaException(Resource jsonSchemaResource, Throwable cause) {
        super("Unable to load JSON schema from " + jsonSchemaResource.getDescription(), cause);
    }

    public C2iUnavailableJsonSchemaException() {
    }

    public C2iUnavailableJsonSchemaException(String msg) {
        super(msg);
    }

    public C2iUnavailableJsonSchemaException(String message, Throwable cause) {
        super(message, cause);
    }

    public C2iUnavailableJsonSchemaException(Throwable cause) {
        super(cause);
    }
}
