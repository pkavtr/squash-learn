package com.cotiviti.c2i.utils.annotations.test;

import java.util.UUID;

public class BoxRequest {
    private Long count;

    private String name;

    private UUID id;

    public Long getCount() {
        return count;
    }

    public void setCount(Long count) {
        this.count = count;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public void setId(UUID id) {
        this.id = id;
    }

    public UUID getId() {
        return id;
    }
}