package com.cotiviti.c2i.utils.annotations.test;

import com.cotiviti.c2i.utils.exception.C2iJsonSchemaValidationException;
import com.cotiviti.c2i.utils.exception.C2iUnavailableJsonSchemaException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.exc.InvalidFormatException;
import org.springframework.http.HttpStatus;
import org.springframework.http.converter.HttpMessageNotReadableException;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.ResponseStatus;

import java.util.List;

@ControllerAdvice
public class RestExceptionHandler {
    @ExceptionHandler
    @ResponseBody
    @ResponseStatus(HttpStatus.UNPROCESSABLE_ENTITY)
    public ApiError handleJsonSchemaValidationException(C2iJsonSchemaValidationException exception) {
        return ApiError.of(exception.getBindingResult());
    }

    @ExceptionHandler
    @ResponseBody
    @ResponseStatus(HttpStatus.UNPROCESSABLE_ENTITY)
    public ApiError handleHttpMessageNotReadableException(HttpMessageNotReadableException e) {
        if (e.getCause() instanceof InvalidFormatException) {
            InvalidFormatException invalidFormatException = (InvalidFormatException) e.getCause();
            ApiError apiError = new ApiError();
            apiError.addFieldError(getField(invalidFormatException), "invalid-property", invalidFormatException.getOriginalMessage());
            return apiError;
        } else {
            return new ApiError().addGlobalError("payload", e.getMessage());
        }
    }

    @ExceptionHandler
    @ResponseBody
    @ResponseStatus(HttpStatus.UNPROCESSABLE_ENTITY)
    public ApiError handleUnavailableJsonSchemaException(C2iUnavailableJsonSchemaException exception) {
        return new ApiError().addGlobalError("payload", "Internal validation error");
    }

    private String getField(InvalidFormatException exception) {
        List<JsonMappingException.Reference> path = exception.getPath();
        JsonMappingException.Reference lastComponent = path.get(path.size() - 1);
        return lastComponent.getFieldName();
    }

}