package com.cotiviti.c2i.kafkaconnectintegrationtests;

import static org.junit.Assert.assertEquals;

import java.util.List;
import java.util.concurrent.ExecutionException;

import javax.transaction.Transactional;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.context.SpringBootTest.WebEnvironment;
import org.springframework.boot.web.server.LocalServerPort;
import org.springframework.test.context.junit4.SpringRunner;

import com.cotiviti.c2i.kafkaconnectintegrationtests.model.AvroClient;
import com.cotiviti.c2i.kafkaconnectintegrationtests.model.JsonClient;
import com.cotiviti.c2i.kafkaconnectintegrationtests.model.MySQL.MySQLModel;
import com.cotiviti.c2i.kafkaconnectintegrationtests.model.SQLServer.SQLServerModel;
import com.cotiviti.c2i.kafkaconnectintegrationtests.repository.MySQL.MySQLRepository;
import com.cotiviti.c2i.kafkaconnectintegrationtests.repository.SQLServer.SQLServerRepo;
import com.cotiviti.c2i.kafkaconnectintegrationtests.service.KafkaService;

@RunWith(SpringRunner.class)
@SpringBootTest(webEnvironment=WebEnvironment.RANDOM_PORT)
public class KafkaConnectIntegrationTestsApplicationTests {

	@LocalServerPort
	private int port;

	@Autowired
	private KafkaService ks;
	
	@Autowired
	private SQLServerRepo sqlServerRepo;
	
	
	
	private static Logger log = LoggerFactory.getLogger(KafkaConnectIntegrationTestsApplicationTests.class);
	/**
	 * Test if Kafka is Up and running
	 * @throws InterruptedException
	 * @throws ExecutionException
	 */
	@Test
		public void kafkaSendAndRecieveMessage() throws InterruptedException, ExecutionException{
		log.debug("entered sendMessage");
		JsonClient client = new JsonClient(123, "james");
		ks.produce(client);
		Thread.sleep(1000);
		List<AvroClient> clients = ks.consume();
		String name =  clients.get(0).getName().toString();
		assertEquals("james",name);
		
	}
	
	/**
	 * Test if MsSQl is up and running
	 */
	@Test
	@Transactional
	public void mssqlTest()
	{
		//assumeTrue(dbRepository.!=null);
		SQLServerModel sample = new SQLServerModel(1, "james");
		sqlServerRepo.save(sample);
		
		List<SQLServerModel> dbModels = sqlServerRepo.findByName("james");
		for (SQLServerModel dbModel : dbModels) {
			log.info(dbModel.getName()+" "+dbModel.getId());
		}
		assertEquals(dbModels.isEmpty(),false);
	}
	
	@Test
	public void msSqlSourceTest() throws InterruptedException
	{
		SQLServerModel sample = new SQLServerModel(1, "preetham");
		sqlServerRepo.save(sample);

		Thread.sleep(1000);
		List<AvroClient> clients = ks.consume();
		String name =  clients.get(0).getName().toString();
		assertEquals("preetham",name);
		
		
	}
	
	
	
	 
}
