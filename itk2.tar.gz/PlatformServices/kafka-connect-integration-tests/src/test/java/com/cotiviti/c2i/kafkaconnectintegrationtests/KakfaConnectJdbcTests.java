package com.cotiviti.c2i.kafkaconnectintegrationtests;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;

import java.util.List;
import java.util.concurrent.ExecutionException;

import javax.transaction.Transactional;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.context.SpringBootTest.WebEnvironment;
import org.springframework.test.context.junit4.SpringRunner;

import com.cotiviti.c2i.kafkaconnectintegrationtests.model.AvroClient;
import com.cotiviti.c2i.kafkaconnectintegrationtests.model.JsonClient;
import com.cotiviti.c2i.kafkaconnectintegrationtests.model.MySQL.MySQLModel;
import com.cotiviti.c2i.kafkaconnectintegrationtests.repository.MySQL.MySQLRepository;
import com.cotiviti.c2i.kafkaconnectintegrationtests.service.KafkaService;
/**
 * 
 * @author vishnu
 *
 */
@RunWith(SpringRunner.class)
@SpringBootTest(webEnvironment=WebEnvironment.RANDOM_PORT)

public class KakfaConnectJdbcTests 
{
	@Autowired
	private MySQLRepository mysqlRepo;
	
	@Autowired
	private KafkaService ks;
	
	private static Logger log = LoggerFactory.getLogger(KakfaConnectJdbcTests.class);
	
	static int id = 1;
	@Test
	@Transactional
	public void mysqlTest(){
		//assumeTrue(mySQLRepository);
		
		System.out.println("value "+mysqlRepo.count());
		MySQLModel input = new MySQLModel(1, "vishnu");
	    mysqlRepo.save(input);
		
		MySQLModel output = mysqlRepo.findById(input.getId());
		
		assertEquals(input.getName(),output.getName());
		assertEquals(input.getId(), output.getId());
	}
	
	@Test
	public void testJdbcSink() throws InterruptedException, ExecutionException {
		JsonClient inputClient = new JsonClient(2, "random_1");
		ks.produce(inputClient);
		
		Thread.sleep(1000);
		
		MySQLModel outputClient = mysqlRepo.findById(inputClient.getId());
		
		assertEquals(outputClient.getName(), inputClient.getName());
		assertEquals(outputClient.getId(), inputClient.getId());
	}
	
	/**
	 * This test is not yet done. Issue with serialization. 
	 * 
	 * 
	 * @throws InterruptedException
	 */
	@Test
	public void testJdbcSource() throws InterruptedException{
		MySQLModel inputClient = new MySQLModel(5,"random_5");
		mysqlRepo.save(inputClient);
		Thread.sleep(1000);
		
		List<AvroClient> clients = ks.consume();
		log.info("list of consume"+ clients.size()); // size is always zero
	}
}
