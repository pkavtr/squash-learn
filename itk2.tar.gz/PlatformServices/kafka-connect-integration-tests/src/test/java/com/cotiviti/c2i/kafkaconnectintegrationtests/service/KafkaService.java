package com.cotiviti.c2i.kafkaconnectintegrationtests.service;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.ExecutionException;

import org.apache.kafka.clients.consumer.Consumer;
import org.apache.kafka.clients.consumer.ConsumerRecord;
import org.apache.kafka.clients.consumer.ConsumerRecords;
import org.apache.kafka.clients.producer.Producer;
import org.apache.kafka.clients.producer.ProducerRecord;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import com.cotiviti.c2i.kafkaconnectintegrationtests.model.AvroClient;
import com.cotiviti.c2i.kafkaconnectintegrationtests.model.JsonClient;


@Service
public class KafkaService {

	private static Logger log = LoggerFactory.getLogger(KafkaService.class);	
	
	@Autowired
	private Producer<String, AvroClient> producer;
	
	@Autowired
	Consumer<String, AvroClient> consumer;

	@Value("${producer.properties.topicName}")
	String topicName;  
	
	public void produce(JsonClient client) throws InterruptedException, ExecutionException {

		log.debug("ClientController:producer is called");
		AvroClient avroClient = AvroClient.newBuilder().setName(client.getName()).setId(client.getId()).build();		
		producer.send(new ProducerRecord<String,AvroClient>(topicName,"",avroClient));

	}

	
	public List<AvroClient> consume() {
		log.debug("ClientController:consumer is called");
		List<AvroClient> clients = new ArrayList<>();
		try {
		    ConsumerRecords<String, AvroClient> records = consumer.poll(1000);
		    
            if (records.count() > 0) {
            	for (ConsumerRecord<String, AvroClient> record: records) {
            		Object obj = record.value();
            		
            		if (obj instanceof AvroClient) {
            			AvroClient event = (AvroClient) obj;
	            		clients.add(event);
	            		log.debug(event.toString());
            		}
                }
                consumer.commitSync();
            }
		}
		catch (Exception ex) {
			log.debug("exception at kafllka consumer : "+ex.getMessage());
		}    
		return clients;
	}

}
