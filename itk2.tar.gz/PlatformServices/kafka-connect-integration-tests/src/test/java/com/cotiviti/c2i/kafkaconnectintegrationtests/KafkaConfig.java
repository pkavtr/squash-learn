package com.cotiviti.c2i.kafkaconnectintegrationtests;

import java.util.HashMap;
import java.util.Map;

import org.apache.kafka.clients.consumer.Consumer;
import org.apache.kafka.clients.producer.Producer;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.kafka.core.DefaultKafkaProducerFactory;
import org.springframework.kafka.core.KafkaTemplate;

import com.cotiviti.c2i.kafkaconnectintegrationtests.model.AvroClient;
import com.cotiviti.c2i.utils.property.C2iConfigProperties;
import com.cotiviti.c2i.utils.queuing.kafka.C2iKafkaConsumer;
import com.cotiviti.c2i.utils.queuing.kafka.C2iKafkaProducer;

@Configuration
public class KafkaConfig {
	
	@Bean
	@ConfigurationProperties(prefix="producer")
	public C2iConfigProperties producerProperties() {
		
		C2iConfigProperties prop = new C2iConfigProperties();		
		return prop;
	}
		
	@Bean
	@ConfigurationProperties(prefix="consumer")
	public C2iConfigProperties consumerProperties() {
		
		C2iConfigProperties prop = new C2iConfigProperties();	
		return prop;
	}
	

	@Bean
	public Producer<String, AvroClient> producer() {
		
		C2iKafkaProducer<String, AvroClient> c2iKafkaProducer 
			= new C2iKafkaProducer<String, AvroClient>();
		c2iKafkaProducer.setProperties((HashMap) producerProperties().getFormattedProperties());
		
		Producer<String, AvroClient> clientProducer = c2iKafkaProducer.createProducer();
		return clientProducer;
	}
	
	@Bean
	public Consumer<String, AvroClient> consumer() {
		
		C2iKafkaConsumer<String, AvroClient> c2iKafkaConsumer 
			= new C2iKafkaConsumer<String, AvroClient>(consumerProperties().getFormattedProperties());
		Consumer<String, AvroClient> clientConsumer = c2iKafkaConsumer.createConsumer();
		return clientConsumer;
	}
}
