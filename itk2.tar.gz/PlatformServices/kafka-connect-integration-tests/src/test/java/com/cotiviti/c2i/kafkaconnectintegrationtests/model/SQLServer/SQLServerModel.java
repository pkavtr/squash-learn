package com.cotiviti.c2i.kafkaconnectintegrationtests.model.SQLServer;

import java.util.Date;

import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import org.hibernate.annotations.CreationTimestamp;

import javax.persistence.Id;

@Entity
@Table(name="test")
public class SQLServerModel {

	@Id
	@Column(name="id")
	int id;
	@Column(name="name")
	String name;
	@Column(nullable = false, updatable = false)
	@CreationTimestamp
	private Date create_ts;
	@Column(nullable = false, updatable = false)
	@CreationTimestamp
	private Date update_ts;

	
	public SQLServerModel()
	{}


	public SQLServerModel(int id, String name) {
		super();
		this.id = id;
		this.name = name;
	}

	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	
	public Date getCreate_ts() {
		return create_ts;
	}

	public Date getUpdate_ts() {
		return update_ts;
	}
	
	
}