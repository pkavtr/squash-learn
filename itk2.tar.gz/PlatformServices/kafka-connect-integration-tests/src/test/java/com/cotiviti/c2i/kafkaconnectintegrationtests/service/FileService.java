package com.cotiviti.c2i.kafkaconnectintegrationtests.service;
import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import com.cotiviti.c2i.kafkaconnectintegrationtests.model.JsonClient;



@Service
public class FileService 
{
	final private String FILEPATH = "/home/vishnu/Desktop/connector-files/file-sink-output.txt";
	private static Logger log = LoggerFactory.getLogger(FileService.class);
	public String getLastRecordFromFile()
	{
		log.debug("entered getLastRecordFromFile of FileService method");
		String lastLine = "";
		String currentLine = "";
		try
		{
			BufferedReader br = new BufferedReader(new FileReader(FILEPATH));
			while((currentLine = br.readLine())!= null) 
			{
				
				lastLine = currentLine;
			}
			log.info("last record :: "+lastLine);
			br.close();
		}
		catch(IOException exception)
		{
		
			log.error("IOException occured. Cause is ",exception.getMessage());
		}
		return lastLine;
	}
	public String getExpectedSinkedRecord(JsonClient record)
	{
		return "Struct{name="+record.getName()+",id="+record.getId()+"}";
		 
	}
}