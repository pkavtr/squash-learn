package com.cotiviti.c2i.kafkaconnectintegrationtests.repository.SQLServer;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.cotiviti.c2i.kafkaconnectintegrationtests.model.SQLServer.SQLServerModel;

public interface SQLServerRepo extends JpaRepository<SQLServerModel,Long> {

	List<SQLServerModel> findByName(String name);
	
}
