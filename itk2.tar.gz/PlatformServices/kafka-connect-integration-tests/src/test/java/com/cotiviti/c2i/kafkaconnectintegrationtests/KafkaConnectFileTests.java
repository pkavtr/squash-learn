package com.cotiviti.c2i.kafkaconnectintegrationtests;

import static org.junit.Assert.assertEquals;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ExecutionException;

import org.apache.kafka.clients.consumer.Consumer;
import org.apache.kafka.clients.consumer.ConsumerRecord;
import org.apache.kafka.clients.consumer.ConsumerRecords;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.context.SpringBootTest.WebEnvironment;
import org.springframework.test.context.junit4.SpringRunner;

import com.cotiviti.c2i.kafkaconnectintegrationtests.model.AvroClient;
import com.cotiviti.c2i.kafkaconnectintegrationtests.model.JsonClient;
import com.cotiviti.c2i.kafkaconnectintegrationtests.service.FileService;
import com.cotiviti.c2i.kafkaconnectintegrationtests.service.KafkaService;
import com.cotiviti.c2i.utils.property.C2iConfigProperties;
import com.cotiviti.c2i.utils.queuing.kafka.C2iKafkaConsumer;
/**
 * 
 * @author vishnu
 *
 */
@RunWith(SpringRunner.class)
@SpringBootTest(webEnvironment=WebEnvironment.RANDOM_PORT)
public class KafkaConnectFileTests 
{
	private static Logger log = LoggerFactory.getLogger(KafkaConnectFileTests.class);
	@Autowired
	private FileService fileService;
	
	@Autowired 
	private KafkaService kafkaService;
	
	Consumer<String, AvroClient> consumer; 
	@Test
	public void testFileSink() throws InterruptedException, ExecutionException{
		JsonClient inputClient = new JsonClient(1,"random_1");
		kafkaService.produce(inputClient);
		Thread.sleep(1000);
		String sinkedRecord = fileService.getLastRecordFromFile();
		log.info("last record from file:: "+sinkedRecord);
		String expectedSinkedRecord = fileService.getExpectedSinkedRecord(inputClient);
		log.info("expected sinked record :: "+expectedSinkedRecord);
		assertEquals(sinkedRecord,expectedSinkedRecord);
	}
	
	@Test
	public void testFileSource() 
	{
		C2iConfigProperties prop = new C2iConfigProperties();
		HashMap<String, Object> properties = new HashMap<String, Object>(); 
		properties.put("topicName", "avroClient-intermediate");
		properties.put("bootstrap-servers","localhost:9092");
		properties.put("schema-registry-url","http://localhost:8081");
		properties.put("group-id","C2iFrameworkSampleClient");
		properties.put("key-deserializer","org.apache.kafka.common.serialization.StringDeserializer");
		properties.put("value-deserializer","io.confluent.kafka.serializers.KafkaAvroDeserializer");
		properties.put("specific-avro-reader","true");
		prop.setProperties(properties);
		
		Map<String, Object> p = prop.getFormattedProperties();
		
		C2iKafkaConsumer<String, AvroClient> c2iKafkaConsumer 
		= new C2iKafkaConsumer<String, AvroClient>();
	consumer = c2iKafkaConsumer.createConsumer();
	List<AvroClient> list = consume();
		
	}
	
	public List<AvroClient> consume() {
		log.debug("ClientController:consumer is called");
		List<AvroClient> clients = new ArrayList<>();
		try {
		    ConsumerRecords<String, AvroClient> records = consumer.poll(1000);
		    
            if (records.count() > 0) {
            	for (ConsumerRecord<String, AvroClient> record: records) {
            		Object obj = record.value();
            		
            		if (obj instanceof AvroClient) {
            			AvroClient event = (AvroClient) obj;
	            		clients.add(event);
	            		log.debug(event.toString());
            		}
                }
                consumer.commitSync();
            }
		}
		catch (Exception ex) {
			log.debug("exception at kafllka consumer : "+ex.getMessage());
		}    
		return clients;
	}
}
