package com.cotiviti.c2i.kafkaconnectintegrationtests;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.builder.SpringApplicationBuilder;
import org.springframework.boot.web.servlet.support.SpringBootServletInitializer;
import org.springframework.context.annotation.Import;

import com.cotiviti.c2i.utils.configs.C2iConfig;


@SpringBootApplication
@Import(C2iConfig.class)
public class KCApplication extends SpringBootServletInitializer{

	@Override
	protected SpringApplicationBuilder configure(SpringApplicationBuilder application) {
		
		return application.sources(KCApplication.class);
	}
	
	public static void main(String[] args) {
		
		SpringApplication.run(KCApplication.class, args);
	}
}
