package com.cotiviti.c2i.kafkaconnectintegrationtests.model.MySQL;
import java.util.Date;

import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import org.hibernate.annotations.CreationTimestamp;

import javax.persistence.Id;

@Entity
@Table(name="avroClient")
public class MySQLModel {

	@Id
	@Column(name="id")
	int id;
	
	@Column(name="name")
	String name;
	
	@Column(nullable = false, updatable = false)
	@CreationTimestamp
	private Date update_ts;

	
	public MySQLModel()
	{}


	public MySQLModel(int id, String name) {
		super();
		this.id = id;
		this.name = name;
	}

	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	

	public Date getUpdate_ts() {
		return update_ts;
	}
	
	
}