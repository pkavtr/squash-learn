package com.cotiviti.c2i.kafkaconnectintegrationtests.repository.MySQL;

import java.util.List;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.cotiviti.c2i.kafkaconnectintegrationtests.model.MySQL.MySQLModel;

@Repository
public interface MySQLRepository extends JpaRepository<MySQLModel,Long> 
{

	MySQLModel findById(int id);
	
}