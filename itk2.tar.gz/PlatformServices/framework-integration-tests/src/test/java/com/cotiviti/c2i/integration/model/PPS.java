package com.cotiviti.c2i.integration.model;

public class PPS {
	private String dispositionNotes;

	private String policySetKey;

	private String payerKey;

	private String clientKey;

	private String clientDesc;

	private String payerShort;

	private String insuranceKey;

	private String insuranceDesc;

	private String claimType;

	private String claimTypeDesc;

	public void setDispositionNotes(String dispositionNotes) {
		this.dispositionNotes = dispositionNotes;
	}

	public String getDispositionNotes() {
		return this.dispositionNotes;
	}

	public void setPolicySetKey(String policySetKey) {
		this.policySetKey = policySetKey;
	}

	public String getPolicySetKey() {
		return this.policySetKey;
	}

	public void setPayerKey(String payerKey) {
		this.payerKey = payerKey;
	}

	public String getPayerKey() {
		return this.payerKey;
	}

	public void setClientKey(String clientKey) {
		this.clientKey = clientKey;
	}

	public String getClientKey() {
		return this.clientKey;
	}

	public void setClientDesc(String clientDesc) {
		this.clientDesc = clientDesc;
	}

	public String getClientDesc() {
		return this.clientDesc;
	}

	public void setPayerShort(String payerShort) {
		this.payerShort = payerShort;
	}

	public String getPayerShort() {
		return this.payerShort;
	}

	public void setInsuranceKey(String insuranceKey) {
		this.insuranceKey = insuranceKey;
	}

	public String getInsuranceKey() {
		return this.insuranceKey;
	}

	public void setInsuranceDesc(String insuranceDesc) {
		this.insuranceDesc = insuranceDesc;
	}

	public String getInsuranceDesc() {
		return this.insuranceDesc;
	}

	public void setClaimType(String claimType) {
		this.claimType = claimType;
	}

	public String getClaimType() {
		return this.claimType;
	}

	public void setClaimTypeDesc(String claimTypeDesc) {
		this.claimTypeDesc = claimTypeDesc;
	}

	public String getClaimTypeDesc() {
		return this.claimTypeDesc;
	}
}
