package com.cotiviti.c2i.integration;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.builder.SpringApplicationBuilder;
import org.springframework.boot.web.servlet.support.SpringBootServletInitializer;
import org.springframework.context.annotation.Import;

import com.cotiviti.c2i.utils.configs.C2iConfig;


@SpringBootApplication
@Import(C2iConfig.class)
public class C2iIntegrationTestApplication extends SpringBootServletInitializer{

	@Override
	protected SpringApplicationBuilder configure(SpringApplicationBuilder application) {
		
		return application.sources(C2iIntegrationTestApplication.class);
	}
	
	public static void main(String[] args) {
		
		SpringApplication.run(C2iIntegrationTestApplication.class, args);
	}
}
