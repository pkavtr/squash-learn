package com.cotiviti.c2i.integration;

import static org.apache.commons.lang3.RandomStringUtils.randomNumeric;
import static org.junit.Assert.assertEquals;

import org.json.JSONException;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.context.SpringBootTest.WebEnvironment;
import org.springframework.boot.test.web.client.TestRestTemplate;
import org.springframework.boot.web.server.LocalServerPort;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.test.context.junit4.SpringRunner;

import com.cotiviti.c2i.integration.model.CustomerV3;
import com.cotiviti.c2i.integration.service.CustomerService;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.github.javafaker.Faker;

@RunWith(SpringRunner.class)
@SpringBootTest(webEnvironment = WebEnvironment.RANDOM_PORT)
public class C2iJSONMessagesTest {
	@LocalServerPort
	private int port;

	private TestRestTemplate template = new TestRestTemplate();

	private static Logger log = LoggerFactory.getLogger(C2iJSONMessagesTest.class);

	/*
	 * Test HTTP status codes and JSON messages for adding and retrieving customers.
	 */
	@Test
	public void testAddCustomerAndFetchInJSONFormat() throws JsonProcessingException {
		//Adding JSON customer.
		log.debug("entered Test to test adding and fetching JSON customers");
		Faker faker = new Faker();
		int id = Integer.parseInt(randomNumeric(4));
		CustomerV3 oCustomer = new CustomerV3(faker.name().fullName(), id, faker.company().profession(),
				faker.address().toString());
		ObjectMapper mapper = new ObjectMapper();
		String expectedCustomerInJSON = mapper.writeValueAsString(oCustomer);
		HttpHeaders headers = new HttpHeaders();
		headers.setContentType(MediaType.APPLICATION_JSON);
		HttpEntity<CustomerV3> entity = new HttpEntity<CustomerV3>(oCustomer, headers);

		ResponseEntity<CustomerV3> response1 = template.exchange("http://localhost:{port}/integrationTest/v1/jsonCustomers",
				HttpMethod.POST, entity, CustomerV3.class, port);
		CustomerV3 fetchedCustomer = response1.getBody();
		assertEquals(HttpStatus.CREATED, response1.getStatusCode());
		assertEquals(fetchedCustomer.getId(),id);
			
		//Retrieving added JSON customer.
		ResponseEntity<String> response2 = template.exchange(
				"http://localhost:{port}/integrationTest/v1/jsonCustomers/" + id, HttpMethod.GET, entity, String.class,
				port);
		String fetchedCustomerAsString = response2.getBody();
		assertEquals(HttpStatus.OK, response2.getStatusCode());
		assertEquals(expectedCustomerInJSON, fetchedCustomerAsString);
	}

	@Test
	// This is Controller Implementation specific.
	// If malformed JSON is sent in request body currently an exception
	// is thrown. This is not caught and hence ISE happens.
	public void testPostRequestwithMalformedJson() {
		log.debug("entered Test to test Post req with malformed JSON");
		HttpHeaders headers = new HttpHeaders();
		headers.setContentType(MediaType.APPLICATION_JSON);
		String jsonInString = "{\"id\" : 78,\"name\" : \"test\",\"role\":\"testrole\",\"tryty\" : \"jhjhkjh\"}";
		HttpEntity<String> entity = new HttpEntity<String>(jsonInString, headers);

		ResponseEntity<String> response = template.exchange("http://localhost:{port}/integrationTest/v1/jsonCustomers",
				HttpMethod.POST, entity, String.class, port);
		assertEquals("Expecting Error code", HttpStatus.BAD_REQUEST, response.getStatusCode());
	}

	
	// This is Controller Implementation specific
	// This Test scope is if we pass id values to uri and 
	// updating the corresponding fields.
	@Test
	public void testUpdateCustomers() throws JSONException {
		log.debug("entered testUpdateCustomers");
		HttpHeaders headers = new HttpHeaders();
		headers.setContentType(MediaType.APPLICATION_JSON);
		HttpEntity<Object> entity = new HttpEntity<Object>( headers);

		ResponseEntity<String> response = template.exchange(
				"http://localhost:{port}/integrationTest/v1/jsonCustomers/"+CustomerService.TEST_CUSTOMER_ID,
				HttpMethod.PUT, entity, String.class, port);
		
		assertEquals(HttpStatus.OK, response.getStatusCode());	
	}
	
	/*
	 * To test for the HTTP status on deleting a customer.
	 */
	@Test
	public void testDeleteCustomers() {
		log.debug("entered testDeleteCustomers");
		HttpHeaders headers = new HttpHeaders();
		headers.setContentType(MediaType.APPLICATION_JSON);
		HttpEntity<Object> entity = new HttpEntity<Object>(headers);
		ResponseEntity<Void> response = template.exchange("http://localhost:{port}/integrationTest/v1/jsonCustomers/" +CustomerService.DELETE_CUSTOMER_ID, 
				HttpMethod.DELETE, entity, Void.class, port);
		assertEquals(HttpStatus.NO_CONTENT, response.getStatusCode());		
	} 
	
}
