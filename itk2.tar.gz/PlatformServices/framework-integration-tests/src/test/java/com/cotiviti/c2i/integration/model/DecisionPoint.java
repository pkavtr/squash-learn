package com.cotiviti.c2i.integration.model;

public class DecisionPoint {
	private String key;

	private String desc;

	public void setKey(String key) {
		this.key = key;
	}

	public String getKey() {
		return this.key;
	}

	public void setDesc(String desc) {
		this.desc = desc;
	}

	public String getDesc() {
		return this.desc;
	}
}
