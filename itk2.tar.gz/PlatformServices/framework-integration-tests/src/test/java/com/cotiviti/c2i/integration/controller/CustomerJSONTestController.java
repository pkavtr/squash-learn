package com.cotiviti.c2i.integration.controller;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.ResponseStatus;

import com.cotiviti.c2i.integration.model.CustomerV3;
import com.cotiviti.c2i.integration.service.CustomerService;
import com.cotiviti.c2i.utils.annotations.C2iApiFormat;
import com.cotiviti.c2i.utils.annotations.C2iRestController;


@C2iApiFormat
@C2iRestController
public class CustomerJSONTestController {

	@Autowired
	private CustomerService oCustomerService;
	private static Logger log = LoggerFactory.getLogger(CustomerJSONTestController.class);

	//API to read json from header section
	@RequestMapping(method=RequestMethod.GET,value="/v1/jsonCustomers",consumes="application/json",produces="application/json")
	public List<CustomerV3> getAllCustomers(){
		return  oCustomerService.getListofCustomers();
	}
	
	@RequestMapping(method=RequestMethod.GET,value="/v1/jsonCustomers/{id}",consumes="application/json",produces="application/json")
	@ResponseBody
	public ResponseEntity<CustomerV3> getCustomersBy(@PathVariable int id)
	{
		CustomerV3 customerV3 = oCustomerService.getCustomersBy(id);
		if (customerV3!=null)
			return new ResponseEntity<CustomerV3>(customerV3, HttpStatus.OK);
		
		return new ResponseEntity<>(HttpStatus.NOT_FOUND);
	}

	
	//API to read json from header section
	@RequestMapping(method=RequestMethod.POST,value="/v1/jsonCustomers",consumes="application/json",produces="application/json")
	@ResponseStatus(HttpStatus.CREATED)
	public  CustomerV3 addcustomerDataFromJson(@RequestBody CustomerV3 customer) {
		return oCustomerService.addCustomer(customer);
	}
	
	// API to read json from header section for put method
	@RequestMapping(method = RequestMethod.PUT, value = "/v1/jsonCustomers/{id}",
			consumes = "application/json", produces = "application/json")
	public ResponseEntity<CustomerV3> updateCustomer(@PathVariable int id) {

		CustomerV3 currentCustomer = oCustomerService.getCustomersBy(id);
		if (currentCustomer == null) {
			return new ResponseEntity<CustomerV3>(HttpStatus.NOT_FOUND);
		}
		currentCustomer.setId(CustomerService.TEST_CUSTOMER_ID);
		currentCustomer.setName("sample");
		currentCustomer.setRole("AutoTesting");
		oCustomerService.updateCustomer(currentCustomer);

		return new ResponseEntity<CustomerV3>(HttpStatus.OK);
	}	
	
	@RequestMapping(method = RequestMethod.DELETE, value = "/v1/jsonCustomers/{id}")
	@ResponseStatus(HttpStatus.NO_CONTENT)
	@ResponseBody
	public void deleteCustomerById(@PathVariable final int id) {
		oCustomerService.deleteCustomer(id);
	}

	
}
