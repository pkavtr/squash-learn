package com.cotiviti.c2i.integration.model;

import java.util.List;

public class RootObject {
	@Override
	public String toString() {
		return "RootPojo [opportunityRuleId=" + opportunityRuleId + ", subRuleKey=" + subRuleKey + ", midRuleKey="
				+ midRuleKey + ", ruleVersion=" + ruleVersion + ", rule=" + rule + ", ruleDesc=" + ruleDesc
				+ ", medicalPolicyKey=" + medicalPolicyKey + ", medicalPolicy=" + medicalPolicy + ", topicKey="
				+ topicKey + ", topic=" + topic + ", decisionPoint=" + decisionPoint + ", opportunityType="
				+ opportunityType + ", cdmDecision=" + cdmDecision + ", noDispositionPPS=" + noDispositionPPS
				+ ", ineligibleDispositionPPS=" + ineligibleDispositionPPS + ", pps=" + pps + "]";
	}

	private String opportunityRuleId;

	private String subRuleKey;

	private String midRuleKey;

	private String ruleVersion;

	private String rule;

	private String ruleDesc;

	private String medicalPolicyKey;

	private String medicalPolicy;

	private String topicKey;

	private String topic;

	private DecisionPoint decisionPoint;

	private String opportunityType;

	private List<String> cdmDecision;

	private List<String> noDispositionPPS;

	private List<String> ineligibleDispositionPPS;

	private List<PPS> pps;

	public void setOpportunityRuleId(String opportunityRuleId) {
		this.opportunityRuleId = opportunityRuleId;
	}

	public String getOpportunityRuleId() {
		return this.opportunityRuleId;
	}

	public void setSubRuleKey(String subRuleKey) {
		this.subRuleKey = subRuleKey;
	}

	public String getSubRuleKey() {
		return this.subRuleKey;
	}

	public void setMidRuleKey(String midRuleKey) {
		this.midRuleKey = midRuleKey;
	}

	public String getMidRuleKey() {
		return this.midRuleKey;
	}

	public void setRuleVersion(String ruleVersion) {
		this.ruleVersion = ruleVersion;
	}

	public String getRuleVersion() {
		return this.ruleVersion;
	}

	public void setRule(String rule) {
		this.rule = rule;
	}

	public String getRule() {
		return this.rule;
	}

	public void setRuleDesc(String ruleDesc) {
		this.ruleDesc = ruleDesc;
	}

	public String getRuleDesc() {
		return this.ruleDesc;
	}

	public void setMedicalPolicyKey(String medicalPolicyKey) {
		this.medicalPolicyKey = medicalPolicyKey;
	}

	public String getMedicalPolicyKey() {
		return this.medicalPolicyKey;
	}

	public void setMedicalPolicy(String medicalPolicy) {
		this.medicalPolicy = medicalPolicy;
	}

	public String getMedicalPolicy() {
		return this.medicalPolicy;
	}

	public void setTopicKey(String topicKey) {
		this.topicKey = topicKey;
	}

	public String getTopicKey() {
		return this.topicKey;
	}

	public void setTopic(String topic) {
		this.topic = topic;
	}

	public String getTopic() {
		return this.topic;
	}

	public void setDecisionPoint(DecisionPoint decisionPoint) {
		this.decisionPoint = decisionPoint;
	}

	public DecisionPoint getDecisionPoint() {
		return this.decisionPoint;
	}

	public void setOpportunityType(String opportunityType) {
		this.opportunityType = opportunityType;
	}

	public String getOpportunityType() {
		return this.opportunityType;
	}

	public void setCdmDecision(List<String> cdmDecision) {
		this.cdmDecision = cdmDecision;
	}

	public List<String> getCdmDecision() {
		return this.cdmDecision;
	}

	public void setNoDispositionPPS(List<String> noDispositionPPS) {
		this.noDispositionPPS = noDispositionPPS;
	}

	public List<String> getNoDispositionPPS() {
		return this.noDispositionPPS;
	}

	public void setIneligibleDispositionPPS(List<String> ineligibleDispositionPPS) {
		this.ineligibleDispositionPPS = ineligibleDispositionPPS;
	}

	public List<String> getIneligibleDispositionPPS() {
		return this.ineligibleDispositionPPS;
	}

	public void setPps(List<PPS> pps) {
		this.pps = pps;
	}

	public List<PPS> getPps() {
		return this.pps;
	}
}
