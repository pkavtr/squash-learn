package com.cotiviti.c2i.integration.model;

import java.util.List;

public class DispositionNotes {
	private int key;

	private String clientName;

	private String note;

	private List<String> payers;

	private List<String> insurance;

	private List<String> claimType;

	public void setKey(int key) {
		this.key = key;
	}

	public int getKey() {
		return this.key;
	}

	public void setClientName(String clientName) {
		this.clientName = clientName;
	}

	public String getClientName() {
		return this.clientName;
	}

	public void setNote(String note) {
		this.note = note;
	}

	public String getNote() {
		return this.note;
	}

	public void setPayers(List<String> payers) {
		this.payers = payers;
	}

	public List<String> getPayers() {
		return this.payers;
	}

	public void setInsurance(List<String> insurance) {
		this.insurance = insurance;
	}

	public List<String> getInsurance() {
		return this.insurance;
	}

	public void setClaimType(List<String> claimType) {
		this.claimType = claimType;
	}

	public List<String> getClaimType() {
		return this.claimType;
	}
}
