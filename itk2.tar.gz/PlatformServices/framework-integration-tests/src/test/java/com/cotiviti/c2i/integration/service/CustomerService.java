package com.cotiviti.c2i.integration.service;

import static org.apache.commons.lang3.RandomStringUtils.randomNumeric;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Iterator;
import java.util.List;

import org.springframework.stereotype.Service;

import com.cotiviti.c2i.integration.model.CustomerV3;
import com.github.javafaker.Faker;

@Service
public class CustomerService {
	Faker faker = new Faker();
	public static final int TEST_CUSTOMER_ID = 61907;
	public static final int DELETE_CUSTOMER_ID = 45678;
	
	 private List<CustomerV3> customers = new ArrayList<CustomerV3>(Arrays.asList(
			new CustomerV3(faker.name().fullName(),Integer.parseInt(randomNumeric(4)),faker.company().profession(),faker.address().toString()),
			new CustomerV3(faker.name().fullName(),Integer.parseInt(randomNumeric(4)),faker.company().profession(),faker.address().toString()),
			new CustomerV3(faker.name().fullName(),Integer.parseInt(randomNumeric(4)),faker.company().profession(),faker.address().toString()),
			new CustomerV3(faker.name().fullName(),DELETE_CUSTOMER_ID,faker.company().profession(),faker.address().toString()),
			new CustomerV3(faker.name().fullName(),TEST_CUSTOMER_ID,faker.company().profession(),faker.address().toString()))
			);
	
	public List<CustomerV3> getListofCustomers() {
		return  customers;
	}

	public CustomerV3 getCustomersBy(int id) {
		//return  customers.stream().filter(t -> t.getId()==id).findFirst().get();	
		for (CustomerV3 customerV3 : customers) {
			if (customerV3.getId()==id)
				return customerV3;
		}
		return null;
	}
	
	public CustomerV3 getFirstCustomer() {
		return customers.get(0);
	}

	public CustomerV3 addCustomer(CustomerV3 customersent) {
		
		customers.add(customersent);
		return customersent;
	}
	
	public void updateCustomer(CustomerV3 customersent) {
		
		int index = customers.indexOf(customersent);
		customers.set(index, customersent);
	}
	
	public void deleteCustomer(int id) {
		
		Iterator<CustomerV3> ite = customers.iterator();
		while (ite.hasNext()) {
			if (ite.next().getId()==id)
				ite.remove();			
		}
		
	}
}
