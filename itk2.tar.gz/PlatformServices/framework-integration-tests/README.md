# Framework Integration Tests

## Introduction

This is a project that houses integration tests for the C2i Services Framework.  Current tests include:
-Http Status code tests

## Building Application

To compile this project,

```
	mvn install
```	

## Run Tests
```
	mvn test
```	



