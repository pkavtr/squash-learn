# Framework Parent Pom

## Introduction

This is a maven pom project that serves as the parent pom for other web services to inherit from.  It contains all the necessary dependency jars/libraries that will allow services inherited from it to follow the same pattern.  In order for other services to compile successfully, developers will need to first compile framework-utils and then this project and then the others.

In the future, all web service framework libraries and poms will be hosted in Artifactory.  Custom web service developers will only need to include the parent pom without compiling any module or project. 

## Building Application

To compile this project,

```
	mvn install
```	
