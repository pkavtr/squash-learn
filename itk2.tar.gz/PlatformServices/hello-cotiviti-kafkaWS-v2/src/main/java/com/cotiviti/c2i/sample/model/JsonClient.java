package com.cotiviti.c2i.sample.model;

public class JsonClient {
    private int id;
    private String name;
    private String accountNumber;

    public String getAccountNumber() {
		return accountNumber;
	}

	public void setAccountNumber(String accountNumber) {
		this.accountNumber = accountNumber;
	}

	public JsonClient() {
        super();
    }

    public JsonClient(final int id, final String name, String an) {
        super();

        this.id = id;
        this.name = name;
        this.accountNumber = an;
    }
    
    public JsonClient(final int id, final String name) {
        super();

        this.id = id;
        this.name = name;
    }

    public int getId() {
        return id;
    }

    public void setId(final int id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(final String name) {
        this.name = name;
    }

}