package com.cotiviti.c2i.sample;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.builder.SpringApplicationBuilder;
import org.springframework.boot.web.servlet.support.SpringBootServletInitializer;
import org.springframework.context.annotation.Import;

import com.cotiviti.c2i.utils.configs.C2iConfig;

@SpringBootApplication
@Import(C2iConfig.class)
public class C2iApplication extends SpringBootServletInitializer{

	@Override
	protected SpringApplicationBuilder configure(SpringApplicationBuilder application) {
		
		return application.sources(C2iApplication.class);
	}
	
	public static void main(String[] args) {
		
		// This is to disable the devtools so it won't create two different class loaders
		// If this is set to true (by default), running this application in eclipse will
		// create error when casting an Avro object will throw exception even the object
		// has the exactly the same class type.
		System.setProperty("spring.devtools.restart.enabled", "false");
		SpringApplication.run(C2iApplication.class, args);
	}
}
