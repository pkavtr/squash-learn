package com.cotiviti.c2i.sample.config;

import java.util.Map;

import org.apache.kafka.clients.consumer.Consumer;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.kafka.core.DefaultKafkaProducerFactory;
import org.springframework.kafka.core.KafkaTemplate;

import com.cotiviti.c2i.sample.model.AvroClient;
import com.cotiviti.c2i.utils.property.C2iConfigProperties;
import com.cotiviti.c2i.utils.queuing.kafka.C2iKafkaConsumer;

@Configuration
public class KafkaConfig {
	@Bean
	@ConfigurationProperties(prefix="producer")
	public C2iConfigProperties producerProperties() {
		
		C2iConfigProperties prop = new C2iConfigProperties();		
		return prop;
	}
	
	@Bean
    public KafkaTemplate<String, AvroClient> kafkaTemplate() {
		Map<String, Object> props = producerProperties().getFormattedProperties();
        KafkaTemplate<String, AvroClient> kafkaTemplate = new KafkaTemplate<>(new DefaultKafkaProducerFactory<>(props));
        kafkaTemplate.setDefaultTopic((String)props.get("topicName"));
        return kafkaTemplate;
    }
	
	@Bean
	@ConfigurationProperties(prefix="consumer")
	public C2iConfigProperties consumerProperties() {
		
		C2iConfigProperties prop = new C2iConfigProperties();		
		return prop;
	}
	
	@Bean
	public Consumer<String, AvroClient> consumer() {
		
		C2iKafkaConsumer<String, AvroClient> c2iKafkaConsumer 
			= new C2iKafkaConsumer<String, AvroClient>(consumerProperties().getFormattedProperties());
		Consumer<String, AvroClient> clientConsumer = c2iKafkaConsumer.createConsumer();
		return clientConsumer;
	}
}
