package com.cotiviti.c2i.sample.api;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.ExecutionException;

import org.apache.kafka.clients.consumer.Consumer;
import org.apache.kafka.clients.consumer.ConsumerRecord;
import org.apache.kafka.clients.consumer.ConsumerRecords;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.kafka.support.SendResult;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseStatus;

import com.cotiviti.c2i.sample.model.AvroClient;
import com.cotiviti.c2i.sample.model.JsonClient;
import com.cotiviti.c2i.utils.annotations.C2iApiFormat;
import com.cotiviti.c2i.utils.annotations.C2iJsonRequestBody;
import com.cotiviti.c2i.utils.annotations.C2iRestController;

@C2iRestController
@C2iApiFormat
public class ClientController {

	private static Logger log = LoggerFactory.getLogger(ClientController.class);	
	
	@Autowired
	private KafkaTemplate<String, AvroClient> producer;
	
	@Autowired
	Consumer<String, AvroClient> consumer;

	@RequestMapping(method = RequestMethod.POST, value = { "/v1/client" }, produces = "application/json")
	@ResponseStatus(HttpStatus.CREATED)
	public String produce(@C2iJsonRequestBody(schemaPath="json/JsonClient_name_required") JsonClient client) throws InterruptedException, ExecutionException {

		log.debug("ClientController:producer is called");
				
		String sex = (Math.random() <= 0.5) ? "male" : "female";
		// if you use JsonClient.json rather than JsonClient_name_required.json and name filed is
		// not in the request, the following code will throw exception
		String[] names = client.getName().split(" ");
		String firstName = "";
		String lastName = "";
		if (names.length > 1) {
			firstName = names[0];
			lastName = names[1];
		}
		AvroClient avroClient = AvroClient.newBuilder().setSex(sex).setAccountNumber(client.getAccountNumber()).setLastName(lastName).setFirstName(firstName).setId(client.getId()).build();
		
		SendResult<String, AvroClient> sendResult = producer.sendDefault(avroClient).get();
		AvroClient ret = sendResult.getProducerRecord().value();
		return (String) ret.getLastName() + " " + (String) ret.getFirstName();
	}

	@RequestMapping(method = RequestMethod.GET, value = "/v1/client", produces = "application/json")
	public String consume() {
		log.debug("ClientController:consumer is called");

		String ret = "No new record in topic";
		
		List<String> clients = new ArrayList<String>();
		try {
			StringBuilder ret_records = new StringBuilder("[\n");
            ConsumerRecords<String, AvroClient> records = consumer.poll(1000);
            if (records.count() > 0) {
            	for (ConsumerRecord<String, AvroClient> record: records) {
            		Object obj = record.value();
            		if (obj instanceof AvroClient) {
	            		AvroClient event = (AvroClient) obj;
		                clients.add(event.getLastName().toString());
		                ret_records.append("\t").append(event.toString()).append(",\n");
		                System.out.println(event.toString());
            		}
            		else if (obj instanceof String) {
            			ret_records.append("\t").append(obj).append(",\n");
            			System.out.println(obj);
            		}
	            }
            	ret = ret_records.toString().substring(0, ret_records.toString().length() - 2) + "\n]";
                consumer.commitSync();
            }
		}
		catch (Exception ex) {
			ret = ex.getMessage();
		}
            
		return ret;
	}

}
