package com.cotiviti.c2i.sample.consumer;

import java.util.Collections;
import java.util.List;

import org.apache.kafka.clients.consumer.ConsumerRecord;
import org.apache.kafka.clients.consumer.ConsumerRecords;
import org.apache.kafka.clients.consumer.KafkaConsumer;
import org.apache.kafka.common.PartitionInfo;
import org.apache.kafka.common.errors.WakeupException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.context.properties.EnableConfigurationProperties;
import org.springframework.context.annotation.Import;

import com.cotiviti.c2i.sample.model.Client;
import com.cotiviti.c2i.utils.configs.C2iConfig;
import com.cotiviti.c2i.utils.property.C2iConfigProperties;

/**
 * This example is an adaptation of the Confluent example at
 * https://www.confluent.io/blog/tutorial-getting-started-with-the-new-apache-kafka-0-9-consumer-client/
 * 
 * @author heather.lott
 *
 */
@SpringBootApplication
@Import(C2iConfig.class)
@EnableConfigurationProperties
public class C2iConsumer implements Runnable {

	private final KafkaConsumer<String, Client> consumer;
	private String inputTopic;
	@Autowired
	C2iConfigProperties consumerProperties;

	public C2iConsumer(String inputTopic) {

		this.consumer = new KafkaConsumer<String, Client>(consumerProperties.getProperties());
		this.inputTopic = inputTopic;
	}

	public List<PartitionInfo> partitionsFor() {
		return consumer.partitionsFor(inputTopic);
	}

	public void run() {

		try {
			consumer.subscribe(Collections.singletonList(inputTopic));

			System.out.println("Reading topic:" + inputTopic);

			while (true) {
				ConsumerRecords<String, Client> records = consumer.poll(1000);

				for (ConsumerRecord<String, Client> record : records) {
					Client event = record.value();

					System.out.println(event.toString());
				}
				consumer.commitSync();
			}
		} catch (WakeupException ex) {
			// ignore for shutdown
		}
	}

	public void shutdown() {
		consumer.wakeup();
	}
}
