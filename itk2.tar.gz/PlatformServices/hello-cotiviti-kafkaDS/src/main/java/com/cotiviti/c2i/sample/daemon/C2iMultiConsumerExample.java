package com.cotiviti.c2i.sample.daemon;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.TimeUnit;

import org.springframework.beans.factory.annotation.Value;

import com.cotiviti.c2i.sample.consumer.C2iConsumer;

/**
 * This example is an adaptation of the Confluent example at
 * https://www.confluent.io/blog/tutorial-getting-started-with-the-new-apache-kafka-0-9-consumer-client/
 * 
 * @author heather.lott
 *
 */
public class C2iMultiConsumerExample {

	@Value("${consumer.properties.topicName}")
	private static String inputTopic;

	public static void main(String[] args) throws ExecutionException, InterruptedException {

		/*
		 * In general, we want one consumer (thread) per partition. If there are more
		 * consumers than that, the extra consumers will be idle. If there are fewer,
		 * each consumer may be handling more than one partition...this could be OK, but
		 * the fastest configuration is probably one consumer per partition.
		 */
		// interrogate a consumer for the number of partitions for the topic
		C2iConsumer firstConsumer = new C2iConsumer(inputTopic);

		int numberOfPartitions = firstConsumer.partitionsFor().size();

		ExecutorService executor = Executors.newFixedThreadPool(numberOfPartitions);

		final List<C2iConsumer> consumers = new ArrayList<>(numberOfPartitions);
		consumers.add(firstConsumer);

		// we subtract one from the numberOfPartitions since we've already created one
		// consumer
		for (int i = 0; i < numberOfPartitions - 1; i++) {
			C2iConsumer consumer = new C2iConsumer(inputTopic);
			consumers.add(consumer);
			executor.submit(consumer);
		}

		Runtime.getRuntime().addShutdownHook(new Thread() {
			@Override
			public void run() {
				for (C2iConsumer consumer : consumers) {
					consumer.shutdown();
				}
				executor.shutdown();
				try {
					executor.awaitTermination(5000, TimeUnit.MILLISECONDS);
				} catch (InterruptedException e) {
					e.printStackTrace();
				}
			}
		});

	}

}
