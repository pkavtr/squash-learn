package com.cotiviti.c2i.sample.daemon;

import java.util.Collections;
import java.util.concurrent.ExecutionException;

import org.apache.kafka.clients.consumer.ConsumerRecord;
import org.apache.kafka.clients.consumer.ConsumerRecords;
import org.apache.kafka.clients.consumer.KafkaConsumer;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;

import com.cotiviti.c2i.sample.model.Client;
import com.cotiviti.c2i.utils.property.C2iConfigProperties;

public class C2iDaemonService {

	private final KafkaConsumer<String, Client> consumer;
	@Value("${consumer.properties.topicName}")
	private static String inputTopic;
	@Autowired
	C2iConfigProperties consumerProperties;

	public static void main(String[] args) throws ExecutionException, InterruptedException {

		C2iDaemonService sessionizer = new C2iDaemonService(inputTopic);
		sessionizer.run();

	}

	public C2iDaemonService(String inputTopic) {

		this.consumer = new KafkaConsumer<String, Client>(consumerProperties.getProperties());
	}

	private void run() throws ExecutionException, InterruptedException {
		consumer.subscribe(Collections.singletonList(inputTopic));

		System.out.println("Reading topic:" + inputTopic);

		while (true) {
			ConsumerRecords<String, Client> records = consumer.poll(1000);

			for (ConsumerRecord<String, Client> record : records) {
				// String ip = record.key();
				Client event = record.value();

				System.out.println(event.toString());
			}
			consumer.commitSync();
		}

	}

}
