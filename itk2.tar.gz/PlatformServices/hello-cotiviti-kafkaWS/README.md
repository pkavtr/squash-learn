# Framework Web Service Sample - Kafka

## Introduction

This sample is similar to the existing hello-cotiviti sample application in the first release and has been created to demonstrate the new features added in this release.  The main features that have been implemented in this release and are used in this sample are

* Allowing properties to be set as an array to simplify the setup of application code with modules that can use java.util.Map to set their properties.  The example of setting up Kafka required properties is the best example and can be seen in application.yml along with com.cotiviti.c2i.sample.kafka.KafkaConfig.java class.  It sets up properties and uses a C2iConfigProperties bean to retrieve them without using any extra application code, and then this bean is injected into Kafka producer and/or consumer clients.

* Allowing verification of JSON requests based on a JSON schema, http://json-schema.org/draft-06/schema#.  For requests that need JSON verification, @C2iJsonRequestBody should be used to annotate the request parameter with a corresponding JSON schema file.  The code using the annotation can be found in com.cotiviti.c2i.sample.ClientController class.  For now, the JSON schema file must be in the class path, but we will enhance it to read an external file path and URL in the near future.

Also, this sample, combined with the hello-cotiviti-kafkaWS-v2 sample, demonstrates a couple features that will be very helpful for Cotiviti applications:

* Avro schema evolution - Avro schemas are used to validate and serialize/deserialize objects being put/pulled into/from Kafka topics. With different versions of the applications being created, the same class in two different versions may have different definitions and therefore, they will have different corresponding Avro schema definitions.  These two samples together provide the view of different definitions of the same class and their schemas in two versions and how Avro objects are being deserialized when the objects persisted in Kafka have different versions of schemas.

* JSON schema - Both samples use JSON schemas to validate the request and make sure the requests follow the specified JSON definitions.  Sample hello-cotiviti-kafkaWS uses the JsonClient.json schema (name field is not required) and Sample hello-cotiviti-kafkaWS-v2 uses JsonClient_Name_Required.json schema.  Developers of application services should use the same request without sending the name field to these two services to see the differences in the responses.

## Build Application

```
mvn clean install
```

## Run Application

### Pre-requisites

Since the sample application uses Kafka as the queuing mechanism and uses the schema registry service to store and retrieve Avro schemas, the Kafka server and schema registry service will need to be started first.  Confluent Kafka is used in our application and it comes with the Kafka server and registry service as well as some other services.  Following is the list of steps to install and start those services:

1. Download the Confluent Kafka zip file with this link: https://www.confluent.io/download/
2. Uncompress the downloaded zip file to a folder and mark down the path to this folder
3. Go to bin sub-folder in the folder above and issue "confluent start" command. This Confluent CLI command starts six services:
	* zookeeper server
	* kafka broker
	* schema-registry service
	* kafka-rest service
	* connect - kafka connect server
	* ksql-server
 
### Embedded Tomcat

To run the application with embedded tomcat,

```
mvn spring-boot:run
```

or

```
java -jar target/hello-cotiviti-kafkaWS-0.0.1-RELEASE.war
```

The default port is 9082.  

### Stand-Alone Tomcat

Following is the list of steps for deploying the war file of this sample application to a stand-alone tomcat server:

1. Build the war file with maven: ```mvn clean install```
2. Copy the created war file in the target directory to tomcat webapps folder: ```cp target/hello-cotiviti-kafkaWS-0.0.1-RELEASE.war $TOMCAT_HOME/webapps/hello```
3. Start tomcat with command: ```$TOMCAT_HOME/bin/startup.sh``` in linux or ```$TOMCAT_HOME/bin/startup.bat``` in Windows

## Integration Tests

1. To access the api document, use the following link with corresponding server port:

```
http://localhost:{port}/hello/swagger-ui.html
```

2. To access the info end point for application meta-data, use the following link with corresponding server port:

```
http://localhost:{port}/hello/actuator/info
```

3. To access the health end point for application health, use the following link with corresponding server port:
```
http://localhost:{port}/hello/actuator/health
```

4. To access the client api with a windows domain user

For accessing GET method - messages (if any) will be pulled from a kafka topic:

```
curl -X GET http://localhost:{port}/hello/v1/client
```

For accessing POST method - request body will be re-formatted and published to a kafka topic:

```
curl -X POST http://localhost:{port}/hello/v1/client -H "content-type: application/json" -d "{'id':3,'name':'John Dow','accountNumber':'111'}"
```