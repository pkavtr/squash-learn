package com.cotiviti.c2i.sample.api;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.ExecutionException;

import org.apache.kafka.clients.consumer.Consumer;
import org.apache.kafka.clients.consumer.ConsumerRecord;
import org.apache.kafka.clients.consumer.ConsumerRecords;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.kafka.support.SendResult;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseStatus;

import com.cotiviti.c2i.sample.model.AvroClient;
import com.cotiviti.c2i.sample.model.JsonClient;
import com.cotiviti.c2i.utils.annotations.C2iApiFormat;
import com.cotiviti.c2i.utils.annotations.C2iJsonRequestBody;
import com.cotiviti.c2i.utils.annotations.C2iRestController;

@C2iRestController
@C2iApiFormat
public class ClientController {

	private static Logger log = LoggerFactory.getLogger(ClientController.class);	
	
	@Autowired
	private KafkaTemplate<String, AvroClient> producer;
	
	@Autowired
	Consumer<String, AvroClient> consumer;

	@RequestMapping(method = RequestMethod.POST, value = { "/v1/client" }, produces = "application/json")
	@ResponseStatus(HttpStatus.CREATED)
	public String produce(@C2iJsonRequestBody(schemaPath="json/JsonClient") JsonClient client) throws InterruptedException, ExecutionException {

		log.debug("ClientController:producer is called");
		// this is just for demo purpose
		String sex = (Math.random() <= 0.5) ? "male" : "female";
		// since name may not be a required field in json validation,  request may not contain it
		String name = "";
		if (client.getName() != null)
			name = client.getName();
		AvroClient avroClient = AvroClient.newBuilder().setSex(sex).setAccountNumber(client.getAccountNumber()).setName(name).setId(client.getId()).build();
		
		SendResult<String, AvroClient> sendResult = producer.sendDefault(avroClient).get();
		AvroClient ret = sendResult.getProducerRecord().value();
		return (String) ret.getName();
	}

	@RequestMapping(method = RequestMethod.GET, value = "/v1/client", produces = "application/json")
	public String consume() {
		log.debug("ClientController:consumer is called");

		String ret = "No new record in topic";
		
		List<String> clients = new ArrayList<String>();
		try {
			StringBuilder ret_records = new StringBuilder("[\n");
            ConsumerRecords<String, AvroClient> records = consumer.poll(1000);
            if (records.count() > 0) {
            	for (ConsumerRecord<String, AvroClient> record: records) {
            		Object obj = record.value();
            		if (obj instanceof AvroClient) {
	            		AvroClient event = (AvroClient) obj;
		                clients.add(event.getName().toString());
		                ret_records.append("\t").append(event.toString()).append(",\n");
		                System.out.println(event.toString());
            		}
            		else if (obj instanceof String) {
            			ret_records.append("\t").append(obj).append(",\n");
            			System.out.println(obj);
            		}
	            }
            	ret = ret_records.toString().substring(0, ret_records.toString().length() - 2) + "\n]";
                consumer.commitSync();
            }
		}
		catch (Exception ex) {
			ret = ex.getMessage();
		}
            
		return ret;
	}

}
