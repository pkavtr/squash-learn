# C2i Standard Templates for Kafka Connect

## Introduction

Kafka Connect is a framework for connecting Kafka with external systems such as databases, key-value stores, search indexes, and file systems.  As a service framework, C2i has implemented a set of Kafka Connect templates to allow application developers to create connections to external sources with a standardized approach.  Currently, we have created,

* c2i-elasticsearch-sink-template.json - reads data from Kafka topic(s) and puts it into an ElasticSearch index or indices.
* c2i-file-sink-template.json - reads data from Kafka topic(s) and puts it into a flat file.
* c2i-file-source-template.json - ingests records from a file and puts them into Kafka topic(s).
* c2i-jdbc-sink-template.json - moves data out of Kafka topic(s) and puts it into databases.
* c2i-jdbc-source-template.json - ingests entire databases and streams table updates to Kafka topics.

Above is just a basic set of Kafka Connect templates and we will implement connectors in the near future.

## Pre-requisites

Since the above templates rely on the Kafka Connect service, a Kafka broker, and the Schema Registry service, we will need to install and start these services first.  To do that:

1. Download the Confluent Kafka zip file with link https://www.confluent.io/download/
2. Uncompress the downloaded zip file to a folder and write down the path to this folder
3. Go to the bin sub-folder in the folder above and issue the "confluent start" command. This Confluent CLI command starts six services:
	* zookeeper server
	* kafka broker
	* schema-registry service
	* kafka-rest service
	* connect - kafka connect server
	* ksql-server

## Kafka Connect Template Deployment

To deploy a Kafka Connect template:

1. Use one of the templates listed above and modify the properties accordingly, such as database connection properties, file path information, and other corresponding parameters.  Please see the comments in each template file for customization.
2. Copy the template to the <path-to-confluent>/share/java/kafka-connect-jdbc/ directory.
3. Deploy the template by executing the following command: "confluent load <connector-name> -d <connector-filename>", e.g., "confluent load c2i-file-sink -d /Users/kchen/confluent-4.1.1/share/java/kafka-connect-jdbc/c2i-file-sink-template.json".

Now, the connector should be running, but you can use the following command to check the connector status, "confluent status <connector-name>", e.g., "confluent status c2i-file-sink".

As an example of showing the complete process, we,

1. First use the POST endpoint in hello-cotiviti-kafkaWS service to post message to a Kafka topic (avroClient); 
2. Use c2i-file-sink-template.json to move the messages in the Kafka topic (avroClient) to a file (kafka-connect-avroClient.txt);
3. Use c2i-file-source-template.json to read records in a file (kafka-connect-avroClient.txt) into a Kafka topic (avroClient-intermediate);
4. Use hello-cotiviti-kafkaDS daemon service to pull records from a Kafka topic (avroClient-intermediate) to another Kafka topic (avroClient-output);
5. Use the GET endpoint in hello-cotiviti-kafkaWS service to retrieve data from a Kafka topic (avroClient-output) and reponse it back to user.

Following is the list of modification that will need to be done to accomplish the above example,

* application.yml in hello-cotiviti-kafkaWS: modify "consumer.properties.topicName = avroClient-output".
* c2i-file-sink-template.json: modify "file" key to have correct file path and file name.
* c2i-file-source-template.json: modify "file" key to have the file path and file name matching the ones in the last bullet point. Also modify the "topics" key to have "avroClient-intermediate" value.
* application.yml in hello-cotiviti-kafkaDS: modify "consumer.properties.topicName=avroClient-intermediat" and "producer.properties.topicName=avroClient-output".

Now, start every services and load the connectors,

* Start hello-cotiviti-kafkaWS service: mvn spring-boot:run;
* Start hello-cotiviti-kafkaDS service: mvn spring-boot:run;
* Load c2i-file-sink-template.json: confluent load c2i-file-sink -d <path-to-file>/c2i-file-sink-template.json
* Load c2i-file-source-template.json: confluent load c2i-file-source -d <path-to-file>/c2i-file-source-template.json

Check if the installation is correct,

For accessing GET method - messages (if any) will be pulled from a kafka topic:

```
curl -X GET http://localhost:9082/hello/v1/client
```

For accessing POST method - request body will be re-formatted and published to a kafka topic:

```
curl -X POST http://localhost:9082/hello/v1/client -H "content-type: application/json" -d "{'id':3,'name':'John Dow','accountNumber':'111'}"
```

Please note, the above process flow demonstrates the integration of Kafka clients (producer and consumer), Kafka topics, and file stream sink & source connectors.  But due to the limitation that FileStreamSourceConnector is not capable of serializing messages into Avro objects, it will not demonstrate the support of Avro schema evolution.  To see Avro schema evolution, make the producer and consumer in hello-cotiviti-kafkaWS have the same topic.  This is essentially by-passing Kafka Connect modules.  In the future, we will modify FileStreamSourceConnector class to read record string from file and convert it into Avro object.