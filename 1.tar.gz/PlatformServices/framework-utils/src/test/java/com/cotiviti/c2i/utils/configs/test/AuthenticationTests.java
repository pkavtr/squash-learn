package com.cotiviti.c2i.utils.configs.test;

import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultHandlers.print;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.forwardedUrl;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.redirectedUrl;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import javax.annotation.Resource;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.boot.context.properties.EnableConfigurationProperties;
import org.springframework.boot.test.context.ConfigFileApplicationContextInitializer;
import org.springframework.http.MediaType;
import org.springframework.mock.web.MockHttpSession;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.authority.AuthorityUtils;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.web.FilterChainProxy;
import org.springframework.security.web.context.HttpSessionSecurityContextRepository;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.context.web.WebAppConfiguration;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import org.springframework.web.context.WebApplicationContext;

import com.cotiviti.c2i.utils.annotations.test.TestApplicationContext;
import com.cotiviti.c2i.utils.configs.C2iConfig;

/**
 * 
 * @author vishnu
 *
 */
@RunWith(SpringJUnit4ClassRunner.class)
@EnableConfigurationProperties
@ContextConfiguration(classes = {TestApplicationContext.class, C2iConfig.class} , initializers = ConfigFileApplicationContextInitializer.class)
@WebAppConfiguration
public class AuthenticationTests{
	  
	
	  
	private MockMvc mvc;
	
	@Resource
	private WebApplicationContext context;
	
	 @Resource
	 private FilterChainProxy springSecurityFilterChain;
	 
	 @Resource
	 protected UserDetailsService userDetailsService;
	
	 

	@Before
	public void setup() {
		mvc = MockMvcBuilders.webAppContextSetup(context).addFilters(springSecurityFilterChain).build();
	}
	
	  	@Test
	    public void loginWithCorrectCredentials() throws Exception {
	        this.mvc.perform(post("/login")
	                .contentType(MediaType.APPLICATION_FORM_URLENCODED)
	                .param("username", "user")
	                .param("password", "password")
	        )
	                .andExpect(status().is3xxRedirection()).andExpect(redirectedUrl("/"));
	    }
	  	
	  	@Test
	  	public void loginWithIncorrectCredentials() throws Exception {
	  		this.mvc.perform(post("/login")
	                .contentType(MediaType.APPLICATION_FORM_URLENCODED)
	                .param("username", "user1")
	                .param("password", "password1")
	        )
	                .andExpect(status().is3xxRedirection()).andExpect(redirectedUrl("/login-error"));
	  	}
	  	
	  	@Test
	  	public void loginWithIncorrectMethodType() throws Exception{
	  		this.mvc.perform(get("/login")
	                .param("username", "user")
	                .param("password", "password")
	        )
	  		 .andDo(print()).andExpect(status().isUnauthorized()).andExpect(forwardedUrl("/login"));
	  	}
	  	
	  	 @Test
	     public void testAccessDeniedForProctectedURLWhenNoAuthentication() throws Exception{
	    	 
	  		this.mvc.perform(get("/")).andExpect(status().isUnauthorized());
	  	 }
	     
	  	@Test
	    public void testAccessGrantedForProtectedURLWhenAuthenticated() throws Exception {
	    	UsernamePasswordAuthenticationToken auth = new UsernamePasswordAuthenticationToken("user","password", AuthorityUtils.createAuthorityList("ROLE_USER"));
	    	MockHttpSession session = new MockHttpSession();
	        session.setAttribute(
	                HttpSessionSecurityContextRepository.SPRING_SECURITY_CONTEXT_KEY, 
	                new MockSecurityContext(auth));
	        
	        mvc.perform(get("/").session(session)).andDo(print()).andExpect(status().is3xxRedirection()).andExpect(redirectedUrl("/index"));
	    }
	  	
	  	@Test
	  	public void testLogout() throws Exception{
	  		UsernamePasswordAuthenticationToken auth = new UsernamePasswordAuthenticationToken("user","password", AuthorityUtils.createAuthorityList("ROLE_USER"));
	  		SecurityContextHolder.getContext().setAuthentication(auth);
	  		MockHttpSession session = new MockHttpSession();
	        session.setAttribute(
	                HttpSessionSecurityContextRepository.SPRING_SECURITY_CONTEXT_KEY, 
	                new MockSecurityContext(auth));

	  		mvc.perform(get("/logout").session(session)).andDo(print()).andExpect(status().is3xxRedirection()).andExpect(redirectedUrl("/login?logout"));
	    }
	  
	  	
	  	
}








