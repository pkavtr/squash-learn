/**
 * Copyright (C) 2018 Cotiviti Digital (nexgen.admin@cotiviti.io)
 *
 * The software code contained herein is the property of Cotiviti Corporation
 * and its subsidiaries and affiliates (collectively, “Cotiviti”).
 * Access to this software code is being provided to you in the course of your
 * employment or affiliation with Cotiviti and may be used solely in the scope
 * and course of your work for Cotiviti, and is for internal Cotiviti use only.
 * Any unauthorized use, disclosure, copying, distribution, destruction of this
 * software code, or the taking of any unauthorized action in reliance on this
 * software code, is strictly prohibited.
 * If this information is viewed in error, immediately discontinue use of the
 * application.  Anyone using this software code and the applications will be
 * subject to monitoring for improper use, system maintenance and security
 * purposes, and is advised that if such monitoring reveals possible criminal
 * activity or policy violation, Cotiviti personnel may provide the evidence of
 * such monitoring to law enforcement or other officials, and the user may be
 * subject to disciplinary action by Cotiviti, up to and including termination
 * of employment.
 *
 * Use of this software code and any applications and information therein
 * constitutes acknowledgement of and consent to this notice
 */
package com.cotiviti.c2i.utils.property.test;

import static org.junit.Assert.assertEquals;

import java.util.HashMap;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.junit.runners.JUnit4;

import com.cotiviti.c2i.utils.property.C2iConfigProperties;

@RunWith(JUnit4.class)
public class C2iConfigPropertiesTest {

	@Test
	public void configPropertiesTest() {
		C2iConfigProperties c2iConfigProperties = new C2iConfigProperties();
		HashMap<String, Object> props = new HashMap<>();
		props.put("test-key", "test-value");
		props.put("test.id", "test.name");
		HashMap<String, Object> formattedProps = new HashMap<>();
		formattedProps.put("test.key", "test-value");
		formattedProps.put("test.id", "test.name");
		c2iConfigProperties.setProperties(props);
		assertEquals(props, c2iConfigProperties.getProperties());
		assertEquals(formattedProps, c2iConfigProperties.getFormattedProperties());
	}
}
