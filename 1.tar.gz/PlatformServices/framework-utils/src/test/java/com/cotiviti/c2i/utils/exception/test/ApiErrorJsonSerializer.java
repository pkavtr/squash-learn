/**
 * Copyright (C) 2018 Cotiviti Digital (nexgen.admin@cotiviti.io)
 *
 * The software code contained herein is the property of Cotiviti Corporation
 * and its subsidiaries and affiliates (collectively, “Cotiviti”).
 * Access to this software code is being provided to you in the course of your
 * employment or affiliation with Cotiviti and may be used solely in the scope
 * and course of your work for Cotiviti, and is for internal Cotiviti use only.
 * Any unauthorized use, disclosure, copying, distribution, destruction of this
 * software code, or the taking of any unauthorized action in reliance on this
 * software code, is strictly prohibited.
 * If this information is viewed in error, immediately discontinue use of the
 * application.  Anyone using this software code and the applications will be
 * subject to monitoring for improper use, system maintenance and security
 * purposes, and is advised that if such monitoring reveals possible criminal
 * activity or policy violation, Cotiviti personnel may provide the evidence of
 * such monitoring to law enforcement or other officials, and the user may be
 * subject to disciplinary action by Cotiviti, up to and including termination
 * of employment.
 *
 * Use of this software code and any applications and information therein
 * constitutes acknowledgement of and consent to this notice
 */
package com.cotiviti.c2i.utils.exception.test;

import com.fasterxml.jackson.core.JsonGenerator;
import com.fasterxml.jackson.databind.JsonSerializer;
import com.fasterxml.jackson.databind.SerializerProvider;
import org.springframework.validation.FieldError;
import org.springframework.validation.ObjectError;

import java.io.IOException;

public class ApiErrorJsonSerializer extends JsonSerializer<ApiError> {
    @Override
    public void serialize(ApiError apiError, JsonGenerator json, SerializerProvider provider) throws IOException {
        // @formatter:off
        json.writeStartObject();
            json.writeObjectFieldStart("meta");
                json.writeNumberField("code", apiError.getHttpStatusCode());
            json.writeEndObject();

            json.writeObjectFieldStart("error");
                json.writeStringField("message", apiError.getMessage());
                json.writeStringField("code", apiError.getCode());
                json.writeObjectFieldStart("validation");
                    writeGlobalErrors(apiError, json);
                    writeFieldErrors(apiError, json);
                json.writeEndObject();
            json.writeEndObject();
        json.writeEndObject();

        // @formatter:on
    }

    private void writeGlobalErrors(ApiError apiError, JsonGenerator jsonGenerator) throws IOException {
        if (apiError.getGlobalErrors().isEmpty()) {
            return;
        }

        jsonGenerator.writeArrayFieldStart("global");
        for (ObjectError globalError : apiError.getGlobalErrors()) {
            writeGlobaError(jsonGenerator, globalError);
        }
        jsonGenerator.writeEndArray();
    }

    private void writeGlobaError(JsonGenerator jsonGenerator, ObjectError error) throws IOException {
        jsonGenerator.writeStartObject();
        jsonGenerator.writeStringField("code", error.getCode());
        jsonGenerator.writeStringField("message", error.getDefaultMessage());
        jsonGenerator.writeEndObject();
    }


    private void writeFieldErrors(ApiError apiError, JsonGenerator jsonGenerator) throws IOException {
        if (apiError.getFieldErrors().isEmpty()) {
            return;
        }
        jsonGenerator.writeArrayFieldStart("field");
        for (FieldError fieldError : apiError.getFieldErrors()) {
            writeField(jsonGenerator, fieldError);
        }
        jsonGenerator.writeEndArray();
    }


    private void writeField(JsonGenerator jsonGenerator, FieldError fieldError) throws IOException {
        jsonGenerator.writeStartObject();
        jsonGenerator.writeStringField("name", fieldError.getField());
        jsonGenerator.writeStringField("code", fieldError.getCode());
        jsonGenerator.writeStringField("message", fieldError.getDefaultMessage());
        jsonGenerator.writeEndObject();
    }
}