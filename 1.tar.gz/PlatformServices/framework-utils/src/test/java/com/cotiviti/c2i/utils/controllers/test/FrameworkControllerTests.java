/**
 * Copyright (C) 2018 Cotiviti Digital (nexgen.admin@cotiviti.io)
 *
 * The software code contained herein is the property of Cotiviti Corporation
 * and its subsidiaries and affiliates (collectively, “Cotiviti”).
 * Access to this software code is being provided to you in the course of your
 * employment or affiliation with Cotiviti and may be used solely in the scope
 * and course of your work for Cotiviti, and is for internal Cotiviti use only.
 * Any unauthorized use, disclosure, copying, distribution, destruction of this
 * software code, or the taking of any unauthorized action in reliance on this
 * software code, is strictly prohibited.
 * If this information is viewed in error, immediately discontinue use of the
 * application.  Anyone using this software code and the applications will be
 * subject to monitoring for improper use, system maintenance and security
 * purposes, and is advised that if such monitoring reveals possible criminal
 * activity or policy violation, Cotiviti personnel may provide the evidence of
 * such monitoring to law enforcement or other officials, and the user may be
 * subject to disciplinary action by Cotiviti, up to and including termination
 * of employment.
 *
 * Use of this software code and any applications and information therein
 * constitutes acknowledgement of and consent to this notice
 */
package com.cotiviti.c2i.utils.controllers.test;

import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.result.MockMvcResultHandlers.print;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.redirectedUrl;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.view;

import org.junit.Before;
import org.junit.Test;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import org.springframework.web.servlet.view.InternalResourceViewResolver;

import com.cotiviti.c2i.utils.controllers.FrameworkController;

public class FrameworkControllerTests {

	private MockMvc mvc;

	@Before
	public void setup() {
		InternalResourceViewResolver viewResolver = new InternalResourceViewResolver();
		viewResolver.setPrefix("/WEB-INF/jsp/view/");
		viewResolver.setSuffix(".jsp");

		mvc = MockMvcBuilders.standaloneSetup(new FrameworkController()).setViewResolvers(viewResolver).build();
	}

	@Test
	public void homepageTest() throws Exception {
		this.mvc.perform(get("/").accept(MediaType.APPLICATION_JSON)).andDo(print()).andExpect(redirectedUrl("/index"))
				.andExpect(status().is(302));

	}

	@Test
	public void indexTest() throws Exception {
		this.mvc.perform(get("/index").accept(MediaType.APPLICATION_JSON)).andDo(print())
				.andExpect(view().name("index")).andExpect(status().is(200));
	}

	@Test
	public void userIndexTest() throws Exception {
		this.mvc.perform(get("/user/index").accept(MediaType.APPLICATION_JSON)).andDo(print())
				.andExpect(view().name("user/index")).andExpect(status().is(200));
	}

	@Test
	public void loginTest() throws Exception {
		this.mvc.perform(get("/login").accept(MediaType.APPLICATION_JSON)).andDo(print())
				.andExpect(view().name("login")).andExpect(status().is(200));
	}

	@Test
	public void loginErrorTest() throws Exception {
		this.mvc.perform(get("/login-error").accept(MediaType.APPLICATION_JSON)).andDo(print())
				.andExpect(view().name("login")).andExpect(status().is(200));
	}

}
