/**
 * Copyright (C) 2018 Cotiviti Digital (nexgen.admin@cotiviti.io)
 *
 * The software code contained herein is the property of Cotiviti Corporation
 * and its subsidiaries and affiliates (collectively, “Cotiviti”).
 * Access to this software code is being provided to you in the course of your
 * employment or affiliation with Cotiviti and may be used solely in the scope
 * and course of your work for Cotiviti, and is for internal Cotiviti use only.
 * Any unauthorized use, disclosure, copying, distribution, destruction of this
 * software code, or the taking of any unauthorized action in reliance on this
 * software code, is strictly prohibited.
 * If this information is viewed in error, immediately discontinue use of the
 * application.  Anyone using this software code and the applications will be
 * subject to monitoring for improper use, system maintenance and security
 * purposes, and is advised that if such monitoring reveals possible criminal
 * activity or policy violation, Cotiviti personnel may provide the evidence of
 * such monitoring to law enforcement or other officials, and the user may be
 * subject to disciplinary action by Cotiviti, up to and including termination
 * of employment.
 *
 * Use of this software code and any applications and information therein
 * constitutes acknowledgement of and consent to this notice
 */
package com.cotiviti.c2i.utils.configs.test;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertNotNull;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.spy;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.io.IOException;
import java.util.HashMap;
import java.util.Map;

import javax.servlet.FilterChain;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.junit.runners.JUnit4;
import org.mockito.Mockito;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.mock.web.MockFilterChain;
import org.springframework.mock.web.MockFilterConfig;
import org.springframework.mock.web.MockHttpServletRequest;
import org.springframework.mock.web.MockHttpServletResponse;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.authority.AuthorityUtils;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.kerberos.authentication.KerberosAuthenticationProvider;
import org.springframework.security.kerberos.authentication.KerberosServiceAuthenticationProvider;
import org.springframework.security.kerberos.authentication.KerberosServiceRequestToken;
import org.springframework.security.kerberos.authentication.KerberosTicketValidation;
import org.springframework.security.kerberos.authentication.sun.SunJaasKerberosTicketValidator;
import org.springframework.security.kerberos.web.authentication.SpnegoAuthenticationProcessingFilter;
import org.springframework.security.web.authentication.WebAuthenticationDetailsSource;

import com.cotiviti.c2i.utils.configs.C2iConfig;
import com.cotiviti.c2i.utils.configs.C2iConfig.CorsFilter;
import com.cotiviti.c2i.utils.configs.C2iConfig.WebSecurityConfig;
import com.cotiviti.c2i.utils.property.C2iConfigProperties;
import com.cotiviti.c2i.utils.services.DummyUserDetailsService;

import springfox.documentation.spi.DocumentationType;
import springfox.documentation.spring.web.plugins.Docket;

@RunWith(JUnit4.class)
public class C2iConfigUnitTest {

	private static Logger log = LoggerFactory.getLogger(C2iConfigUnitTest.class);
	private Map<String, Object> mockMap = new HashMap<String, Object>();
	private Map<String, Object> docketMockMap = new HashMap<String, Object>();
	private MockHttpServletRequest req;
	private MockHttpServletResponse res;
	private MockFilterConfig filterConfig;
	private MockFilterChain chain;
	private C2iConfig config;
	private CorsFilter filter;
	private WebSecurityConfig websecurityConfig;
	private C2iConfigProperties props;

	@Before
	public void setUp() {
		req = new MockHttpServletRequest();
		res = new MockHttpServletResponse();
		filterConfig = new MockFilterConfig();
		chain = new MockFilterChain();
		config = mock(C2iConfig.class);
		filter = config.new CorsFilter();
		websecurityConfig = config.new WebSecurityConfig();
		props = mock(C2iConfigProperties.class);

		mockMap.put("Allow-Origin", "*");
		mockMap.put("Allow-Methods", "POST, PUT, GET, OPTIONS, DELETE");
		mockMap.put("Allow-Headers", "Authorization, Content-Type");
		mockMap.put("Max-Age", "3600");

		docketMockMap.put("swaggerBasePackage", null);
	}

	@Test
	public void testDoFilter() {
		try {
			Mockito.when(config.corsFilterProperties()).thenReturn(props);
			Mockito.when(props.getProperties()).thenReturn(mockMap);

			filter.init(filterConfig);
			filter.doFilter(req, res, chain);

			/*
			 * log.debug(res.getHeader("Access-Control-Allow-Origin"));
			 * log.debug(res.getHeader("Access-Control-Allow-Methods"));
			 * log.debug(res.getHeader("Access-Control-Allow-Headers"));
			 * log.debug(res.getHeader("Access-Control-Max-Age"));
			 */

			assertEquals(res.getHeader("Access-Control-Allow-Origin"), "*");
			assertEquals(res.getHeader("Access-Control-Allow-Methods"), "POST, PUT, GET, OPTIONS, DELETE");
			assertEquals(res.getHeader("Access-Control-Allow-Headers"), "Authorization, Content-Type");
			assertEquals(res.getHeader("Access-Control-Max-Age"), "3600");
		} catch (Exception exp) {
			log.error("exception has occured" + exp.getMessage());
			assertFalse(true);
		}
	}

	@Test
	public void testDoFilterOptions() {
		try {
			req.setMethod("OPTIONS");

			Mockito.when(config.corsFilterProperties()).thenReturn(props);
			Mockito.when(props.getProperties()).thenReturn(mockMap);

			filter.init(filterConfig);
			filter.doFilter(req, res, chain);
			log.debug("response status info:- " + res.getStatus());
			assertEquals(res.getStatus(), HttpServletResponse.SC_OK);
		} catch (Exception exp) {
			log.error("exception has occured" + exp.getMessage());
			assertFalse(true);
		}
	}

	@Test
	public void testTwoArgumentedDoFilterMethod() throws ServletException, IOException {
		FilterChain chain = mock(FilterChain.class);
		Mockito.when(config.corsFilterProperties()).thenReturn(props);
		Mockito.when(props.getProperties()).thenReturn(mockMap);
		filter.doFilter(req, res, chain);
		verify(chain).doFilter(req, res);
	}

	@Test
	public void testDocketMethod() {
		config = spy(C2iConfig.class);
		Mockito.when(config.webServiceProperties()).thenReturn(props);
		Mockito.when(props.getProperties()).thenReturn(docketMockMap);

		Docket d = config.api();
		log.info("documentation type:- " + d.getDocumentationType());

		assertEquals(DocumentationType.SWAGGER_2, d.getDocumentationType());
	}

	@Test
	public void testCorsFilterProperties() {
		config = spy(C2iConfig.class);
		Mockito.when(config.corsFilterProperties()).thenReturn(props);
		Mockito.when(props.getProperties()).thenReturn(mockMap);
		assertEquals(mockMap.size(), props.getProperties().size());

	}

	@Test
	public void testWebServicesFilterProperties() {
		config = spy(C2iConfig.class);
		Mockito.when(config.webServiceProperties()).thenReturn(props);
		Mockito.when(props.getProperties()).thenReturn(docketMockMap);
		assertEquals(docketMockMap.size(), props.getProperties().size());

	}

	@Test
	public void testKerberosAuthenticationProvider() {
		KerberosAuthenticationProvider provider = websecurityConfig.kerberosAuthenticationProvider();
		log.info("kerberosAuthenticationProvider:- " + provider);
		assertNotNull(provider);
	}

	@Test
	public void testDummyUserDetailsService() {
		DummyUserDetailsService dummyUserDetailsService = websecurityConfig.dummyUserDetailsService();
		UserDetails userDetails = dummyUserDetailsService.loadUserByUsername("hello");
		assertEquals(userDetails.getUsername(), "hello");
		assertEquals(userDetails.getPassword(), "notUsed");

	}

	@Test
	public void testKerberosServiceAuthenticationProvider() {

		mockMap.clear();
		mockMap.put("service-principal", "HTTP/c2iwebservices@COTIVITI.COM");
		mockMap.put("keytab-location", "/Users/kchen/Documents/cotiviti/c2isa.keytab");
		mockMap.put("ignored-security", "/**");

		Mockito.when(config.webServiceProperties()).thenReturn(props);
		Mockito.when(props.getProperties()).thenReturn(mockMap);

		SunJaasKerberosTicketValidator sunJaasKerberosTicketValidator = websecurityConfig
				.sunJaasKerberosTicketValidator();
		log.info("--" + sunJaasKerberosTicketValidator);

		assertNotNull(sunJaasKerberosTicketValidator);

		KerberosServiceAuthenticationProvider kerberosServiceAuthenticationProvider = websecurityConfig
				.kerberosServiceAuthenticationProvider();
		log.info("--" + kerberosServiceAuthenticationProvider);

		assertNotNull(kerberosServiceAuthenticationProvider);

	}

	@Test
	public void testEntryPointOk() throws Exception {

		websecurityConfig.spnegoEntryPoint().commence(req, res, null);
		assertEquals(res.getHeader("WWW-Authenticate"), "Negotiate");
		assertEquals(res.getStatus(), HttpServletResponse.SC_UNAUTHORIZED);

	}

	@Test
	public void testKerberosAuthentication() throws IOException, ServletException {
		HttpServletRequest request = mock(HttpServletRequest.class);
		HttpServletResponse response = mock(HttpServletResponse.class);
		String HEADER = "Authorization";
		String TEST_TOKEN_BASE64 = "VGVzdFRva2Vu";
		String TOKEN_PREFIX_KERB = "Kerberos ";
		byte[] TEST_TOKEN = "TestToken".getBytes();
		FilterChain chain = mock(FilterChain.class);

		KerberosTicketValidation ticketValid = mock(KerberosTicketValidation.class);
		AuthenticationManager authenticationManager = mock(AuthenticationManager.class);
		WebAuthenticationDetailsSource detailsSource = new WebAuthenticationDetailsSource();

		Authentication authentication = new KerberosServiceRequestToken("test", ticketValid,
				AuthorityUtils.createAuthorityList("ROLE_ADMIN"), TEST_TOKEN);

		SpnegoAuthenticationProcessingFilter filter = new SpnegoAuthenticationProcessingFilter();
		filter.setAuthenticationManager(authenticationManager);
		when(request.getHeader(HEADER)).thenReturn(TOKEN_PREFIX_KERB + TEST_TOKEN_BASE64);
		KerberosServiceRequestToken requestToken = new KerberosServiceRequestToken(TEST_TOKEN);
		requestToken.setDetails(detailsSource.buildDetails(request));
		when(authenticationManager.authenticate(requestToken)).thenReturn(authentication);
		filter.doFilter(request, response, chain);
		verify(chain).doFilter(request, response);
		assertEquals(authentication, SecurityContextHolder.getContext().getAuthentication());
	}

}
