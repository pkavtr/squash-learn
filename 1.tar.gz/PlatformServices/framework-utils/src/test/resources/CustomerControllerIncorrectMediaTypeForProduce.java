import com.cotiviti.c2i.utils.annotations.C2iApiFormat;
import com.cotiviti.c2i.utils.annotations.C2iRestController;

import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseStatus;

@C2iRestController
@C2iApiFormat
public class CustomerControllerIncorrectMediaTypeForProduce {	
    public CustomerControllerIncorrectMediaTypeForProduce() {
    }

    // API - read
    @RequestMapping(method = RequestMethod.GET, value= {"/v1/customers/{id}"}, consumes="application/json", produces="application/jayson")
    public void findById(@PathVariable final long id) {
        return ;
    }
}