/**
 * Copyright (C) 2018 Cotiviti Digital (nexgen.admin@cotiviti.io)
 *
 * The software code contained herein is the property of Cotiviti Corporation
 * and its subsidiaries and affiliates (collectively, “Cotiviti”).
 * Access to this software code is being provided to you in the course of your
 * employment or affiliation with Cotiviti and may be used solely in the scope
 * and course of your work for Cotiviti, and is for internal Cotiviti use only.
 * Any unauthorized use, disclosure, copying, distribution, destruction of this
 * software code, or the taking of any unauthorized action in reliance on this
 * software code, is strictly prohibited.
 * If this information is viewed in error, immediately discontinue use of the
 * application.  Anyone using this software code and the applications will be
 * subject to monitoring for improper use, system maintenance and security
 * purposes, and is advised that if such monitoring reveals possible criminal
 * activity or policy violation, Cotiviti personnel may provide the evidence of
 * such monitoring to law enforcement or other officials, and the user may be
 * subject to disciplinary action by Cotiviti, up to and including termination
 * of employment.
 *
 * Use of this software code and any applications and information therein
 * constitutes acknowledgement of and consent to this notice
 */
package com.cotiviti.c2i.utils.processors;

import org.springframework.beans.BeansException;
import org.springframework.beans.factory.config.BeanPostProcessor;
import org.springframework.web.method.support.HandlerMethodArgumentResolver;
import org.springframework.web.servlet.mvc.method.annotation.RequestMappingHandlerAdapter;
import org.springframework.web.servlet.mvc.method.annotation.RequestResponseBodyMethodProcessor;

import java.util.ArrayList;
import java.util.List;

/**
 * Registers <code>{@link C2iJsonRequestBodyArgumentResolver}</code>
 * to <code>{@link RequestMappingHandlerAdapter}</code>
 * to the proper place.
 * <p>
 *     Since {@link C2iJsonRequestBodyArgumentResolver} depends
 *     on the Jackson <code>@RequestBody</code>
 *     argument resolver, we need to register this validating
 *     argument resolver <i>after</i> the regular resolver.
 * </p>
 * <p>
 *     Since default argument resolvers (including {@link RequestResponseBodyMethodProcessor})
 *     are not beans, the proper order of initialization
 *     is supported by using this {@link BeanPostProcessor}.
 * </p>
 */
public class C2iJsonRequestBodyArgumentResolverRegisteringBeanPostProcessor implements BeanPostProcessor {

	/**
     * Registers the JSON validating argument after {@link HandlerMethodArgumentResolver}.
     * @return the same bean, unchanged, unless it is {@link RequestMappingHandlerAdapter}.
     */
    @Override
    public Object postProcessAfterInitialization(Object bean, String beanName) throws BeansException {
        if (bean instanceof RequestMappingHandlerAdapter) {
            RequestMappingHandlerAdapter handlerAdapter = (RequestMappingHandlerAdapter) bean;
            List<HandlerMethodArgumentResolver> argumentResolvers = handlerAdapter.getArgumentResolvers();
            List<HandlerMethodArgumentResolver> extendedArgumentResolverList = new ArrayList<>(argumentResolvers);
            for (int i = 0; i < argumentResolvers.size(); i++) {
                HandlerMethodArgumentResolver argumentResolver = argumentResolvers.get(i);
                if (argumentResolver instanceof RequestResponseBodyMethodProcessor) {
                	C2iJsonRequestBodyArgumentResolver jsonRequestBodyArgumentResolver = new C2iJsonRequestBodyArgumentResolver();
                    extendedArgumentResolverList.add(i + 1, jsonRequestBodyArgumentResolver);
                    break;
                }
            }
            handlerAdapter.setArgumentResolvers(extendedArgumentResolverList);
        }
        return bean;
    }

    /**
     * Do not process beans in any special way before initialization.
     */
    @Override
    public Object postProcessBeforeInitialization(Object bean, String beanName) throws BeansException {
        return bean;
    }
}
