/**
 * Copyright (C) 2018 Cotiviti Digital (nexgen.admin@cotiviti.io)
 *
 * The software code contained herein is the property of Cotiviti Corporation
 * and its subsidiaries and affiliates (collectively, “Cotiviti”).
 * Access to this software code is being provided to you in the course of your
 * employment or affiliation with Cotiviti and may be used solely in the scope
 * and course of your work for Cotiviti, and is for internal Cotiviti use only.
 * Any unauthorized use, disclosure, copying, distribution, destruction of this
 * software code, or the taking of any unauthorized action in reliance on this
 * software code, is strictly prohibited.
 * If this information is viewed in error, immediately discontinue use of the
 * application.  Anyone using this software code and the applications will be
 * subject to monitoring for improper use, system maintenance and security
 * purposes, and is advised that if such monitoring reveals possible criminal
 * activity or policy violation, Cotiviti personnel may provide the evidence of
 * such monitoring to law enforcement or other officials, and the user may be
 * subject to disciplinary action by Cotiviti, up to and including termination
 * of employment.
 *
 * Use of this software code and any applications and information therein
 * constitutes acknowledgement of and consent to this notice
 */
package com.cotiviti.c2i.integration.service;

import java.io.File;
import java.io.IOException;
import java.util.List;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import org.springframework.stereotype.Service;
import org.springframework.util.ResourceUtils;

import com.cotiviti.c2i.integration.model.RootObject;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;

@Service
public class ComplexJSONObjectService {
	
	private final Logger logger = LoggerFactory.getLogger(this.getClass());

	public RootObject readJsonWithObjectMapper() throws IOException {
		ObjectMapper objectMapper = new ObjectMapper();
		RootObject rootPojo = objectMapper.readValue(
				ResourceUtils.getFile("classpath:CPQJSON.json"), RootObject.class);
		logger.info(rootPojo.toString());
		System.out.println(rootPojo.toString());
		return rootPojo;
	}

	public List<RootObject> readJsonWithObjectMapperList() throws IOException {
		ObjectMapper objectMapper = new ObjectMapper();
		List<RootObject> oParentPojos = objectMapper.readValue(
				ResourceUtils.getFile("classpath:CPQJSONList.json"),
					new TypeReference<List<RootObject>>() {
					});
		logger.info(oParentPojos.toString());
		System.out.println(oParentPojos.toString());
		return oParentPojos;
	}
}
