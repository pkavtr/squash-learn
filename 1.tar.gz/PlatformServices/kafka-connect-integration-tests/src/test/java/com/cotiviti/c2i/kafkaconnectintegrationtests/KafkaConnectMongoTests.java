/*******************************************************************************
 * Copyright (C) 2018 Cotiviti Digital (nexgen.admin@cotiviti.io)
 * 
 * The software code contained herein is the property of Cotiviti Corporation
 * and its subsidiaries and affiliates (collectively, “Cotiviti”).
 * Access to this software code is being provided to you in the course of your
 * employment or affiliation with Cotiviti and may be used solely in the scope
 * and course of your work for Cotiviti, and is for internal Cotiviti use only.
 * Any unauthorized use, disclosure, copying, distribution, destruction of this
 * software code, or the taking of any unauthorized action in reliance on this
 * software code, is strictly prohibited.
 * If this information is viewed in error, immediately discontinue use of the
 * application.  Anyone using this software code and the applications will be
 * subject to monitoring for improper use, system maintenance and security
 * purposes, and is advised that if such monitoring reveals possible criminal
 * activity or policy violation, Cotiviti personnel may provide the evidence of
 * such monitoring to law enforcement or other officials, and the user may be
 * subject to disciplinary action by Cotiviti, up to and including termination
 * of employment.
 * 
 * Use of this software code and any applications and information therein
 * constitutes acknowledgement of and consent to this notice
 ******************************************************************************/
package com.cotiviti.c2i.kafkaconnectintegrationtests;
import static org.assertj.core.api.Assertions.*;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;

import java.util.List;
import java.util.concurrent.ExecutionException;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

import com.cotiviti.c2i.kafkaconnectintegrationtests.model.C2iJsonClient;
import com.cotiviti.c2i.kafkaconnectintegrationtests.model.Mongo.MongoSinkModel;
import com.cotiviti.c2i.kafkaconnectintegrationtests.model.Mongo.MongoSourceModel;
import com.cotiviti.c2i.kafkaconnectintegrationtests.repository.Mongo.MongoSinkRepository;
import com.cotiviti.c2i.kafkaconnectintegrationtests.repository.Mongo.MongoSourceRepository;
import com.cotiviti.c2i.kafkaconnectintegrationtests.service.C2iKafkaService;

/**
 * 
 * @author Swapnika
 *
 */
@RunWith(SpringRunner.class)
@SpringBootTest
public class KafkaConnectMongoTests {

    @Autowired
    MongoSourceRepository sourcerepository;

    @Autowired 
    MongoSinkRepository sinkrepository;

	@Autowired
	private C2iKafkaService kafkaservice;
	
	private static Logger log = LoggerFactory.getLogger(KafkaConnectMongoTests.class);
	/**
	 * Method to test if saving to source collection in mongodb database "sourcedb" 
	 * To test manually
	 * In mongo console use the following commands 
	 *  "use sourcedb"
	 *  "db.source.find();"
	 */
    @Test
    public void sourcedbSaveTest() {
    	MongoSourceModel testrecord = new MongoSourceModel("sourcedbsavetest"); 
    	sourcerepository.save(testrecord);
        assertThat(testrecord.id).isNotNull();
    }
    /**
     * Method to test if saving to sink collection in mongodb database "sourcedb" 
     * To test manually
     * In mongo console use the following commands 
     *  "use sourcedb"
     *  "db.sink.find();"
     */   
    @Test
    public void sinkdbSaveTest() {
    	MongoSinkModel testrecord = new MongoSinkModel("sinkdbsavetest");
    	sinkrepository.save(testrecord);
        assertThat(testrecord.id).isNotNull();
    }

    /**
     * Test to check the "findByName" method
     */
    @Test
    public void sinkdbfindTest() {
    	MongoSinkModel testrecord = new MongoSinkModel("sinkdbfindtest");  
    	sinkrepository.save(testrecord);
    	List<MongoSinkModel> testrecord1=sinkrepository.findByName("sinkdbfindtest");
    	assertThat(testrecord1.get(0).id).isNotNull();
    }
    /**
     * For this test to work the c2i-mongodb-source-template.json should be running 
     * 
     * Method to check if the data from collection "source" of sourcedb database is read into kafka topic "c2i_sourcedb_source"
     * @throws InterruptedException
     */
	@Test
	public void mongoSourceTest() throws InterruptedException {
	    MongoSourceModel testrecord = new MongoSourceModel("mongosourcetest");
		sourcerepository.save(testrecord);
	  	Thread.sleep(5000);
	  	try {
	  	List<String> testrecords = kafkaservice.consumes();
		String testrecord1=testrecords.get(testrecords.size()-1);
		int si=testrecord1.indexOf("\"myid\"");
		int ei=testrecord1.indexOf("\"_class\"");
		String actualrecord=testrecord1.substring(si+10, ei-3);
		assertEquals(testrecords.isEmpty(),false);
		assertEquals(actualrecord,"mongosourcetest");
	  	}
	  	catch(Exception ex)
	  	{
	  		log.error("Exception has occurred while running test mongoSourceTest. " + "Exception message is "
					+ ex.getMessage());
			assertFalse(true);
	  	}
	}
    /**
     * For this test to work the c2i-mongodb-sink-template.json should be running 
     * 
     * Method to check if the data from topic "sinkconnect" of sourcedb database is loaded into "sink" collection of "sourcedb" 
     * @throws InterruptedException
     */
	@Test
	public void mongoSinkTest() throws InterruptedException, ExecutionException  {
		C2iJsonClient client = new C2iJsonClient(1, "mongosinktest");
		kafkaservice.produce(client);
		Thread.sleep(5000);
		try {
	    List<MongoSinkModel> records=sinkrepository.findByName("mongosinktest");
	    assertThat(records.get(0).name).isNotNull();
	    }
		catch(Exception ex)
		{
			log.error("Exception has occurred while running test mongoSinkTest. " + "Exception message is "
					+ ex.getMessage());
			assertFalse(true);
		}
		
		
	
		
	}
	

}
