/*******************************************************************************
 * Copyright (C) 2018 Cotiviti Digital (nexgen.admin@cotiviti.io)
 * 
 * The software code contained herein is the property of Cotiviti Corporation
 * and its subsidiaries and affiliates (collectively, “Cotiviti”).
 * Access to this software code is being provided to you in the course of your
 * employment or affiliation with Cotiviti and may be used solely in the scope
 * and course of your work for Cotiviti, and is for internal Cotiviti use only.
 * Any unauthorized use, disclosure, copying, distribution, destruction of this
 * software code, or the taking of any unauthorized action in reliance on this
 * software code, is strictly prohibited.
 * If this information is viewed in error, immediately discontinue use of the
 * application.  Anyone using this software code and the applications will be
 * subject to monitoring for improper use, system maintenance and security
 * purposes, and is advised that if such monitoring reveals possible criminal
 * activity or policy violation, Cotiviti personnel may provide the evidence of
 * such monitoring to law enforcement or other officials, and the user may be
 * subject to disciplinary action by Cotiviti, up to and including termination
 * of employment.
 * 
 * Use of this software code and any applications and information therein
 * constitutes acknowledgement of and consent to this notice
 ******************************************************************************/
package com.cotiviti.c2i.kafkaconnectintegrationtests.service;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import com.cotiviti.c2i.kafkaconnectintegrationtests.model.C2iJsonClient;

@Service
public class C2iFileService {

	@Value("${file.sink.path}")
	private String FILE_SINK_PATH;

	@Value("${file.source.path}")
	private String FILE_SOURCE_PATH;

	private static Logger log = LoggerFactory.getLogger(C2iFileService.class);

	public String getLastRecordFromFile() {
		log.debug("entered getLastRecordFromFile of FileService method");
		String lastLine = "";
		String currentLine = "";
		try {
			BufferedReader br = new BufferedReader(new FileReader(FILE_SINK_PATH));
			while ((currentLine = br.readLine()) != null) {

				lastLine = currentLine;
			}
			br.close();
		} catch (IOException exception) {

			log.error("IOException occured. Cause is ", exception.getMessage());
		}
		return lastLine;
	}

	public String getExpectedRecord(C2iJsonClient record) {
		return "Struct{name=" + record.getName() + ",id=" + record.getId() + "}";

	}

	public void writeToFileSource(String record) throws IOException, InterruptedException {
		log.debug("writing record to file source");
		FileWriter fileWriter = new FileWriter(FILE_SOURCE_PATH, true);
		PrintWriter printWriter = new PrintWriter(fileWriter);
		printWriter.println(record);
		Thread.sleep(2000);
		printWriter.flush();
		printWriter.close();
	}
}
