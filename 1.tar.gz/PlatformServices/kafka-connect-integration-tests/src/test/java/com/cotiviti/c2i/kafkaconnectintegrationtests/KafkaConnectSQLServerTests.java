/*******************************************************************************
 * Copyright (C) 2018 Cotiviti Digital (nexgen.admin@cotiviti.io)
 * 
 * The software code contained herein is the property of Cotiviti Corporation
 * and its subsidiaries and affiliates (collectively, “Cotiviti”).
 * Access to this software code is being provided to you in the course of your
 * employment or affiliation with Cotiviti and may be used solely in the scope
 * and course of your work for Cotiviti, and is for internal Cotiviti use only.
 * Any unauthorized use, disclosure, copying, distribution, destruction of this
 * software code, or the taking of any unauthorized action in reliance on this
 * software code, is strictly prohibited.
 * If this information is viewed in error, immediately discontinue use of the
 * application.  Anyone using this software code and the applications will be
 * subject to monitoring for improper use, system maintenance and security
 * purposes, and is advised that if such monitoring reveals possible criminal
 * activity or policy violation, Cotiviti personnel may provide the evidence of
 * such monitoring to law enforcement or other officials, and the user may be
 * subject to disciplinary action by Cotiviti, up to and including termination
 * of employment.
 * 
 * Use of this software code and any applications and information therein
 * constitutes acknowledgement of and consent to this notice
 ******************************************************************************/
package com.cotiviti.c2i.kafkaconnectintegrationtests;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;

import java.util.List;
import java.util.concurrent.ExecutionException;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.context.SpringBootTest.WebEnvironment;
import org.springframework.boot.web.server.LocalServerPort;
import org.springframework.test.context.junit4.SpringRunner;

import com.cotiviti.c2i.kafkaconnectintegrationtests.config.DatabaseContextHolder;
import com.cotiviti.c2i.kafkaconnectintegrationtests.config.DatabaseEnvironment;
import com.cotiviti.c2i.kafkaconnectintegrationtests.model.C2iJsonClient;
import com.cotiviti.c2i.kafkaconnectintegrationtests.model.SinkModel;
import com.cotiviti.c2i.kafkaconnectintegrationtests.model.SourceModel;
import com.cotiviti.c2i.kafkaconnectintegrationtests.repository.SinkRepo;
import com.cotiviti.c2i.kafkaconnectintegrationtests.repository.SourceRepo;
import com.cotiviti.c2i.kafkaconnectintegrationtests.service.C2iKafkaService;

@RunWith(SpringRunner.class)
@SpringBootTest(webEnvironment = WebEnvironment.RANDOM_PORT)
public class KafkaConnectSQLServerTests {
	@LocalServerPort
	private int port;

	@Autowired
	private C2iKafkaService ks;

	@Autowired
	private SourceRepo sqlServerRepo;

	@Autowired
	private SinkRepo sqlSinkRepo;

	private static Logger log = LoggerFactory.getLogger(KafkaConnectSQLServerTests.class);

	/**
	 * To test the c2i-mssql-source template
	 * 
	 * @throws InterruptedException
	 */
	@Test
	public void msSqlSourceTest() throws InterruptedException {
		try {
			DatabaseContextHolder.set(DatabaseEnvironment.MSSQL);
			SourceModel sample = new SourceModel(1, "mssqlsourcetest");
			sqlServerRepo.save(sample);

			Thread.sleep(3000);
			List<String> clients = ks.consume();
			if (clients.size() == 0) {
				clients = ks.consume();
			}
			int len = clients.size();
			String name = clients.get(len - 1);
			assertEquals(ks.jsonToStruct(new C2iJsonClient(sample.getId(), sample.getName())), name);

		} catch (Exception ex) {
			log.error("Exception has occurred while running test msSqlSourceTest. " + "Exception message is "
					+ ex.getMessage());
			assertFalse(true);
		}
	}

	/**
	 * To test the c2i-mssql-sink template
	 * 
	 * @throws InterruptedException
	 * @throws ExecutionException
	 */
	@Test
	public void msSqlSinkTest() throws InterruptedException, ExecutionException {
		try {
			DatabaseContextHolder.set(DatabaseEnvironment.MSSQL);
			C2iJsonClient client = new C2iJsonClient(2, "msssqlsinktest");
			ks.produce(client);
			Thread.sleep(1000);

			List<SinkModel> dbModels = sqlSinkRepo.findByName(client.getName());
			for (SinkModel dbModel : dbModels) {
				log.info(dbModel.getName() + " " + dbModel.getId());
			}
			assertEquals(dbModels.isEmpty(), false);

		} catch (Exception ex) {
			log.error("Exception has occurred while running test msSqlSourceTest. " + "Exception message is "
					+ ex.getMessage());
			assertFalse(true);
		}
	}

}
