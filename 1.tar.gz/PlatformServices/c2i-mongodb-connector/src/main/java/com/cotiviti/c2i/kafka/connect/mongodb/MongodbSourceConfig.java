/**
 * Copyright (C) 2018 Cotiviti Digital (nexgen.admin@cotiviti.io)
 *
 * The software code contained herein is the property of Cotiviti Corporation
 * and its subsidiaries and affiliates (collectively, “Cotiviti”).
 * Access to this software code is being provided to you in the course of your
 * employment or affiliation with Cotiviti and may be used solely in the scope
 * and course of your work for Cotiviti, and is for internal Cotiviti use only.
 * Any unauthorized use, disclosure, copying, distribution, destruction of this
 * software code, or the taking of any unauthorized action in reliance on this
 * software code, is strictly prohibited.
 * If this information is viewed in error, immediately discontinue use of the
 * application.  Anyone using this software code and the applications will be
 * subject to monitoring for improper use, system maintenance and security
 * purposes, and is advised that if such monitoring reveals possible criminal
 * activity or policy violation, Cotiviti personnel may provide the evidence of
 * such monitoring to law enforcement or other officials, and the user may be
 * subject to disciplinary action by Cotiviti, up to and including termination
 * of employment.
 *
 * Use of this software code and any applications and information therein
 * constitutes acknowledgement of and consent to this notice
 */
package com.cotiviti.c2i.kafka.connect.mongodb;

import org.apache.kafka.common.config.AbstractConfig;
import org.apache.kafka.common.config.ConfigDef;
import org.apache.kafka.common.config.ConfigDef.Type;

import com.cotiviti.c2i.kafka.connect.mongodb.converter.StringStructConverter;

import org.apache.kafka.common.config.ConfigDef.Importance;

import java.util.Map;

/**
 * Config variables for Mongodb source connector
 * 
 * @author kchen
 */
public class MongodbSourceConfig extends AbstractConfig {
    public static final String HOST = "host";
    private static final String HOST_DOC = "Host url of mongodb";
    public static final String PORT = "port";
    private static final String PORT_DOC = "Port of mongodb";
    public static final String URI = "uri";
    private static final String URI_DOC = "uri of mongodb";
    public static final String BATCH_SIZE = "batch.size";
    private static final String BATCH_SIZE_DOC = "Count of documents in each polling";
    public static final String SCHEMA_NAME = "schema.name";
    private static final String SCHEMA_NAME_DOC = "Schema name";
    public static final String TOPIC_PREFIX = "topic.prefix";
    private static final String TOPIC_PREFIX_DOC = "Prefix of each topic, final topic will be prefix_db_collection";
    public static final String DATABASES = "databases";
    private static final String DATABASES_DOC = "Databases, join database and collection with dot, split different databases with comma";
    public static final String CONVERTER_CLASS = "converter.class";
    private static final String CONVERTER_CLASS_DOC = "Converter class used to transform a mongodb oplog in a kafka message";

    public static ConfigDef config = new ConfigDef()
            .define(URI, Type.STRING, Importance.HIGH, URI_DOC)
            .define(HOST, Type.STRING, Importance.HIGH, HOST_DOC)
            .define(PORT, Type.INT, Importance.HIGH, PORT_DOC)
            .define(BATCH_SIZE, Type.INT, Importance.HIGH, BATCH_SIZE_DOC)
            .define(SCHEMA_NAME, Type.STRING, Importance.HIGH, SCHEMA_NAME_DOC)
            .define(TOPIC_PREFIX, Type.STRING, Importance.LOW, TOPIC_PREFIX_DOC)
            .define(CONVERTER_CLASS, Type.STRING, StringStructConverter.class.getName(), Importance.LOW, CONVERTER_CLASS_DOC)
            .define(DATABASES, Type.STRING, Importance.LOW, DATABASES_DOC);

    public MongodbSourceConfig(Map<String, String> props) {
        super(config, props);
    }
}
