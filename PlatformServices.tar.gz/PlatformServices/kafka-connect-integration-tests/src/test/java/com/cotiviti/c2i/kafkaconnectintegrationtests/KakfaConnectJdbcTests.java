/*******************************************************************************
 * Copyright (C) 2018 Cotiviti Digital (nexgen.admin@cotiviti.io)
 * 
 * The software code contained herein is the property of Cotiviti Corporation
 * and its subsidiaries and affiliates (collectively, “Cotiviti”).
 * Access to this software code is being provided to you in the course of your
 * employment or affiliation with Cotiviti and may be used solely in the scope
 * and course of your work for Cotiviti, and is for internal Cotiviti use only.
 * Any unauthorized use, disclosure, copying, distribution, destruction of this
 * software code, or the taking of any unauthorized action in reliance on this
 * software code, is strictly prohibited.
 * If this information is viewed in error, immediately discontinue use of the
 * application.  Anyone using this software code and the applications will be
 * subject to monitoring for improper use, system maintenance and security
 * purposes, and is advised that if such monitoring reveals possible criminal
 * activity or policy violation, Cotiviti personnel may provide the evidence of
 * such monitoring to law enforcement or other officials, and the user may be
 * subject to disciplinary action by Cotiviti, up to and including termination
 * of employment.
 * 
 * Use of this software code and any applications and information therein
 * constitutes acknowledgement of and consent to this notice
 ******************************************************************************/
package com.cotiviti.c2i.kafkaconnectintegrationtests;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;

import java.util.List;

import org.apache.kafka.clients.consumer.Consumer;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.context.SpringBootTest.WebEnvironment;
import org.springframework.test.context.junit4.SpringRunner;

import com.cotiviti.c2i.kafkaconnectintegrationtests.config.DatabaseContextHolder;
import com.cotiviti.c2i.kafkaconnectintegrationtests.config.DatabaseEnvironment;
import com.cotiviti.c2i.kafkaconnectintegrationtests.model.C2iJsonClient;
import com.cotiviti.c2i.kafkaconnectintegrationtests.model.SinkModel;
import com.cotiviti.c2i.kafkaconnectintegrationtests.model.SourceModel;
import com.cotiviti.c2i.kafkaconnectintegrationtests.repository.SinkRepo;
import com.cotiviti.c2i.kafkaconnectintegrationtests.repository.SourceRepo;
import com.cotiviti.c2i.kafkaconnectintegrationtests.service.C2iKafkaService;

/**
 * 
 * @author vishnu
 *
 */
@RunWith(SpringRunner.class)
@SpringBootTest(webEnvironment = WebEnvironment.RANDOM_PORT)
public class KakfaConnectJdbcTests {
	@Autowired
	private SourceRepo mySQLRepository;

	@Autowired
	private SinkRepo mySQLSinkRepository;

	@Autowired
	private C2iKafkaService ks;

	private static Logger log = LoggerFactory.getLogger(KakfaConnectJdbcTests.class);

	/**
	 * To test the JDBC sink connector
	 */
	@Test
	public void testJdbcSink() {
		try {
			DatabaseContextHolder.set(DatabaseEnvironment.MYSQL);
			// log.info("-------------------testing testJDBCSink----------------");
			log.info("-------------------testing JDBC_SINK----------------");
			C2iJsonClient inputClient = new C2iJsonClient(1159, "JDBC_SINK_TEST");
			ks.produce(inputClient);

			Thread.sleep(1000);

			SinkModel outputClient = mySQLSinkRepository.findById(inputClient.getId());
			log.info("MYSQL SINK TEST " + outputClient.toString());
			assertEquals(outputClient.getName(), inputClient.getName());
			assertEquals(outputClient.getId(), inputClient.getId());
		} catch (Exception ex) {
			log.error("Exception has occurred while running test testJdbcSink. " + "Exception message is"
					+ ex.getMessage());
			assertFalse(true);
		}
	}

	/**
	 * To test the JDBC source connector
	 * 
	 * @throws InterruptedException
	 */
	@Test
	public void testJdbcSource() throws InterruptedException {

		try {
			DatabaseContextHolder.set(DatabaseEnvironment.MYSQL);
			log.info("-------------------testing JDBC_SOURCETest----------------");
			SourceModel record = new SourceModel(1024, "JDBC_SOURCE_TEST");
			mySQLRepository.save(record);
			Thread.sleep(5000);

			List<String> records = ks.consume();
			int len = records.size();
			if (len == 0) {
				records = ks.consume();
				len = records.size();
			}
			assertEquals(records.get(len - 1), ks.jsonToStruct(new C2iJsonClient(record.getId(), record.getName())));
		} catch (Exception ex) {
			log.error("Exception has occurred while running test jdbcSourceTest. " + "Exception message is "
					+ ex.getMessage());
			assertFalse(true);
		}

	}
}
