/*******************************************************************************
 * Copyright (C) 2018 Cotiviti Digital (nexgen.admin@cotiviti.io)
 * 
 * The software code contained herein is the property of Cotiviti Corporation
 * and its subsidiaries and affiliates (collectively, “Cotiviti”).
 * Access to this software code is being provided to you in the course of your
 * employment or affiliation with Cotiviti and may be used solely in the scope
 * and course of your work for Cotiviti, and is for internal Cotiviti use only.
 * Any unauthorized use, disclosure, copying, distribution, destruction of this
 * software code, or the taking of any unauthorized action in reliance on this
 * software code, is strictly prohibited.
 * If this information is viewed in error, immediately discontinue use of the
 * application.  Anyone using this software code and the applications will be
 * subject to monitoring for improper use, system maintenance and security
 * purposes, and is advised that if such monitoring reveals possible criminal
 * activity or policy violation, Cotiviti personnel may provide the evidence of
 * such monitoring to law enforcement or other officials, and the user may be
 * subject to disciplinary action by Cotiviti, up to and including termination
 * of employment.
 * 
 * Use of this software code and any applications and information therein
 * constitutes acknowledgement of and consent to this notice
 ******************************************************************************/
package com.cotiviti.c2i.kafkaconnectintegrationtests;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;

import java.util.List;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.context.SpringBootTest.WebEnvironment;
import org.springframework.test.context.junit4.SpringRunner;

import com.cotiviti.c2i.kafkaconnectintegrationtests.model.C2iJsonClient;
import com.cotiviti.c2i.kafkaconnectintegrationtests.service.C2iFileService;
import com.cotiviti.c2i.kafkaconnectintegrationtests.service.C2iKafkaService;

/**
 * 
 * @author vishnu
 *
 */
@RunWith(SpringRunner.class)
@SpringBootTest(webEnvironment = WebEnvironment.RANDOM_PORT)
public class KafkaConnectFileTests {
	private static Logger log = LoggerFactory.getLogger(KafkaConnectFileTests.class);
	@Autowired
	private C2iFileService fileService;

	@Autowired
	private C2iKafkaService kafkaService;

	/**
	 * To test the file sink connector
	 */
	@Test
	public void testFileSink() {
		try {
			C2iJsonClient inputClient = new C2iJsonClient(12, "FILE_SINK_TEST");
			kafkaService.produce(inputClient);
			Thread.sleep(2000);
			String sinkedRecord = fileService.getLastRecordFromFile();
			log.info("last record from file:: " + sinkedRecord);
			String expectedSinkedRecord = fileService.getExpectedRecord(inputClient);
			log.info("expected sinked record :: " + expectedSinkedRecord);
			assertEquals(sinkedRecord, expectedSinkedRecord);
		} catch (Exception ex) {
			log.error("Exception has occurred while running test testFileSink. " + "Exception message is "
					+ ex.getMessage());
			assertFalse(true);
		}
	}

	/**
	 * To test the file source connector
	 */
	@Test
	public void testFileSource() {
		try {
			C2iJsonClient input = new C2iJsonClient(22, "FILE_SOURCE_TEST");
			String inputRecord = fileService.getExpectedRecord(input);
			fileService.writeToFileSource(inputRecord);
			Thread.sleep(2000);
			List<String> records = kafkaService.consume();
			if (records.size() == 0) {
				fileService.writeToFileSource(inputRecord);
				log.info("IN IF CONDITION");
				records = kafkaService.consume();
			}
			int size = records.size();
			String outputRecord = records.get(size - 1);
			assertEquals(inputRecord, outputRecord);
		} catch (Exception ex) {
			log.error("Exception has occurred while running test testFileSource. " + "Exception message is "
					+ ex.getMessage());
			assertFalse(true);
		}
	}

}
