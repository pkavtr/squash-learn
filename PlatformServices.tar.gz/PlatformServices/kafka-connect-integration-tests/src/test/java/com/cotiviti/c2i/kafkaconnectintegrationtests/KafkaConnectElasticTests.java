/*******************************************************************************
 * Copyright (C) 2018 Cotiviti Digital (nexgen.admin@cotiviti.io)
 * 
 * The software code contained herein is the property of Cotiviti Corporation
 * and its subsidiaries and affiliates (collectively, “Cotiviti”).
 * Access to this software code is being provided to you in the course of your
 * employment or affiliation with Cotiviti and may be used solely in the scope
 * and course of your work for Cotiviti, and is for internal Cotiviti use only.
 * Any unauthorized use, disclosure, copying, distribution, destruction of this
 * software code, or the taking of any unauthorized action in reliance on this
 * software code, is strictly prohibited.
 * If this information is viewed in error, immediately discontinue use of the
 * application.  Anyone using this software code and the applications will be
 * subject to monitoring for improper use, system maintenance and security
 * purposes, and is advised that if such monitoring reveals possible criminal
 * activity or policy violation, Cotiviti personnel may provide the evidence of
 * such monitoring to law enforcement or other officials, and the user may be
 * subject to disciplinary action by Cotiviti, up to and including termination
 * of employment.
 * 
 * Use of this software code and any applications and information therein
 * constitutes acknowledgement of and consent to this notice
 ******************************************************************************/
package com.cotiviti.c2i.kafkaconnectintegrationtests;

import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.context.SpringBootTest.WebEnvironment;
import org.springframework.boot.test.web.client.TestRestTemplate;
import org.springframework.boot.web.server.LocalServerPort;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.test.context.junit4.SpringRunner;

import com.cotiviti.c2i.kafkaconnectintegrationtests.model.C2iJsonClient;
import com.cotiviti.c2i.kafkaconnectintegrationtests.service.C2iKafkaService;

@RunWith(SpringRunner.class)
@SpringBootTest(webEnvironment = WebEnvironment.RANDOM_PORT)
public class KafkaConnectElasticTests {

	@LocalServerPort
	private int port;

	@Autowired
	private C2iKafkaService ks;

	@Value("${elastic.url}")
	private String elasticURL;

	@Value("${elastic.port}")
	private String elasticPort;

	private TestRestTemplate template = new TestRestTemplate();

	private static Logger log = LoggerFactory.getLogger(KafkaConnectSQLServerTests.class);

	@Test
	public void elasticSinkTest() {

		try {
			log.info("inside elasticSinkTest");
			C2iJsonClient client = new C2iJsonClient(1, "elasticsinktest");
			ks.produce(client);
			Thread.sleep(1000);

			HttpHeaders headers = new HttpHeaders();
			HttpEntity<String> entity = new HttpEntity<String>(headers);

			String url = elasticURL + "/sinkconnect/_search?q=name:" + client.getName();
			ResponseEntity<String> resp = template.exchange(url, HttpMethod.GET, entity, String.class, elasticPort);
			String respString = resp.toString();
			assertTrue(respString.contains("\"name\":\"" + client.getName() + "\",\"id\":" + client.getId() + "}"));
		} catch (Exception ex) {
			log.error("Exception has occurred while running test elasticSinkTest. " + "Exception message is "
					+ ex.getMessage());
			assertFalse(true);
		}
	}
}
