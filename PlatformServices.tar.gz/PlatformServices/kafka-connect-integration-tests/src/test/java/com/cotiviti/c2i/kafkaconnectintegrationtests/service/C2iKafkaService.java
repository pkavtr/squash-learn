/*******************************************************************************
 * Copyright (C) 2018 Cotiviti Digital (nexgen.admin@cotiviti.io)
 * 
 * The software code contained herein is the property of Cotiviti Corporation
 * and its subsidiaries and affiliates (collectively, “Cotiviti”).
 * Access to this software code is being provided to you in the course of your
 * employment or affiliation with Cotiviti and may be used solely in the scope
 * and course of your work for Cotiviti, and is for internal Cotiviti use only.
 * Any unauthorized use, disclosure, copying, distribution, destruction of this
 * software code, or the taking of any unauthorized action in reliance on this
 * software code, is strictly prohibited.
 * If this information is viewed in error, immediately discontinue use of the
 * application.  Anyone using this software code and the applications will be
 * subject to monitoring for improper use, system maintenance and security
 * purposes, and is advised that if such monitoring reveals possible criminal
 * activity or policy violation, Cotiviti personnel may provide the evidence of
 * such monitoring to law enforcement or other officials, and the user may be
 * subject to disciplinary action by Cotiviti, up to and including termination
 * of employment.
 * 
 * Use of this software code and any applications and information therein
 * constitutes acknowledgement of and consent to this notice
 ******************************************************************************/
package com.cotiviti.c2i.kafkaconnectintegrationtests.service;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.ExecutionException;

import org.apache.kafka.clients.consumer.Consumer;
import org.apache.kafka.clients.consumer.ConsumerRecord;
import org.apache.kafka.clients.consumer.ConsumerRecords;
import org.apache.kafka.clients.producer.Producer;
import org.apache.kafka.clients.producer.ProducerRecord;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import com.cotiviti.c2i.kafkaconnectintegrationtests.model.AvroClient;
import com.cotiviti.c2i.kafkaconnectintegrationtests.model.C2iJsonClient;

@Service
public class C2iKafkaService {

	private static Logger log = LoggerFactory.getLogger(C2iKafkaService.class);

	@Autowired
	private Producer<String, AvroClient> producer;

	@Autowired
	Consumer<String, String> consumer;
	
	@Autowired
	@Qualifier("consumerm")
    Consumer<String, String> consumerm;

	@Value("${producer.properties.topicName}")
	String topicName;

	/**
	 * To produce kafka records as Avro objects
	 * 
	 * @param client
	 * @throws InterruptedException
	 * @throws ExecutionException
	 */
	public void produce(C2iJsonClient client) throws InterruptedException, ExecutionException {

		log.debug("ClientController:producer is called");
		AvroClient avroClient = AvroClient.newBuilder().setName(client.getName()).setId(client.getId()).build();
		producer.send(new ProducerRecord<String, AvroClient>(topicName, "", avroClient));

	}

	/**
	 * To consume kafka records as Strings
	 * 
	 * @return
	 */
	public List<String> consume() {
		log.debug("ClientController:consumer is called");
		List<String> clients = new ArrayList<>();
		try {
			ConsumerRecords<String, String> records = consumer.poll(2500);
			System.out.println("record count :" + records.count());
			if (records.count() > 0) {
				for (ConsumerRecord<String, String> record : records) {
					Object obj = record.value();

					String event = obj.toString();
					clients.add(event);
					log.debug(event);

				}
				consumer.commitSync();
			}
		} catch (Exception ex) {
			log.debug("exception at kafllka consumer : " + ex.getMessage());
		}
		return clients;
	}
	/**
	 * Specifically for mongodb beacause of topic names clash
	 * 
	 * @return list of records in the kafka topic
	 */
	public List<String> consumes() {
		log.debug("ClientController:consumermongo is called");
		List<String> clients = new ArrayList<>();
		try {
		    ConsumerRecords<String, String> records = consumerm.poll(2500);
		    System.out.println("record count :"+records.count());
            if (records.count() > 0) {
            	for (ConsumerRecord<String, String> record: records) {
            		Object obj = record.value();
            		
            		
            			String event = obj.toString();
	            		clients.add(event);
	            		log.debug(event);
            	
                }
                consumer.commitSync();
            }
		}
		catch (Exception ex) {
			log.debug("exception at kafka consumer : "+ex.getMessage());
		}    
		return clients;
	}

	/**
	 * To Convert Json objects to Struct form
	 * 
	 * @param client
	 * @return
	 */
	public String jsonToStruct(C2iJsonClient client) {
		return "Struct{id=" + client.getId() + ",name=" + client.getName() + "}";
	}

}
