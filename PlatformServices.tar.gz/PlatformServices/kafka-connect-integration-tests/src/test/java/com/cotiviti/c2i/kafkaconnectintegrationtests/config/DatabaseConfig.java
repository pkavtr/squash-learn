/*******************************************************************************
 * Copyright (C) 2018 Cotiviti Digital (nexgen.admin@cotiviti.io)
 * 
 * The software code contained herein is the property of Cotiviti Corporation
 * and its subsidiaries and affiliates (collectively, “Cotiviti”).
 * Access to this software code is being provided to you in the course of your
 * employment or affiliation with Cotiviti and may be used solely in the scope
 * and course of your work for Cotiviti, and is for internal Cotiviti use only.
 * Any unauthorized use, disclosure, copying, distribution, destruction of this
 * software code, or the taking of any unauthorized action in reliance on this
 * software code, is strictly prohibited.
 * If this information is viewed in error, immediately discontinue use of the
 * application.  Anyone using this software code and the applications will be
 * subject to monitoring for improper use, system maintenance and security
 * purposes, and is advised that if such monitoring reveals possible criminal
 * activity or policy violation, Cotiviti personnel may provide the evidence of
 * such monitoring to law enforcement or other officials, and the user may be
 * subject to disciplinary action by Cotiviti, up to and including termination
 * of employment.
 * 
 * Use of this software code and any applications and information therein
 * constitutes acknowledgement of and consent to this notice
 ******************************************************************************/
package com.cotiviti.c2i.kafkaconnectintegrationtests.config;

import java.util.HashMap;

import javax.persistence.EntityManagerFactory;
import javax.sql.DataSource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.boot.autoconfigure.orm.jpa.JpaProperties;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.boot.jdbc.DataSourceBuilder;
import org.springframework.boot.orm.jpa.EntityManagerFactoryBuilder;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Primary;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;
import org.springframework.orm.jpa.JpaTransactionManager;
import org.springframework.orm.jpa.JpaVendorAdapter;
import org.springframework.orm.jpa.LocalContainerEntityManagerFactoryBean;
import org.springframework.orm.jpa.persistenceunit.PersistenceUnitManager;
import org.springframework.orm.jpa.vendor.AbstractJpaVendorAdapter;
import org.springframework.orm.jpa.vendor.HibernateJpaVendorAdapter;
import org.springframework.transaction.annotation.EnableTransactionManagement;

@Configuration
@EnableTransactionManagement
@EnableJpaRepositories(entityManagerFactoryRef = "DatabaseEntityManager", transactionManagerRef = "DatabaseTransactionManager",
		// Location of the datasource Repository
		basePackages = "com.cotiviti.c2i.kafkaconnectintegrationtests.repository")
public class DatabaseConfig {

	@Bean
	@ConfigurationProperties(prefix = "spring.mysql.datasource")
	public DataSource mySQLDataSource() {
		return DataSourceBuilder.create().build();
	}

	@Bean
	@ConfigurationProperties(prefix = "spring.sqlserver.datasource")
	public DataSource sqlServerDataSource() {
		return DataSourceBuilder.create().build();
	}
	@Bean
	@ConfigurationProperties(prefix = "spring.oracle.datasource")
	public DataSource OracleDataSource() {
		return DataSourceBuilder.create().build();
	}


	@Bean
	public DataSource databaseDataSource() {
		DataSourceRouter router = new DataSourceRouter();
		final HashMap<Object, Object> map = new HashMap<>(3);
		map.put(DatabaseEnvironment.MYSQL, mySQLDataSource());
		map.put(DatabaseEnvironment.MSSQL, sqlServerDataSource());
		map.put(DatabaseEnvironment.ORACLE, OracleDataSource());
		router.setTargetDataSources(map);
		router.setDefaultTargetDataSource(mySQLDataSource());
		return router;

	}

	@Autowired(required = false)
	private PersistenceUnitManager persistenceUnitManager;

	@Bean
	@ConfigurationProperties("spring.jpa")
	public JpaProperties customerJpaProperties() {
		return new JpaProperties();
	}

	@Bean(name = "DatabaseTransactionManager")
	public JpaTransactionManager databaseTransactionManager(
			@Qualifier("DatabaseEntityManager") final EntityManagerFactory factory) {
		return new JpaTransactionManager(factory);
	}

	@Bean(name = "DatabaseEntityManager")
	public LocalContainerEntityManagerFactoryBean databaseEntityManager(final JpaProperties customerJpaProperties) {

		EntityManagerFactoryBuilder builder = createEntityManagerFactoryBuilder(customerJpaProperties);

		return builder.dataSource(databaseDataSource()).packages("com.cotiviti.c2i.kafkaconnectintegrationtests.model")
				.persistenceUnit("DatabaseEntityManager").build();
	}

	private EntityManagerFactoryBuilder createEntityManagerFactoryBuilder(JpaProperties databaseJpaProperties) {
		JpaVendorAdapter jpaVendorAdapter = createJpaVendorAdapter(databaseJpaProperties);
		return new EntityManagerFactoryBuilder(jpaVendorAdapter, databaseJpaProperties.getProperties(),
				this.persistenceUnitManager);
	}

	private JpaVendorAdapter createJpaVendorAdapter(JpaProperties jpaProperties) {
		AbstractJpaVendorAdapter adapter = new HibernateJpaVendorAdapter();
		adapter.setShowSql(jpaProperties.isShowSql());
		adapter.setDatabase(jpaProperties.getDatabase());
		adapter.setDatabasePlatform(jpaProperties.getDatabasePlatform());
		adapter.setGenerateDdl(jpaProperties.isGenerateDdl());
		return adapter;
	}
}
