<h1>Integration tests for C2i Standard Templates for Kafka Connect</h1>
<h3>INTRODUCTION</h3>
This is a project that houses integration tests for the C2i Standard Templates for Kafka Connect. Current tests include: Integration tests for File, Elastic, Mongo and JDBC connect templates.

<h3>DEPENDENCIES</h3>
1) Confluent<br>
2) MySQL server<br>
3) Microsoft SQL server running on docker instance<br>
4) Oracle xe<br>
5) Mongo DB<br>
6) Elasticsearch<br>

<h3>1) INSTALLING CONFLUENT</h3>
To install Confluent, follow the below given steps:<br><br>
1) Download the Confluent Kafka zip file with link https://www.confluent.io/download/    <br><br>
2) Uncompress the downloaded zip file to a folder and write down the path to this folder <br><br>
3) Go to the bin sub-folder in the folder above and issue the "confluent start" command. This Confluent CLI command starts six services:<br>
            1) zookeeper server<br>
            2) kafka broker<br>
            3) schema-registry service<br>
            4) kafka-rest service<br>
            5) connect-kafka connect server<br>
            6) ksql-server<br>

<h3>2) Installing MySQL server</h3>

  1) sudo apt-get install mysql-server.  
  
  2) sudo service mysql start [to start the mysql server].
  
  3) sudo /usr/bin/mysql_secure_installation [running the file as root user].
     This step helps to set root password if not set already and some other configurations to make mysql secure.
             
  4) mysql -u root -p [to start the server as root user and to create another user.]
  
  5) create database project;
  
  6) create user 'c2iuser' @'localhost' identified by 'C2i@cotv123' ;  [creating user]
  
  
  7) grant all privileges on project.* to 'c2iuser'@'localhost' ; [granting user all privileges on database]
  
  8) To exit mysql, type \q and hit enter .
  
  9) mysql -u c2iuser -p [to start the server with user you created]
  
  10) use project;  [to switch to the database you want to use]
   
  11) create table sourceconnect using the following command <b>CREATE TABLE sourceconnect (
    id int(11) not null PRIMARY KEY,
    name VARCHAR(255) default '',
    update_ts TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);</b>
  
  12) To exit mysql, type \q and hit enter
  
<h3>3) Setting up Microsoft SQL server on Docker instance</h3>
We assume the environment running these connectors is a Linux OS for now.  We will provide Windows OS instruction later.  To simplify the installation, we will use SQL Server Linux Docker image.  So, the environment will need to have Docker engine installed.  Following is the list of steps to perform the installation

1. Download Microsoft SQL Server JDBC driver from: http://central.maven.org/maven2/com/microsoft/sqlserver/mssql-jdbc/7.0.0.jre8/mssql-jdbc-7.0.0.jre8.jar

2. Copy the downloaded SQL Server JDBC driver to `<path-to-confluent>/share/java/kafka-connect-jdbc` folder

3. Pull SQL Server Linux image: ``docker pull microsoft/mssql-server-linux``

4. Start a mssql-server instance running as the SQL Express edition: ``docker run -e 'ACCEPT_EULA=Y' -e 'SA_PASSWORD=yourStrong@Password' -e 'MSSQL_PID=Express' -p 1433:1433 -d microsoft/mssql-server-linux:latest``

5. Find the instance container id and copy it: ``docker ps``

6. Connect to the mssql-server instance using sqlcmd tool: ``docker exec -it <container id> /opt/mssql-tools/bin/sqlcmd -S localhost -U sa -P yourStrong@Password``

7. Create new database: ``CREATE DATABASE testConnectors``

8. Press Enter and then: ``go``

9. Use the newly created database: ``use testConnectors``

10. Press Enter and then: ``go``

11. Create connect table in the sqlcmd establised above: ``create table sourceconnect (id int, name varchar(255) ,update_ts DATETIME DEFAULT GETDATE())``

12. Press enter and then: ``go``

<h3>3) Setting up Elasticsearch</h3>

1. Download the Elasticsearch package based on your OS from the link given below:<br/>
	https://www.elastic.co/downloads/elasticsearch

2. Unzip the downloaded Elasticsearch package and open it.

3. Run the elasticsearch using the command : <br/> bin/elasticsearch (or bin\elasticsearch.bat on Windows)

4. Run curl http://localhost:9200/ or Invoke-RestMethod http://localhost:9200 to verify the running of Elasticsearch on your machine. 

<h3>4) Installing Oracle</h3>
Following are the steps to install Oracle-xe version on Linux OS.The Installer released by Oracle is only meant for 64-bit (x86_64) systems.Only one installation of Oracle Database XE can be performed on a single computer.
The steps for Installation :
 
1. Download the Oracle 11gR2 express edition installer from the link given below:<br/>
http://www.oracle.com/technetwork/products/express-edition/downloads/index.html
( You will need to create a free oracle web account if you don't already have it )

2. Unzip it :<br/>
`unzip oracle-xe-11.2.0-1.0.x86_64.rpm.zip`
3. Install the following packages :<br/>
`sudo apt-get install alien libaio1 unixodbc vim`

4. Convert the red-hat ( rpm ) package to Ubuntu-package :<br/>
`sudo alien --scripts -d oracle-xe-11.2.0-1.0.x86_64.rpm`

5. Meanwhile do the following pre-requisite things:<br/>
      1. Create a special chkconfig script :
      `sudo vim /sbin/chkconfig`
      (copy and paste the following into the file )
            <pre>
            #!/bin/bash
            # Oracle 11gR2 XE installer chkconfig hack for Ubuntu
            file=/etc/init.d/oracle-xe
            if [[ ! `tail -n1 $file | grep INIT` ]]; then
            echo >> $file
            echo '### BEGIN INIT INFO' >> $file
            echo '# Provides: OracleXE' >> $file
            echo '# Required-Start: $remote_fs $syslog' >> $file
            echo '# Required-Stop: $remote_fs $syslog' >> $file
            echo '# Default-Start: 2 3 4 5' >> $file
            echo '# Default-Stop: 0 1 6' >> $file
            echo '# Short-Description: Oracle 11g Express Edition' >> $file
            echo '### END INIT INFO' >> $file
            fi
            update-rc.d oracle-xe defaults 80 01
            </pre>
            Save the above file and provide appropriate execute privilege :<br/>
            `sudo chmod 755 /sbin/chkconfig`
       
       
      2. Set the Kernel parameters :<br/>
      Oracle 11gR2 XE requires to set the following additional kernel parameters:<br/>
       `sudo vim /etc/sysctl.d/60-oracle.conf`
            (Enter the following) 
            <pre>
            # Oracle 11g XE kernel parameters  
            fs.file-max=6815744  
            net.ipv4.ip_local_port_range=9000 65000  
            kernel.sem=250 32000 100 128 
            kernel.shmmax=536870912 
            </pre>
            (Save the file)
            Note: kernel.shmmax = max possible value , e.g. size of physical RAM ( in bytes e.g. 512MB RAM == 512*1024*1024 == 536870912 bytes ) 
  
           Verify the change :<br/>
           `sudo cat /etc/sysctl.d/60-oracle.conf`

           Load new kernel parameters:<br/>
           `sudo service procps restart`

           Verify: sudo sysctl -q fs.file-max <br/>
               -> fs.file-max = 6815744 <br/>
       
      3. make some more required changes :<br/>

              a. sudo ln -s /usr/bin/awk /bin/awk 
              b. mkdir /var/lock/subsys 
              c. touch /var/lock/subsys/listener 

6. Go to the directory where you created the ubuntu package file in Step 4 and enter following commands in terminal :<br/>

              1. sudo dpkg --install oracle-xe_11.2.0-2_amd64.deb 
              2. sudo /etc/init.d/oracle-xe configure
 
              Enter the following configuration information:

              A valid HTTP port for the Oracle Application Express (the default is 8080)  
              A valid port for the Oracle database listener (the default is 1521) 
              A password for the SYS and SYSTEM administrative user accounts
              Confirm password for SYS and SYSTEM administrative user accounts
              Whether you want the database to start automatically when the computer starts (next reboot).

7. Before you start using Oracle 11gR2 XE you have to set-up more things :
     1. Set-up the environmental variables :
        Add following lines to your .bashrc :
        <pre>
         export ORACLE_HOME=/u01/app/oracle/product/11.2.0/xe
         export ORACLE_SID=XE
         export NLS_LANG=`$ORACLE_HOME/bin/nls_lang.sh`
         export ORACLE_BASE=/u01/app/oracle
         export LD_LIBRARY_PATH=$ORACLE_HOME/lib:$LD_LIBRARY_PATH
         export PATH=$ORACLE_HOME/bin:$PATH
        </pre>
     2. execute your .profile to load the changes:

         . ./.profile

8. Start the Oracle 11gR2 XE :
  `sudo service oracle-xe start`
    1. start sqlplus and login as sys :<br/>
        `sqlplus sys as sysdba`
        ( provide the password you gave while configuring the oracle ). 
    2. Enter following on the sql prompt : Replace username and password by your desired ones.
        <pre>
        SQL> create user username identified by password; [User created.]
        SQL> grant connect,resource to username; [Grant succeeded.]
        </pre><br/>
9. Now as you have created the user , you can login to it by opening sqlplus console.Type the following command in Terminal:<br/>
 `>sqlplus`
 (Login with your credentials)<br/>

10. We are using the default database xe with default user SYSTEM. Create the following Table.
<pre>
CREATE TABLE SOURCECONNECT(
         id      NUMBER(5) PRIMARY KEY,
         name      VARCHAR2(15) NOT NULL,
         update_ts        DATE DEFAULT (sysdate)
         );
</pre>
11. Type exit to exit the sqlplus console.

<h3>5. Installing mongo</h3>

 1. Download the MongoDB Community Server from https://www.mongodb.com/download-center#community for the corresponding OS;
 2. Uncompress the downloaded file to a folder and mark down the path to this folder if OS is a Unix like system. Just install the downloaded MSI file for Windows system;
 3. In a terminal, go to the bin sub-folder in the folder above and issue "./mongod --replSet rs" with default data path or "./mongod --dbpath ~/Documents/mongo/data --replSet rs" with specified data path;
 4. In another terminal, go to the bin sub-folder in the folder above again and issue the "./mongo" command to start the MongoDB client. Then, issue the "rs.initiate()" command to initiate data replication.
 5. Copy the uber jar to the target directory of the project. Look for the jar file with the naming pattern of c2i-MongoDB-connector-{version}-jar-with-dependencies.jar and copy it into the "/share/java/kafka" or "/share/java/confluent-common" directory. Restart the Kafka Connect service after copying the jar file into one of those folders to make sure the jar file is being loaded. You can use "./confluent status plugins" to see if the connectors are listed in output. If you do not see the connector in the list, there is something not correct


<h3>RUNNING THE CONNECTORS</h3>
Please run the templates that are present in kafka-connect-integration-tests/connect-templates
<h3>FILE</h3>
Change the file path information in both file sink and file source connect templates by modifying the "file" field in the templates.<br>

Load these two connectors with: ``confluent load c2i-file-sink -d <path-to-connector>/c2i-file-sink-template.json`` &
``confluent load c2i-file-source -d <path-to-connector>/c2i-file-source-template.json``

In the /src/test/resources/application.yml change the paths of the source and sink files.

<h3>JDBC</h3>

Load these two connectors with: ``confluent load c2i-jdbc-sink -d <path-to-connector>/c2i-jdbc-sink-template.json`` &
``confluent load c2i-jdbc-source -d <path-to-connector>/c2i-jdbc-source-template.json``

<h3>SQL SERVER</h3>
Load these two connectors with: ``confluent load c2i-mssql-sink -d <path-to-connector>/c2i-jdbc-mssql-template.json`` &
``confluent load c2i-mssql-source -d <path-to-connector>/c2i-mssql-source-template.json``

<h3>ELASTIC</h3>

Load the Sink connector with: ``confluent load c2i-elasticsearch-sink -d c2i-elasticsearch-sink-template.json ``

<h3>ORACLE</h3>

 Load the source connector with `confluent load c2i-oracle-source -d <path-to-connector>/c2i-oracle-source-template.json` 

<h3>MONGO</h3>

 Load these two connectors with `confluent load c2i-mongodb-source -d <path-to-connector>/c2i-mongodb-source-template.json` &
`confluent load c2i-mongodb-sink -d <path-to-connector>/c2i-mongodb-sink-template.json`
<h3>Running the Tests</h3>
Run the tests for various datasources using the commands:

File : ``mvn test -Pfile``

Jdbc : ``mvn test -Pjdbc``

SQL Server : ``mvn test -Pmssql``

Elastic : ``mvn test -Pelastic``

Oracle : ``mvn test -Poracle``

Mongo : ``mvn test -Pmongo``


Drop/clean the Database tables each time the tests are run to prevent the primary key exception.
