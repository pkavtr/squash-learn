/**
 * Copyright (C) 2018 Cotiviti Digital (nexgen.admin@cotiviti.io)
 *
 * The software code contained herein is the property of Cotiviti Corporation
 * and its subsidiaries and affiliates (collectively, “Cotiviti”).
 * Access to this software code is being provided to you in the course of your
 * employment or affiliation with Cotiviti and may be used solely in the scope
 * and course of your work for Cotiviti, and is for internal Cotiviti use only.
 * Any unauthorized use, disclosure, copying, distribution, destruction of this
 * software code, or the taking of any unauthorized action in reliance on this
 * software code, is strictly prohibited.
 * If this information is viewed in error, immediately discontinue use of the
 * application.  Anyone using this software code and the applications will be
 * subject to monitoring for improper use, system maintenance and security
 * purposes, and is advised that if such monitoring reveals possible criminal
 * activity or policy violation, Cotiviti personnel may provide the evidence of
 * such monitoring to law enforcement or other officials, and the user may be
 * subject to disciplinary action by Cotiviti, up to and including termination
 * of employment.
 *
 * Use of this software code and any applications and information therein
 * constitutes acknowledgement of and consent to this notice
 */
package com.cotiviti.c2i.kafka.connect.mongodb;

import org.apache.kafka.common.config.ConfigDef;
import org.apache.kafka.common.utils.AppInfoParser;
import org.apache.kafka.connect.connector.Task;
import org.apache.kafka.connect.errors.ConnectException;
import org.apache.kafka.connect.sink.SinkConnector;
import org.apache.kafka.connect.util.ConnectorUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.cotiviti.c2i.kafka.connect.utils.LogUtils;
import com.cotiviti.c2i.kafka.connect.utils.StringUtils;

import static com.cotiviti.c2i.kafka.connect.mongodb.MongodbSinkConfig.BULK_SIZE;
import static com.cotiviti.c2i.kafka.connect.mongodb.MongodbSinkConfig.COLLECTIONS;
import static com.cotiviti.c2i.kafka.connect.mongodb.MongodbSinkConfig.DATABASE;
import static com.cotiviti.c2i.kafka.connect.mongodb.MongodbSinkConfig.HOST;
import static com.cotiviti.c2i.kafka.connect.mongodb.MongodbSinkConfig.PORT;
import static com.cotiviti.c2i.kafka.connect.mongodb.MongodbSinkConfig.TOPICS;
import static com.cotiviti.c2i.kafka.connect.mongodb.MongodbSinkConfig.URI;

import java.util.*;

/**
 * MongodbSinkConnector implement the Connector interface to send Kafka data to Mongodb
 * 
 * @author kchen
 *
 */
public class MongodbSinkConnector extends SinkConnector {
    private final static Logger log = LoggerFactory.getLogger(MongodbSinkConnector.class);

    private String uri;
    private String port;
    private String host;
    private String bulkSize;
    private String database;
    private String collections;
    private String topics;

    /**
     * Get the version of this connector.
     *
     * @return the version, formatted as a string
     */
    @Override
    public String version() {
        return AppInfoParser.getVersion();
    }

    /**
     * Start this Connector. This method will only be called on a clean Connector, i.e. it has
     * either just been instantiated and initialized or {@link #stop()} has been invoked.
     *
     * @param map configuration settings
     */
    @Override
    public void start(Map<String, String> map) {
        log.trace("Parsing configuration");

        uri = map.get(URI);
        if (uri == null || uri.isEmpty()){
            host = map.get(HOST);
            if (host == null || host.isEmpty()){
                throw new ConnectException("Missing " + HOST + " config");
            }
        	
	        port = map.get(PORT);
	        if (port == null || port.isEmpty()){
	            throw new ConnectException("Missing " + PORT + " config");
	        }
        }
        bulkSize = map.get(BULK_SIZE);
        if (bulkSize == null || bulkSize.isEmpty())
            throw new ConnectException("Missing " + BULK_SIZE + " config");

        database = map.get(DATABASE);
        collections = map.get(COLLECTIONS);
        topics = map.get(TOPICS);

        if (collections.split(",").length != topics.split(",").length) {
            throw new ConnectException("The number of topics should be the same as the number of collections");
        }

        LogUtils.dumpConfiguration(map, log);
    }

    /**
     * Returns the task implementation for this Connector
     *
     * @return the task class
     */
    @Override
    public Class<? extends Task> taskClass() {
        return MongodbSinkTask.class;
    }

    /**
     * Returns a set of configurations for Tasks based on the current configuration,
     * producing at most maxTasks configurations.
     *
     * @param maxTasks maximum number of task to start
     * @return configurations for tasks
     */
    @Override
    public List<Map<String, String>> taskConfigs(int maxTasks) {
        List<Map<String, String>> configs = new ArrayList<>();
        List<String> coll = Arrays.asList(collections.split(","));
        int numGroups = Math.min(coll.size(), maxTasks);
        List<List<String>> dbsGrouped = ConnectorUtils.groupPartitions(coll, numGroups);
        List<String> topics = Arrays.asList(this.topics.split(","));
        List<List<String>> topicsGrouped = ConnectorUtils.groupPartitions(topics, numGroups);

        for (int i = 0; i < numGroups; i++) {
            Map<String, String> config = new HashMap<>();
            config.put(URI, uri);
            if(host!=null){
                config.put(HOST, host);
            }
            if(port!=null){
            	config.put(PORT, port);
            }
            config.put(BULK_SIZE, bulkSize);
            config.put(DATABASE, database);
            config.put(COLLECTIONS, StringUtils.join(dbsGrouped.get(i), ","));
            config.put(TOPICS, StringUtils.join(topicsGrouped.get(i), ","));
            configs.add(config);
        }
        return configs;
    }

    /**
     * Stop this connector.
     */
    @Override
    public void stop() {

    }

    @Override
    public ConfigDef config () {
    	return MongodbSinkConfig.config;
    }
}
