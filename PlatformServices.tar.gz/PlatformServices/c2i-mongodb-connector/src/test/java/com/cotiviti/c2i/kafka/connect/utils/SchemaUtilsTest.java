/**
 * Copyright (C) 2018 Cotiviti Digital (nexgen.admin@cotiviti.io)
 *
 * The software code contained herein is the property of Cotiviti Corporation
 * and its subsidiaries and affiliates (collectively, “Cotiviti”).
 * Access to this software code is being provided to you in the course of your
 * employment or affiliation with Cotiviti and may be used solely in the scope
 * and course of your work for Cotiviti, and is for internal Cotiviti use only.
 * Any unauthorized use, disclosure, copying, distribution, destruction of this
 * software code, or the taking of any unauthorized action in reliance on this
 * software code, is strictly prohibited.
 * If this information is viewed in error, immediately discontinue use of the
 * application.  Anyone using this software code and the applications will be
 * subject to monitoring for improper use, system maintenance and security
 * purposes, and is advised that if such monitoring reveals possible criminal
 * activity or policy violation, Cotiviti personnel may provide the evidence of
 * such monitoring to law enforcement or other officials, and the user may be
 * subject to disciplinary action by Cotiviti, up to and including termination
 * of employment.
 *
 * Use of this software code and any applications and information therein
 * constitutes acknowledgement of and consent to this notice
 */
package com.cotiviti.c2i.kafka.connect.utils;

import static org.junit.Assert.assertTrue;

import java.util.Map;

import org.apache.kafka.connect.data.Date;
import org.apache.kafka.connect.data.Schema;
import org.apache.kafka.connect.data.SchemaBuilder;
import org.apache.kafka.connect.data.Struct;
import org.apache.kafka.connect.data.Time;
import org.apache.kafka.connect.data.Timestamp;
import org.junit.Before;
import org.junit.Test;

import com.cotiviti.c2i.kafka.connect.utils.SchemaUtils;

public class SchemaUtilsTest {

	@Before
	public void setUp() throws Exception {
	}

	@Test
	public void shouldSupportTimestamp() {
		Schema schema = SchemaBuilder.struct().field("timestamp", Timestamp.SCHEMA);
		Struct struct = new Struct( schema );
		struct.put("timestamp", new java.util.Date());
		
		Map<String,Object> jsonMap = SchemaUtils.toJsonMap(struct);
		assertTrue(jsonMap.get("timestamp") instanceof java.util.Date);
	}
	@Test
	public void shouldSupportDate() {
		Schema schema = SchemaBuilder.struct().field("date", Date.SCHEMA);
		Struct struct = new Struct( schema );
		struct.put("date", new java.util.Date());
		
		Map<String,Object> jsonMap = SchemaUtils.toJsonMap(struct);
		assertTrue(jsonMap.get("date") instanceof java.util.Date);
	}
	@Test
	public void shouldSupportTime() {
		Schema schema = SchemaBuilder.struct().field("time", Time.SCHEMA);
		Struct struct = new Struct( schema );
		struct.put("time", new java.util.Date());
		
		Map<String,Object> jsonMap = SchemaUtils.toJsonMap(struct);
		assertTrue(jsonMap.get("time") instanceof java.util.Date);
	}
}
