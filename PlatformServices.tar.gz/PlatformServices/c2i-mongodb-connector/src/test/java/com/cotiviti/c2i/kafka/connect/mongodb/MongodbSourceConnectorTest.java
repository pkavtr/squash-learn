/**
 * Copyright (C) 2018 Cotiviti Digital (nexgen.admin@cotiviti.io)
 *
 * The software code contained herein is the property of Cotiviti Corporation
 * and its subsidiaries and affiliates (collectively, “Cotiviti”).
 * Access to this software code is being provided to you in the course of your
 * employment or affiliation with Cotiviti and may be used solely in the scope
 * and course of your work for Cotiviti, and is for internal Cotiviti use only.
 * Any unauthorized use, disclosure, copying, distribution, destruction of this
 * software code, or the taking of any unauthorized action in reliance on this
 * software code, is strictly prohibited.
 * If this information is viewed in error, immediately discontinue use of the
 * application.  Anyone using this software code and the applications will be
 * subject to monitoring for improper use, system maintenance and security
 * purposes, and is advised that if such monitoring reveals possible criminal
 * activity or policy violation, Cotiviti personnel may provide the evidence of
 * such monitoring to law enforcement or other officials, and the user may be
 * subject to disciplinary action by Cotiviti, up to and including termination
 * of employment.
 *
 * Use of this software code and any applications and information therein
 * constitutes acknowledgement of and consent to this notice
 */
package com.cotiviti.c2i.kafka.connect.mongodb;

import org.apache.kafka.connect.connector.ConnectorContext;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.powermock.api.easymock.PowerMock;

import com.cotiviti.c2i.kafka.connect.mongodb.MongodbSourceConnector;
import com.cotiviti.c2i.kafka.connect.mongodb.MongodbSourceTask;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * @author kchen
 */
public class MongodbSourceConnectorTest {
    private MongodbSourceConnector connector;
    private ConnectorContext context;


    @Before
    public void setupByHostAndPort() {
        connector = new MongodbSourceConnector();
        context = PowerMock.createMock(ConnectorContext.class);
        connector.initialize(context);
    }
    
    private Map<String, String> buildSourcePropertiesWithHostAndPort(){
    	final Map<String, String> sourceProperties = new HashMap<>();
        sourceProperties.put("host", "localhost");
        sourceProperties.put("port", Integer.toString(12345));
        sourceProperties.put("batch.size", Integer.toString(100));
        sourceProperties.put("schema.name", "schema");
        sourceProperties.put("topic.prefix", "prefix");
        sourceProperties.put("databases", "mydb.test1,mydb.test2,mydb.test3");
        return sourceProperties;
    }
    
    private Map<String, String> buildSourcePropertiesWithURI(){
    	final Map<String, String> sourceProperties = new HashMap<>();
        sourceProperties.put("uri", "mongodb://localhost:12345");
        sourceProperties.put("batch.size", Integer.toString(100));
        sourceProperties.put("schema.name", "schema");
        sourceProperties.put("topic.prefix", "prefix");
        sourceProperties.put("databases", "mydb.test1,mydb.test2,mydb.test3");
        return sourceProperties;
    }

    @Test
    public void testSourceTasks() {
        PowerMock.replayAll();
        connector.start(buildSourcePropertiesWithHostAndPort());
        List<Map<String, String>> taskConfigs = connector.taskConfigs(1);
        Assert.assertEquals(1, taskConfigs.size());
        Assert.assertEquals("localhost", taskConfigs.get(0).get("host"));
        Assert.assertEquals("12345", taskConfigs.get(0).get("port"));
        Assert.assertEquals("100", taskConfigs.get(0).get("batch.size"));
        Assert.assertEquals("schema", taskConfigs.get(0).get("schema.name"));
        Assert.assertEquals("prefix", taskConfigs.get(0).get("topic.prefix"));
        Assert.assertEquals("mydb.test1,mydb.test2,mydb.test3", taskConfigs.get(0).get("databases"));
        PowerMock.verifyAll();
    }
    
    @Test
    public void testSourceTasksUri() {
        PowerMock.replayAll();
        connector.start(buildSourcePropertiesWithURI());
        List<Map<String, String>> taskConfigs = connector.taskConfigs(1);
        Assert.assertEquals(1, taskConfigs.size());
        Assert.assertEquals("mongodb://localhost:12345", taskConfigs.get(0).get("uri"));
        Assert.assertEquals("100", taskConfigs.get(0).get("batch.size"));
        Assert.assertEquals("schema", taskConfigs.get(0).get("schema.name"));
        Assert.assertEquals("prefix", taskConfigs.get(0).get("topic.prefix"));
        Assert.assertEquals("mydb.test1,mydb.test2,mydb.test3", taskConfigs.get(0).get("databases"));
        PowerMock.verifyAll();
    }

    @Test
    public void testMultipleTasks() {
        PowerMock.replayAll();
        connector.start(buildSourcePropertiesWithHostAndPort());
        List<Map<String, String>> taskConfigs = connector.taskConfigs(2);
        Assert.assertEquals(2, taskConfigs.size());
        Assert.assertEquals("localhost", taskConfigs.get(0).get("host"));
        Assert.assertEquals("12345", taskConfigs.get(0).get("port"));
        Assert.assertEquals("100", taskConfigs.get(0).get("batch.size"));
        Assert.assertEquals("schema", taskConfigs.get(0).get("schema.name"));
        Assert.assertEquals("prefix", taskConfigs.get(0).get("topic.prefix"));
        Assert.assertEquals("mydb.test1,mydb.test2", taskConfigs.get(0).get("databases"));

        Assert.assertEquals("localhost", taskConfigs.get(1).get("host"));
        Assert.assertEquals("12345", taskConfigs.get(1).get("port"));
        Assert.assertEquals("100", taskConfigs.get(1).get("batch.size"));
        Assert.assertEquals("schema", taskConfigs.get(1).get("schema.name"));
        Assert.assertEquals("prefix", taskConfigs.get(1).get("topic.prefix"));
        Assert.assertEquals("mydb.test3", taskConfigs.get(1).get("databases"));
        PowerMock.verifyAll();
    }

    @Test
    public void testTaskClass() {
        PowerMock.replayAll();
        connector.start(buildSourcePropertiesWithHostAndPort());
        Assert.assertEquals(MongodbSourceTask.class, connector.taskClass());
        PowerMock.verifyAll();
    }
}
