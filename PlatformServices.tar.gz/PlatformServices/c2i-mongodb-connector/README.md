# Framework Kafka Connector - Mongodb

## Introduction

This project serves as sample for dveloping new Kafka connector and can also be used to sink & source data between Kafka topics and MongoDB collections.

To develop a Kafka Connect connector, there several required modules need to be developed by the Kafka Connect framework,

* Connector configuration class - It is used to get configuration properties for the connector.  It can be extended from org.apache.kafka.common.config.AbstractConfig class or create your own class from the ground.  The main purpose of the configuration class is to expose a static function to return a org.apache.kafka.common.config.ConfigDef object;
* Connector class - It must extend from either org.apache.kafka.connect.source.SourceConnector or org.apache.kafka.connect.sink.SinkConnector to allow Kafka Connect framework to use it to start or stop the connector;
* Task class - It is used to process data in pre-defined data sources or Kafka topics.   It must be extended from org.apache.kafka.connect.sink.SinkTask or org.apache.kafka.connect.source.SourceTask class in order for Kafka Connect framework to invoke it to process event or data;
* Converter class - This is an optional class for converting object from one format to another for different data sources.

## Building Project

This project has no dependency on other C2i projects and can be built alone with Maven using the standard lifecycle phases:
```
mvn clean package -DskipTests
```

Due to some issues in the unit tests, we use skip test for now.  If you run these test individually, all of them will pass without problem.  It may relate to mongodb connections are not being closed after they are used within the specified timeframe.

## Deploying Connectors

### Pre-requisition

Since the connectors in this project are deployed to Kafka Connect for loading data from Kafka to Mongodb and from Mongodb to Kafka, Kafka Connect service and Mongodb server are required to be installed and run along with Kafka broker in the system for testing the connectors.  The easiest way to install and run required Kafka modules is to install and run Confluent platform.  To do that, 

1. Download Confluent Kafka zip file with link https://www.confluent.io/download/;
2. Uncompress the downloaded zip file to a folder and mark down the path to this folder;
3. Go to bin sub-folder in the folder above and issue "./confluent start" command. This Confluent CLI command starts six services,
	* zookeeper server
	* kafka broker
	* schema-registry service
	* kafka-rest service
	* connect - kafka connect server
	* ksql-server

The next thing is to install Mongodb if your system has not yet installed it already,

1. Download the MongoDB Community Server from https://www.mongodb.com/download-center#community for the corresponding OS;
2. Uncompress the downloaded file to a folder and mark down the path to this folder if OS is a Unix like system.  Just install the downloaded MSI file for Windows system;
3. In a terminal, go to bin sub-folder in the folder above and issue "./mongod  --replSet rs" with default data path or "./mongod --dbpath ~/Documents/mongo/data --replSet rs" with specified data path;
4. In another terminal, go to bin sub-folder in the folder above again and issue "./mongo" to start mongodb client.  Then, issue "rs.initiate()" command to initiate data replication.

Please note, the source connector in this project reads data from MongoDB oplog and then publish it to Kafka topic. Therefore, the MongoDB instance is reuqired to enable data replication.  Step 3 and 4 are used to enable the replication.  Without "--replSet rs" option in starting MongoDB server or without issuing "rs.initiate()" command at least once in a MongoDB client, the source connector will not work.

### Deployment

In this project, we use the same jar for both sink & source connectors.  So, 

1. The first thing for deploying the connectors is to copy the uber jar in the target directory of the project, the jar file with naming pattern of c2i-mongodb-connector-{version}-jar-with-dependencies.jar, into "<path-to-confluent>/share/java/kafka" or "<path-to-confluent>/share/java/confluent-common" directory.  Please restart Kafka Connect service after copying the jar file into those folders to make sure the jar file is being loaded.  You can use "./confluent status plugins" to see if the connectors are listed in output.  If you do not see the connector in the list, there is something not correct;
2. Now deploy the Kafka Connect configurations for the connectors into Kafka Connect service.  In a terminal, change to "<path-to-confluent>/bin" folder and issue "./confluent load c2i-mongodb-sink -d <path-to-c2i-mongo-sink-template>/c2i-mongo-sink-template.json" and "./confluent load c2i-mongodb-source -d <path-to-c2i-mongo-source-template>/c2i-mongo-source-template.json" commands to load both connectors into Kafka Connect service.  Please note, both json files are in this project folder;
3. Check if there is any error in loading the connectors into Kafka Connect service by issuing "./confluent status c2i-mongodb-sink" or "./confluent status c2i-mongodb-source".  There should not be any error and they should be in "RUNNING" state.

## Integration Tests

The integration test is kind of confusing and therefore, the data flows are shown here first to allow readers to understand the test flow.  For the source connector, which is used to read events from MongoDB oplog and publish them into Kafka topics, the data flow for the test is,
```
user insert/update/delete record in "source" collection under "sourcedb" database using mongodb client -> "c2i-mongodb-source" connector reads record from oplog file and publish the record into "c2i_sourcedb_source" kafka topic -> use "kafka-avro-console-consumer" to display the messages being published in the "c2i_sourcedb_source" topic
```

For the sink connector, which is used to read messages from Kafka topics and insert them into MongoDB collections, the data flow for the test is,
```
user pushes message into "c2i_sink" Kafka topic using "kafka-avro-console-producer" -> "c2i-mongodb-sink" connector reads message from "c2i_sink" topic and format the message with "converter.class" and insert it into "sink" collection under "sinkdb" database -> user use "use sinkdb" and then "db.sink.find()" commands inside a mongodb client to display records in the collection
```

After understanding the data flows for testing the connectors, we can start to send data and see the results.  For testing "c2i-mongodb-source" connector,

1. Open a terminal and change to "<path-to-mongodb>/bin" and enter "./mongo" to start a MongoDB client;
2. In the MongoDB client, enter "use sourcedb" to switch to "sourcedb" database;
3. In the same MongoDB client again, enter "db.source.insert({'myid': 1})" command to insert {'myid': 1} json record into "source" collection;
4. Open a new terminal and change to "<path-to-confluent>/bin" directory and enter "./kafka-avro-console-consumer --bootstrap-server localhost:9092 --topic c2i_sourcedb_source --from-beginning" to see all the records being published into "c2i_sourcedb_source" Kafka topic.

For testing "c2i-mongodb-sink" connector,

1. Open a ternminal and change to "<path-to-confluent>/bin" directory and enter "./kafka-avro-console-producer --broker-list localhost:9092 --topic c2i_sink --property value.schema='{"type":"record","name":"myrecord","fields":[{"name":"f1","type":"string"}]}' --property schema.registry.url=http://localhost:8081" command to start the Kafka producer;
2. Use the same terminal, enter "{'f1':'whatever-value'}" command to publish the json record into "c2i_sink" topic.  Please note, the key in the json record must be "f1" and the value must be string type since we use Avro schema to validate. If the key is not "f1", the producer will throw exception and exit;
3. Open a new terminal and change to "<path-to-mongodb>/bin" directory and enter "./mongo" to start a MongoDB client;
4. In the MongoDB client, enter "use sinkdb" command to switch database;
5. Enter "db.sink.find()" command in the MongoDB client to see all the records being inserted into the "sink" collection.

## Summary

1. Since Kafka Connect is a framework and is also a process/service, it is very difficult to debug, especially, if there are any exception during the loading (deployment) process.  So, Kafka Connect is not for connector with complicated logic.  If complex logic is needed, Kafka consumer should be used rather than Kafka Connector;
2. Because the framework handles the commit, user code has no control for it.  So, it is not recommended for connectors that require user code to handle commits.

## References

* Apache Connect Documentation: https://kafka.apache.org/documentation/#connect
* Confluent Connect Documentation: https://docs.confluent.io/current/connect/index.html
* Step-by-step toturial for developing connector: https://hackernoon.com/writing-your-own-sink-connector-for-your-kafka-stack-fa7a7bc201ea
* Debugging Kafka connector: https://stackoverflow.com/questions/45717658/what-is-a-simple-effective-way-to-debug-custom-kafka-connectors/45719652#45719652
* Using Kafka Consumer rather than Kafka Connector: https://hackernoon.com/why-we-replaced-our-kafka-connector-with-a-kafka-consumer-972e56bebb23
