# C2i Standard Templates for Kafka Connect

## Introduction

Kafka Connect is a framework for connecting Kafka with external systems such as databases, key-value stores, search indexes, and file systems.  As a service framework, C2i has implemented a set of Kafka Connect templates to allow application developers to create connections to external sources with a standardized approach.  Currently, we have created,

* c2i-elasticsearch-sink-template.json - reads data from Kafka topic(s) and puts it into an ElasticSearch index or indices.
* c2i-file-sink-template.json - reads data from Kafka topic(s) and puts it into a flat file.
* c2i-file-source-template.json - ingests records from a file and puts them into Kafka topic(s).
* c2i-jdbc-sink-template.json - moves data out of Kafka topic(s) and puts it into databases.
* c2i-jdbc-source-template.json - ingests entire databases and streams table updates to Kafka topics.
* c2i-mssql-sink-template.json - moves data our of Kafka topic(s) and puts it into SQL Server databases.
* c2i-mssql-source-template.json - ingests entire SQL Server database and stream table updates to Kafka topics.
* c2i-oracle-source-template.json - ingests one Oracle table and streams table updates to a Kafka topic.
* c2i-mongo-sink-template.json - reads data from Kafka topic(s) and puts them into Mongodb collections.  Please read README.md in c2i-mongodb-connector project for deploying and running this connector.
* c2i-mongo-source-template.json - reads data from Mongodb oplog and publishes it into Kafka topics. Please read README.md in c2i-mongodb-connector project for deploying and running this connector.

Above is just a basic set of Kafka Connect templates and we will implement connectors in the near future.

## Pre-requisites

Since the above templates rely on the Kafka Connect service, a Kafka broker, and the Schema Registry service, we will need to install and start these services first.  To do that:

1. Download the Confluent Kafka zip file with link https://www.confluent.io/download/
2. Uncompress the downloaded zip file to a folder and write down the path to this folder
3. Go to the bin sub-folder in the folder above and issue the `confluent start` command. This Confluent CLI command starts six services:
	* zookeeper server
	* kafka broker
	* schema-registry service
	* kafka-rest service
	* connect - kafka connect server
	* ksql-server

## Kafka Connect Template Deployment

To deploy a Kafka Connect template:

1. Use one of the templates listed above and modify the properties accordingly, such as database connection properties, file path information, and other corresponding parameters.  Please see the comments in each template file for customization.
2. Copy the template to the `<path-to-confluent>/share/java/kafka-connect-jdbc/` directory.
3. Deploy the template by executing the following command: ``confluent load <connector-name> -d <connector-filename>``, e.g., ``confluent load c2i-file-sink -d /Users/kchen/confluent-4.1.1/share/java/kafka-connect-jdbc/c2i-file-sink-template.json``.

Now, the connector should be running, but you can use the following command to check the connector status, ``confluent status <connector-name>``, e.g., ``confluent status c2i-file-sink``.

As an example of showing the complete process, we,

1. First use the POST endpoint in hello-cotiviti-kafkaWS service to post message to a Kafka topic (avroClient); 
2. Use c2i-file-sink-template.json to move the messages in the Kafka topic (avroClient) to a file (kafka-connect-avroClient.txt);
3. Use c2i-file-source-template.json to read records in a file (kafka-connect-avroClient.txt) into a Kafka topic (avroClient-intermediate);
4. Use hello-cotiviti-kafkaDS daemon service to pull records from a Kafka topic (avroClient-intermediate) to another Kafka topic (avroClient-output);
5. Use the GET endpoint in hello-cotiviti-kafkaWS service to retrieve data from a Kafka topic (avroClient-output) and reponse it back to user.

Following is the list of modification that will need to be done to accomplish the above example,

* application.yml in hello-cotiviti-kafkaWS: modify "consumer.properties.topicName = avroClient-output".
* c2i-file-sink-template.json: modify "file" key to have correct file path and file name.
* c2i-file-source-template.json: modify "file" key to have the file path and file name matching the ones in the last bullet point. Also modify the "topics" key to have "avroClient-intermediate" value.
* application.yml in hello-cotiviti-kafkaDS: modify "consumer.properties.topicName=avroClient-intermediat" and "producer.properties.topicName=avroClient-output".

Now, start every services and load the connectors,

* Start hello-cotiviti-kafkaWS service: ``mvn spring-boot:run``
* Start hello-cotiviti-kafkaDS service: ``mvn spring-boot:run``
* Load c2i-file-sink-template.json: ``confluent load c2i-file-sink -d <path-to-file>/c2i-file-sink-template.json``
* Load c2i-file-source-template.json: ``confluent load c2i-file-source -d <path-to-file>/c2i-file-source-template.json``

Check if the installation is correct,

For accessing GET method - messages (if any) will be pulled from a kafka topic:

```
curl -X GET http://localhost:9082/hello/v1/client
```

For accessing POST method - request body will be re-formatted and published to a kafka topic:

```
curl -X POST http://localhost:9082/hello/v1/client -H "content-type: application/json" -d "{'id':3,'name':'John Dow','accountNumber':'111'}"
```

Please note, the above process flow demonstrates the integration of Kafka clients (producer and consumer), Kafka topics, and file stream sink & source connectors.  But due to the limitation that FileStreamSourceConnector is not capable of serializing messages into Avro objects, it will not demonstrate the support of Avro schema evolution.  To see Avro schema evolution, make the producer and consumer in hello-cotiviti-kafkaWS have the same topic.  This is essentially by-passing Kafka Connect modules.  In the future, we will modify FileStreamSourceConnector class to read record string from file and convert it into Avro object.

## Run SQL Server Connectors

We have added two connectors to handle SQL Server database.  Before we provide the steps to test the connectors, we outline the process flow for running these connectors,
```bash
developer uses sqlcmd to insert data into foobar table => 
c2i-mssql-source connector reads record from foobar table and put it into c2i-mssql-foobar Kafka topic => 
c2i-mssql-sink connector reads messages from c2i-foobar Kafka topic and put them into c2i-mssql-foobar table => 
developer uses sqlcmd to select records from c2i-mssql-foobar table to verify the records
```
We assume the environment running these connectors is a Linux OS for now.  We will provide Windows OS instruction later.  To simplify the installation, we will use SQL Server Linux Docker image.  So, the environment will need to have Docker engine installed.  Following is the list of steps to perform the installation and running the tests,

1. Download Microsoft SQL Server JDBC driver from: http://central.maven.org/maven2/com/microsoft/sqlserver/mssql-jdbc/7.0.0.jre8/mssql-jdbc-7.0.0.jre8.jar
2. Copy the downloaded SQL Server JDBC driver to `<path-to-confluent>/share/java/kafka-connect-jdbc` folder
3. Pull SQL Server Linux image: ``docker pull microsoft/mssql-server-linux``
4. Start a mssql-server instance running as the SQL Express edition: ``docker run -e 'ACCEPT_EULA=Y' -e 'SA_PASSWORD=yourStrong@Password' -e 'MSSQL_PID=Express' -p 1433:1433 -d microsoft/mssql-server-linux:latest``
5. Find the instance container id and copy it: ``docker ps``
6. Connect to the mssql-server instance using sqlcmd tool: ``docker exec -it <container id> /opt/mssql-tools/bin/sqlcmd -S localhost -U sa -P yourStrong@Password``
7. Create new database: ``CREATE DATABASE testConnectors``
8. Press Enter and then: ``go``
9. Use the newly created database: ``use testConnectors``
10. Press Enter and then: ``go``
11. Create foobar table in the sqlcmd establised above: ``create table foobar (c1 int, c2 varchar(255),create_ts DATETIME DEFAULT GETDATE() , update_ts DATETIME DEFAULT GETDATE())``
12. Press enter and then: ``go``
13. Start Confluent as mentioned before
14. Load these two connectors with: ``confluent load <connector-name> -d <path-to-connector>/<connector-file-name>``
15. Insert record into the foobar table: ``insert into foobar (c1, c2) values (1, 'value1')``
16. Check if the records are put into c2i-mssql-foobar topic: ``kafka-avro-console-consumer --bootstrap-server localhost:9092 --topic c2i-mssql-foobar --from-beginning``
17. Check if the records are being inserted into c2i-mssql-foobar table: ``select * from "c2i-mssql-foobar"``

You should see that the records in the foobar table should be exactly the same as the `c2i-mssql-foobar` table.  If they are not the same, something is incorrect.