# Framework Utility Library

## Introduction

This is a utility project that has all custom functions for enforcing Web Service Framework standard. The example project in hello-spring provides the usage of these utility functions. The developer guide for developing Web Service Framework will give detailed information for using this library to create compliant web services.

## Building Application

This project is referred to by every other project and will need to be compiled first.  To compile this project,

```
	mvn install
```
