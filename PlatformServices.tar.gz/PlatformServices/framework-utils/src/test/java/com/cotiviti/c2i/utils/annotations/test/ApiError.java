/**
 * Copyright (C) 2018 Cotiviti Digital (nexgen.admin@cotiviti.io)
 *
 * The software code contained herein is the property of Cotiviti Corporation
 * and its subsidiaries and affiliates (collectively, “Cotiviti”).
 * Access to this software code is being provided to you in the course of your
 * employment or affiliation with Cotiviti and may be used solely in the scope
 * and course of your work for Cotiviti, and is for internal Cotiviti use only.
 * Any unauthorized use, disclosure, copying, distribution, destruction of this
 * software code, or the taking of any unauthorized action in reliance on this
 * software code, is strictly prohibited.
 * If this information is viewed in error, immediately discontinue use of the
 * application.  Anyone using this software code and the applications will be
 * subject to monitoring for improper use, system maintenance and security
 * purposes, and is advised that if such monitoring reveals possible criminal
 * activity or policy violation, Cotiviti personnel may provide the evidence of
 * such monitoring to law enforcement or other officials, and the user may be
 * subject to disciplinary action by Cotiviti, up to and including termination
 * of employment.
 *
 * Use of this software code and any applications and information therein
 * constitutes acknowledgement of and consent to this notice
 */
package com.cotiviti.c2i.utils.annotations.test;

import org.springframework.http.HttpStatus;
import org.springframework.validation.Errors;
import org.springframework.validation.FieldError;
import org.springframework.validation.ObjectError;

import java.util.ArrayList;
import java.util.Collection;
import java.util.List;

public class ApiError {
    private HttpStatus httpStatus = HttpStatus.UNPROCESSABLE_ENTITY;

    private String code;

    private String message;

    private List<ObjectError> globalErrors = new ArrayList<>();

    private List<FieldError> fieldErrors = new ArrayList<>();

    public List<ObjectError> getGlobalErrors() {
        return this.globalErrors;
    }

    public List<FieldError> getFieldErrors() {
        return this.fieldErrors;
    }

    public ApiError addFieldErrors(Collection<? extends FieldError> fieldErrors) {
        this.fieldErrors.addAll(fieldErrors);

        return this;
    }

    public ApiError addFieldError(FieldError fieldError) {
        this.fieldErrors.add(fieldError);
        return this;
    }

    public ApiError addFieldError(String fieldName, String code, String message) {
        FieldError error = new FieldError("ApiError", fieldName, null, false, new String[]{code}, null, message);
        this.fieldErrors.add(error);

        return this;
    }

    public ApiError addGlobalError(String objectName, String detailedMessages) {
        this.globalErrors.add(new ObjectError(objectName, detailedMessages));
        return this;
    }

    public ApiError addGlobalError(ObjectError globalError) {
        this.globalErrors.add(globalError);
        return this;
    }

    public ApiError addGlobalErrors(Collection<? extends ObjectError> globalErrors) {
        this.globalErrors.addAll(globalErrors);
        return this;
    }

    public ApiError withHttpStatus(HttpStatus httpStatus) {
        this.httpStatus = httpStatus;
        return this;
    }

    public HttpStatus getHttpStatus() {
        return httpStatus;
    }

    public int getHttpStatusCode() {
        return httpStatus.value();
    }

    public void setCode(String code) {
        this.code = code;
    }

    public String getCode() {
        return code;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    public static ApiError of(Errors errors) {
        ApiError apiError = new ApiError();
        apiError.addGlobalErrors(errors.getGlobalErrors());
        apiError.addFieldErrors(errors.getFieldErrors());

        return apiError;
    }
}