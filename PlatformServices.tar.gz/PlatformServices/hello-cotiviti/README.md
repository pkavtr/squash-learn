# Framework Web Service Sample

## Introduction

c2i web services use pessimistic security approach - allow no api methods to be accessed without authentication except methods that are specifically permitted in security configuration.  The specific example of the methods require authentication is in the com.cotiviti.c2i.sample.api.CustomerController class.  Resources/methods without authentication are the swagger-ui.html.

## Building Application

```
mvn clean install
```

## Run Application

### Embedded Tomcat

To run the application with embedded tomcat,

```
mvn spring-boot:run
```

or

```
java -jar target/hello-cotiviti-0.0.1-RELEASE.war
```

The default port is 9081.  

### Stand-Alone Tomcat

Following is the list of steps for deploying the war file of this sample application to a stand-alone tomcat server,

1. build the war file with maven: ```mvn clean install```
2. copy the created war file in the target directory to tomcat webapps folder: ```cp target/hello-cotiviti-0.0.1-RELEASE.war $TOMCAT_HOME/webapps/hello```
3. start tomcat with command: ```$TOMCAT_HOME/bin/startup.sh``` in linux or ```$TOMCAT_HOME/bin/startup.bat``` in Windows

## Integration Tests

1. To access the api document, use the following link with corresponding server port:

```
http://localhost:{port}/hello/swagger-ui.html
```

2. To access the info end point for application meta-data, use the following link with corresponding server port,

```
http://localhost:{port}/hello/actuator/info
```

3. To access the health end point for application health, use the following link with corresponding server port,
```
http://localhost:{port}/hello/actuator/health
```

4. To access the customers api with a windows domain user,

For accessing GET method:

```
curl http://localhost:{port}/hello/v1/customers/1 

curl http://localhost:{port}/hello/v2/customers/1 -H "content-type: application/json"
```

For accessing POST method:

```
curl -X POST http://localhost:{port}/hello/v1/customers

curl -X POST http://localhost:{port}/hello/v2/customers 
```

Please pay attention to the request url, "v1" or "v2", for demonstration of the different responses with different versions.
