/**
 * Copyright (C) 2018 Cotiviti Digital (nexgen.admin@cotiviti.io)
 *
 * The software code contained herein is the property of Cotiviti Corporation
 * and its subsidiaries and affiliates (collectively, “Cotiviti”).
 * Access to this software code is being provided to you in the course of your
 * employment or affiliation with Cotiviti and may be used solely in the scope
 * and course of your work for Cotiviti, and is for internal Cotiviti use only.
 * Any unauthorized use, disclosure, copying, distribution, destruction of this
 * software code, or the taking of any unauthorized action in reliance on this
 * software code, is strictly prohibited.
 * If this information is viewed in error, immediately discontinue use of the
 * application.  Anyone using this software code and the applications will be
 * subject to monitoring for improper use, system maintenance and security
 * purposes, and is advised that if such monitoring reveals possible criminal
 * activity or policy violation, Cotiviti personnel may provide the evidence of
 * such monitoring to law enforcement or other officials, and the user may be
 * subject to disciplinary action by Cotiviti, up to and including termination
 * of employment.
 *
 * Use of this software code and any applications and information therein
 * constitutes acknowledgement of and consent to this notice
 */
package com.cotiviti.c2i.integration;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNull;
import org.json.JSONException;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.context.SpringBootTest.WebEnvironment;
import org.springframework.boot.test.web.client.TestRestTemplate;
import org.springframework.boot.web.server.LocalServerPort;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.test.context.junit4.SpringRunner;

import com.cotiviti.c2i.integration.model.CustomerV3;


@RunWith(SpringRunner.class)
@SpringBootTest(webEnvironment=WebEnvironment.RANDOM_PORT)
public class C2iHTTPStatusMessagesTest {

	@LocalServerPort
	private int port;

	private TestRestTemplate template = new TestRestTemplate();
	
	private static Logger log = LoggerFactory.getLogger(C2iHTTPStatusMessagesTest.class);
	
	@Test
	// HTTP STATUS - 404 (NOT FOUND)
	public void httpNOT_FOUNDStatusTest() {
		log.debug("entered httpNOT_FOUNDStatusTest");
		HttpHeaders headers = new HttpHeaders();
		headers.setContentType(MediaType.APPLICATION_JSON);
		HttpEntity<Object> entity = new HttpEntity<Object>(headers);

		ResponseEntity<String> response = template.exchange("http://localhost:{port}/integrationTest/v1/jsonCustomers/97881", HttpMethod.GET, entity, String.class, port);	    
		assertEquals(HttpStatus.NOT_FOUND, response.getStatusCode());

		String auth = response.getHeaders().getFirst("WWW-Authenticate");
		assertNull(auth);
	}
	
	@Test
	// HTTP STATUS - 415 (Unsupported Media Type)
	public void httpStatusUnsupportedMediaTypeTest() {    
		log.debug("entered httpStatusUnsupportedMediaTypeTest");
		ResponseEntity<String> response = template.exchange("http://localhost:{port}/integrationTest/v1/jsonCustomers/9788", HttpMethod.GET, null, String.class, port);	    
		assertEquals(HttpStatus.UNSUPPORTED_MEDIA_TYPE, response.getStatusCode());

		String auth = response.getHeaders().getFirst("WWW-Authenticate");
		assertNull(auth);
	}
	
	@Test
	// HTTP STATUS - 400 (Bad Request/Malformed URI)
	public void testRetrieveCustomersByMalformedURI() throws JSONException {
		log.debug("entered testRetrieveCustomersByMalformedURI");
		HttpHeaders headers = new HttpHeaders();
		headers.setContentType(MediaType.APPLICATION_JSON);
		HttpEntity<Object> entity = new HttpEntity<Object>(headers);

		ResponseEntity<CustomerV3> response = template.exchange(
				"http://localhost:{port}/integrationTest/v1/jsonCustomers/61907ghjj", HttpMethod.GET, entity,
				CustomerV3.class, port);

		assertEquals("Expecting Error code", HttpStatus.BAD_REQUEST, response.getStatusCode());

	}
	
	// HTTP STATUS - 400 (Bad Request/Malformed URI with  All Special Character other than ? # %)
	@Test
	public void testMalformedURIByAllSpecialCharecters() {
		log.debug("entered testMalformedURIByAllSpecialCharecters");
		HttpHeaders headers = new HttpHeaders();
		headers.setContentType(MediaType.APPLICATION_JSON);
		HttpEntity<Object> entity = new HttpEntity<Object>(headers);

		ResponseEntity<CustomerV3> response = template.exchange(
				"http://localhost:{port}/integrationTest/v1/jsonCustomers/61907*&*&", HttpMethod.GET, entity,
				CustomerV3.class, port);

		assertEquals(HttpStatus.BAD_REQUEST, response.getStatusCode());
	}
}
