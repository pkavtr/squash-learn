# Creating C2i Web Service Framework Compliant Jenkins Pipeline

## Introduction

This document provides a template and the steps to create a Jenkins CI/CD process for web service projects that are based on the C2i Web Service Framework.  Please refer to the Service Framework Developer Guide to develop application services.  Also, refer to the ["Creating_CICD_Process" document](Creating_CICD_Process.md) to have all the pre-requiesites completed before creating a Jenkins job.

## Configuration of Jenkins CI/CD Process

For the C2i Web Service Framework, the Jenkins CI/CD process (CWSFP) has been configured with a Multibranch Pipeline and it will serve as the standard template for other application services that are based on the framework to create their Jenkins CI/CD processes.  CWSFP uses Jenkins Declarative Pipeline syntax instead of Scripted Pipeline syntax. It performs the following tasks (stages) to complete the CI/CD process:

01. Declarative Checkout SCM - pulls source code from github based on the provided credentials and repository url;
02. Declarative Tool Install - defines maven with a specific version as the build tool and JDK version for the build;
03. Initialize - initializes the predefined tools and environment variables for the build process;
04. Build & Unit Test - uses the predefined maven tool to build the project and then perform unit tests.  If the build or unit tests failed, the process stops and goes to step 12;
05. Integration tests - executes a project that has been specifically created to test different scenarios to make sure the system is working correctly.  This task is desirable and each project team should make an effort to create one.  However, it is not a required task for a CI/CD process since unit tests and sanity tests after the deployment task (along with user acceptance tests (UAT) outside the CI/CD process) are the natural tests to achieve the same goal. Just like step 4, if any tests fail, the process will stop and go to step 12;
06. Sonar Scan Analysis - uses Sonarqube to scan through all the source code to find all the issues related to security, maintainability, reliability, anti-patterns, etc., and provides an aggregated report to allow decisions about the code quality.  If there are any connection issues to the Sonarqube server, it will also stop and go to step 12;
07. Sonar Scan Result Check - checks the result from step 6 to see if the code quality passes the quality gate defined in the Sonarqube server. If the quality gate is not passed, the process is stopped and goes to step 12.  Since this task requires a webhook from the Sonarqube server to provide the analysis results to the pipeline, and the webhook has to be configured by the Sonarqube server administrator, it is temporarily disabled until the webhook can be configured;
08. Publish Release Artifacts - uploads release artifacts to the release repo in Nexus (for the master branch only).  This task will not be used--at least for now--since artifacts are not allowed to be uploaded to the release repo in Labs Nexus through a Jenkins pipeline.  As the process stands currently, the release artifacts will be created and uploaded to the release repo by the Labs team manually after sending a message to @meredith in Slack with the project name and tag name in the master branch;
09. Publish & Scan Develop Artifacts - this task consists of two tasks executed simultaneously:

  * Publish Develop Artifacts - uploads non-release artifacts to the snapshot repo in Nexus (for the develop branch only).  With the current design, artifacts from other branches are not uploaded to Nexus.  If there are any errors during the uploading process, the process is stopped and goes to step 12;
  * Veracode Scan Develop Artifacts - upload the generated artifacts (jar or war files) to the Veracode server to allow it to scan for any security vulnerability issues.  If the vulnerability scan failed or connection to the server failed, the process will stop and go to step 12;
10. Deploy War File to Dev Server - scp the generated war file to a tomcat container in a development server.  For now, we use norgenhdpdev04.ccaintranet.com server as our development server.  There should be a new development server soon.  If there are any issues during scp files to the server, the process will stop and route to step 12;
11. Check War File Deployed Successfully - sends sanity test to the web service deployed to the tomcat container in the development server.  If the response status code is not 200, it will route to step 12;
12. Declarative Post Actions - sends email to specified users based on the pipeline execution status.  

### Template Customization

As mentioned in the previous section, CWSFP uses a Jenkins Multibranch Pipeline project that requires a Jenkinsfile.  Its Jenkinsfile can be found from <https://github.com/cotiviti/PlatformServices/blob/features/labsNexus/Jenkinsfile-stages>.  This file has been developed with reusability in mind and can be used by most web service projects with just a few customizations.  Please refer to the file in the [Reference](#reference) section of this document to see the places that must be customized according to the list below:

* \<list-of-email-addresses> - comma-delimited list of email addresses;
* \<integration-tests-project-name> - the project name that contains the integration tests.  If you do not have an integration test project for your repo, the "Integration tests" stage needs to be removed or commented out;
* \<detail-project-name> - the name your application was given on the Veracode site;
* \<unique-name-for-project> -  the prefix for scan names uploaded to Veracode (according to the Security Team's naming convention);
* \<username-in-comma-delimited> - list of user names that can approve the action;
* \<user-credential-with-ssh-key> - a Jenkins credential that is used to scp and ssh to the norgenhdpdev04.ccaintranet.com development server.  A Jenkins administrator can set up the SSH key generated above with "Credentials -> Add Credentials" in Jenkins.
* \<url-to-test-web-service-endpoint> -  the url of the web service being deployed to the development server;
* \<project-name> - the project name of the web service being built and deployed in the pipeline;
* \<project-name-path> - the url path used by the web service endpoint.

After customization, put the file into the project and write down the path to the file in the project hierarchy.  The name of the file can be any valid Linux file name.

### Jenkins Configuration

The last task is to create the Jenkins process to use the customized Jenkinsfile.  One of the reasons to use a Multibranch Pipeline is that is can build any branches that have a defined Jenkinsfile in them.  This will allow errors to be caught as early as possible for any commits.  Below are the steps to create a Jenkins Multibranch Pipeline project:

1. Log in to the C2i Jenkins instance and click on "New Item";
2. Provide a descriptive name for the process and then select "Multibranch Pipeline" and then click on "OK";
3. Click on "Add source" under the "Branch Sources" section and select "Git";
4. Enter the repository link in the "Project Repository" field.  The link should be something like "git@github.com:cotiviti/<project-name>.git;
5. Select the credential if the credential exists or "Add" new credential with the SSH key generated above;
6. In the "Build Configuration" section, select "by Jenkinsfile" mode and enter the path to Jenkins file customized above (from the root of the project) in the "Script Path" field;
7. The "Periodically if not otherwise run" checkbox may be selected, but this is not recommended since it can waste Jenkins server resources even there are no changes.  The optimal way to do it is to use a webhook of the project to trigger a Jenkins build once a user commits.  However, the configuration of webhooks for each project must be done by github administrators. Right now, we do not know who those administrators are or who can help us to set it up.  So, it is a manual process to trigger the build process for now;
8. Click on "Apply" to save the configuration and start the process.

Please note, every single branch with a Jenkins file matching the name and path specified in the Multibranch Pipeline configuration will be built.

## Reference

~~~~

#!/usr/bin/groovy
import java.text.SimpleDateFormat
def date
def buildDate

pipeline {
  // This Jenkinsfile is used to create framework-utils and framework-parent libraries
  // It will call other Jenkins jobs to deploy artifacts to different environments
  agent any
  environment {
      EMAIL_RECIPIENTS = '<list-of-email-addresses>'
  }
  tools {
  maven 'Maven-3.5.4'
  jdk 'JDK8'
  }
  stages {
    stage ('Initialize') {
      steps {
        sh '''
        echo "PATH = ${PATH}"
        echo "M2_HOME = ${M2_HOME}"
        echo "JAVA_HOME = ${JAVA_HOME}"
        '''
      }
    }
    stage('Build & Unit Test') {
      // if the pom.xml is not in the root path provide the location of the pom (-f) as a relative path
      steps {
        script {
          configFileProvider([configFile(fileId: '3d4cf3d0-c4a8-449a-b346-2d910d4947db', variable: 'MAVEN_SETTINGS')]) {
            sh "mvn clean install -s $MAVEN_SETTINGS"
          }
        }
      }
      post {
        success {
          junit '**/target/surefire-reports/*.xml'
        }
      }
    }
    stage('Integration tests') {
      // Run integration test
      steps {
        script {
          // just to trigger the integration test project
          configFileProvider([configFile(fileId: '3d4cf3d0-c4a8-449a-b346-2d910d4947db', variable: 'MAVEN_SETTINGS')]) {
            sh "mvn -f <integration-tests-project-name>/pom.xml test -s $MAVEN_SETTINGS"
          }
        }
      }
      post {
        success {
          junit '<integration-tests-project-name>/target/surefire-reports/*.xml'
        }
      }
    }
    // sonar scan
    stage('Sonar Scan Analysis') {
      steps {
        // version of installed sonarqube
        script { scannerHome = tool 'SonarQube-Scanner-3.2.0.1227' }
        // name of Sonar in Jenkins configuration
        withSonarQubeEnv('SonarSecuirty') {
          configFileProvider([configFile(fileId: '3d4cf3d0-c4a8-449a-b346-2d910d4947db', variable: 'MAVEN_SETTINGS')]) {
            sh 'mvn org.sonarsource.scanner.maven:sonar-maven-plugin:3.4.1.1168:sonar -s $MAVEN_SETTINGS'
          }
        }
      }
    }
    stage('Sonar Scan Result Check') {
      steps {
        sh '''
        echo "temporarily disable sonarqube quality gate as webhook is required to trigger Jenkins once the calculation has done."
        '''
      }
    }
    stage('Publish Release Artifacts') {
      when {
        branch 'master'
      }
      steps {
        script {
          echo "for release send notification to slack user @meredith"
          //currently doing this manually
          //publishArtifacts('master')
        }
      }
    }
    stage('Publish & Scan Develop Artifacts') {
      when {
        branch 'develop'
      }
      // publish and scan artifacts parallelly
      parallel {
        stage('Publish Develop Artifacts') {
          steps {
            script {
              publishArtifacts('develop')
            }
          }
        }
        stage('Veracode Scan Develop Artifacts') {
          steps {
            script {
              date = new Date()
              sdf = new SimpleDateFormat("MMddyy")
              buildDate = sdf.format(date)
            }
            withCredentials([[$class: 'UsernamePasswordMultiBinding', credentialsId: 'VeracodeUser', passwordVariable: 'veracode_password', usernameVariable: 'veracode_username']]) {
              veracode applicationName: '<detail-project-name>', createProfile: false, createSandbox: false,
              criticality: 'High', debug: true, fileNamePattern: '', replacementPattern: '',
              scanExcludesPattern: '', scanIncludesPattern: '', scanName: "<unique-name-for-project>_${env.BUILD_NUMBER}_${buildDate}_Static", teams: '', uploadExcludesPattern: '',
              uploadIncludesPattern: '**/**.jar', useIDkey: true, vid: veracode_username, vkey: veracode_password
            }
          }
        }
      }
    }
    // copy generated war file to dev/qa server so tomcat can use use it
    stage('Deploy War File to Dev Server') {
      steps {
        script {
          timeout(time: 3, unit: 'MINUTES') {
            // you can use the commented line if u have specific user group who CAN ONLY approve
            // input message:'Approve deployment?', submitter: 'it-ops'
            input message: 'Approve deployment?', submitter:'<username-in-comma-delimited>', submitterParameter: 'APPROVER'
          }
          deployed = true
          // this need to change to have ssh key to be setup to access the Dev server
          sshagent(credentials: ['<user-credential-with-ssh-key>']) {
            // following will need to change dev server ip or dns name
            sh 'ssh -o StrictHostKeyChecking=no <username>@norgenhdpdev04.ccaintranet.com rm apache-tomcat-8.0.53/webapps/<project-name-path>.war || true'
            sh 'ssh -o StrictHostKeyChecking=no <username>@norgenhdpdev04.ccaintranet.com rm -rf apache-tomcat-8.0.53/webapps/<project-name-path> || true'
            sh 'scp -o StrictHostKeyChecking=no <project-name>/target/*.war <username>@norgenhdpdev04.ccaintranet.com:apache-tomcat-8.0.53/webapps/<project-name-path>.war'
          }
        }
      }
    }
    // add other war files to other environments
    // check if the deployment of the war file is successful
    stage('Check War File Deployed Successfully') {
      // if deployed, we will check it is successful.  Otherwise, no need to check
      when {
        expression {
          return "${deployed}";
        }
      }
      steps {
        // if 30 second delay time is not here, checking request to the url will always return error.
        sleep 60
        timeout(time:30, unit: 'SECONDS') {
          retry(3) {
            script {
              def response = httpRequest '<url-to-test-web-service-endpoint>'

              echo "Response: ${response.content}"
              // checking the response status to make sure the deployment is good.
              if ("${response.status}" != "200") {
                error "Deployment is unsuccessful because the response status of the http request is ${response.status}"
              }
            }
          }
        }
      }
    }
  }
  post {
    // Always runs. And it runs before any of the other post conditions.
    always {
      // Let's wipe out the workspace before we finish!
      echo 'One way or another, I have finished'
      deleteDir()
    }
    success {
      echo 'sending build successful email.'
      sendEmail("Successful");
    }
    unstable {
      echo 'sending build unstable email.'
      sendEmail("Unstable");
    }
    failure {
      echo 'sending build failure email.'
      sendEmail("Failed");
    }
    aborted {
      echo 'sending build aborted email.'
      sendEmail("Aborted");
    }
  }
}

def developmentArtifactVersion = ''
def releasedVersion = ''
def git_branch = ''
def deployed = false

// get change log to be send over the mail
//@NonCPS
def getChangeString() {
  MAX_MSG_LEN = 100
  def changeString = ""

  echo "Gathering SCM changes"
  def changeLogSets = currentBuild.changeSets
  for (int i = 0; i < changeLogSets.size(); i++) {
    def entries = changeLogSets[i].items
    for (int j = 0; j < entries.length; j++) {
      def entry = entries[j]
      truncated_msg = entry.msg.take(MAX_MSG_LEN)
      changeString += " - ${truncated_msg} [${entry.author}]\n"
    }
  }
  if (!changeString) {
      changeString = " - No new changes"
  }
  return changeString
}

def sendEmail(status) {
  mail(
  to: "$EMAIL_RECIPIENTS",
  subject: "Build $BUILD_NUMBER - " + status + " (${currentBuild.fullDisplayName})",
  body: "Changes:\n " + getChangeString() + "\n\n Check console output at: $BUILD_URL/console" + "\n")
}

def getVersion(branchName) {
  def pom = readMavenPom file: 'pom.xml'
  def gitCommit = sh(returnStdout: true, script: 'git rev-parse HEAD').trim()
  def versionNumber;
  if (gitCommit == null) {
    versionNumber = env.BUILD_NUMBER;
  } else {
    versionNumber = gitCommit.take(8);
  }
  def finalVersionNumber
  if (branchName == 'master')
    finalVersionNumber = "RELEASE" + ".${versionNumber}"
  if (branchName == 'develop')
    finalVersionNumber = "DEVELOP" + ".${versionNumber}"
  return pom.version.replace("SNAPSHOT", "${finalVersionNumber}")
}

def publishArtifacts(branchName) {
  //def mvnHome = tool 'Maven 3.3.1'
  def mvnHome = tool 'Maven-3.5.4'
  if (currentBuild.result == null || currentBuild.result == 'SUCCESS') {
    def v = getVersion(branchName)
    releasedVersion = v;
    if (v) {
        echo "Building version ${v} - so released ${branchName} is ${releasedVersion}"
    }
    //if (branchName == 'master') {
    //  // not sure if this sshagent is needed or not.  If needed, it will need to be setup
    //  sshagent(['00fd4893-f203-42ac-bb61-57b65fd43480']) {
    //    sh "git tag -f v${v}"
    //    sh "git push -f --tags https://eebeee5f9af70dd48782ad6de184fe76718de929@github.com/cotiviti/PlatformServices.git"
    //  }
    }
    // versioning scheme, when we'll have our own service account for nexus
    //sh "'${mvnHome}/bin/mvn' -Dmaven.test.skip=true  versions:set  -DgenerateBackupPoms=false -DnewVersion=${v} -s $MAVEN_SETTINGS"
    // following will deploy artifacts to Labs Nexus under https://artifacts.cotiviti.io/repository/public/
    configFileProvider([configFile(fileId: '3d4cf3d0-c4a8-449a-b346-2d910d4947db', variable: 'MAVEN_SETTINGS')]) {
      sh "'${mvnHome}/bin/mvn' deploy -Dmaven.test.skip=true -s $MAVEN_SETTINGS"
    }
  } else {
    error "Release is not possible. as build is not successful"
  }
}
~~~~