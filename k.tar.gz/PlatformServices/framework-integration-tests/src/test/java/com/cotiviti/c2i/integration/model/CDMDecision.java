/**
 * Copyright (C) 2018 Cotiviti Digital (nexgen.admin@cotiviti.io)
 *
 * The software code contained herein is the property of Cotiviti Corporation
 * and its subsidiaries and affiliates (collectively, “Cotiviti”).
 * Access to this software code is being provided to you in the course of your
 * employment or affiliation with Cotiviti and may be used solely in the scope
 * and course of your work for Cotiviti, and is for internal Cotiviti use only.
 * Any unauthorized use, disclosure, copying, distribution, destruction of this
 * software code, or the taking of any unauthorized action in reliance on this
 * software code, is strictly prohibited.
 * If this information is viewed in error, immediately discontinue use of the
 * application.  Anyone using this software code and the applications will be
 * subject to monitoring for improper use, system maintenance and security
 * purposes, and is advised that if such monitoring reveals possible criminal
 * activity or policy violation, Cotiviti personnel may provide the evidence of
 * such monitoring to law enforcement or other officials, and the user may be
 * subject to disciplinary action by Cotiviti, up to and including termination
 * of employment.
 *
 * Use of this software code and any applications and information therein
 * constitutes acknowledgement of and consent to this notice
 */
package com.cotiviti.c2i.integration.model;

import java.util.List;

public class CDMDecision {
	private int key;

	private String decision;

	private String clientName;

	private String cdmModifications;

	private List<String> payers;

	private List<String> insurance;

	private List<String> claimType;

	private List<String> midRule;

	private String release;

	public void setKey(int key) {
		this.key = key;
	}

	public int getKey() {
		return this.key;
	}

	public void setDecision(String decision) {
		this.decision = decision;
	}

	public String getDecision() {
		return this.decision;
	}

	public void setClientName(String clientName) {
		this.clientName = clientName;
	}

	public String getClientName() {
		return this.clientName;
	}

	public void setCdmModifications(String cdmModifications) {
		this.cdmModifications = cdmModifications;
	}

	public String getCdmModifications() {
		return this.cdmModifications;
	}

	public void setPayers(List<String> payers) {
		this.payers = payers;
	}

	public List<String> getPayers() {
		return this.payers;
	}

	public void setInsurance(List<String> insurance) {
		this.insurance = insurance;
	}

	public List<String> getInsurance() {
		return this.insurance;
	}

	public void setClaimType(List<String> claimType) {
		this.claimType = claimType;
	}

	public List<String> getClaimType() {
		return this.claimType;
	}

	public void setMidRule(List<String> midRule) {
		this.midRule = midRule;
	}

	public List<String> getMidRule() {
		return this.midRule;
	}

	public void setRelease(String release) {
		this.release = release;
	}

	public String getRelease() {
		return this.release;
	}
}
