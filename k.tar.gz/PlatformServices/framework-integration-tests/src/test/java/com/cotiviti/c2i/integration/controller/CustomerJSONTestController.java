/**
 * Copyright (C) 2018 Cotiviti Digital (nexgen.admin@cotiviti.io)
 *
 * The software code contained herein is the property of Cotiviti Corporation
 * and its subsidiaries and affiliates (collectively, “Cotiviti”).
 * Access to this software code is being provided to you in the course of your
 * employment or affiliation with Cotiviti and may be used solely in the scope
 * and course of your work for Cotiviti, and is for internal Cotiviti use only.
 * Any unauthorized use, disclosure, copying, distribution, destruction of this
 * software code, or the taking of any unauthorized action in reliance on this
 * software code, is strictly prohibited.
 * If this information is viewed in error, immediately discontinue use of the
 * application.  Anyone using this software code and the applications will be
 * subject to monitoring for improper use, system maintenance and security
 * purposes, and is advised that if such monitoring reveals possible criminal
 * activity or policy violation, Cotiviti personnel may provide the evidence of
 * such monitoring to law enforcement or other officials, and the user may be
 * subject to disciplinary action by Cotiviti, up to and including termination
 * of employment.
 *
 * Use of this software code and any applications and information therein
 * constitutes acknowledgement of and consent to this notice
 */
package com.cotiviti.c2i.integration.controller;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.ResponseStatus;

import com.cotiviti.c2i.integration.model.CustomerV3;
import com.cotiviti.c2i.integration.service.CustomerService;
import com.cotiviti.c2i.validation.annotations.C2iApiFormat;
import com.cotiviti.c2i.validation.annotations.C2iRestController;


@C2iApiFormat
@C2iRestController
public class CustomerJSONTestController {

	@Autowired
	private CustomerService oCustomerService;
	private static Logger log = LoggerFactory.getLogger(CustomerJSONTestController.class);

	//API to read json from header section
	@RequestMapping(method=RequestMethod.GET,value="/v1/jsonCustomers",consumes="application/json",produces="application/json")
	public List<CustomerV3> getAllCustomers(){
		return  oCustomerService.getListofCustomers();
	}
	
	@RequestMapping(method=RequestMethod.GET,value="/v1/jsonCustomers/{id}",consumes="application/json",produces="application/json")
	@ResponseBody
	public ResponseEntity<CustomerV3> getCustomersBy(@PathVariable int id)
	{
		CustomerV3 customerV3 = oCustomerService.getCustomersBy(id);
		if (customerV3!=null)
			return new ResponseEntity<CustomerV3>(customerV3, HttpStatus.OK);
		
		return new ResponseEntity<>(HttpStatus.NOT_FOUND);
	}

	
	//API to read json from header section
	@RequestMapping(method=RequestMethod.POST,value="/v1/jsonCustomers",consumes="application/json",produces="application/json")
	@ResponseStatus(HttpStatus.CREATED)
	public  CustomerV3 addcustomerDataFromJson(@RequestBody CustomerV3 customer) {
		return oCustomerService.addCustomer(customer);
	}
	
	// API to read json from header section for put method
	@RequestMapping(method = RequestMethod.PUT, value = "/v1/jsonCustomers/{id}",
			consumes = "application/json", produces = "application/json")
	public ResponseEntity<CustomerV3> updateCustomer(@PathVariable int id) {

		CustomerV3 currentCustomer = oCustomerService.getCustomersBy(id);
		if (currentCustomer == null) {
			return new ResponseEntity<CustomerV3>(HttpStatus.NOT_FOUND);
		}
		currentCustomer.setId(CustomerService.TEST_CUSTOMER_ID);
		currentCustomer.setName("sample");
		currentCustomer.setRole("AutoTesting");
		oCustomerService.updateCustomer(currentCustomer);

		return new ResponseEntity<CustomerV3>(HttpStatus.OK);
	}	
	
	@RequestMapping(method = RequestMethod.DELETE, value = "/v1/jsonCustomers/{id}")
	@ResponseStatus(HttpStatus.NO_CONTENT)
	@ResponseBody
	public void deleteCustomerById(@PathVariable final int id) {
		oCustomerService.deleteCustomer(id);
	}

	
}
