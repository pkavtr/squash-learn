/**
 * Copyright (C) 2018 Cotiviti Digital (nexgen.admin@cotiviti.io)
 *
 * The software code contained herein is the property of Cotiviti Corporation
 * and its subsidiaries and affiliates (collectively, “Cotiviti”).
 * Access to this software code is being provided to you in the course of your
 * employment or affiliation with Cotiviti and may be used solely in the scope
 * and course of your work for Cotiviti, and is for internal Cotiviti use only.
 * Any unauthorized use, disclosure, copying, distribution, destruction of this
 * software code, or the taking of any unauthorized action in reliance on this
 * software code, is strictly prohibited.
 * If this information is viewed in error, immediately discontinue use of the
 * application.  Anyone using this software code and the applications will be
 * subject to monitoring for improper use, system maintenance and security
 * purposes, and is advised that if such monitoring reveals possible criminal
 * activity or policy violation, Cotiviti personnel may provide the evidence of
 * such monitoring to law enforcement or other officials, and the user may be
 * subject to disciplinary action by Cotiviti, up to and including termination
 * of employment.
 *
 * Use of this software code and any applications and information therein
 * constitutes acknowledgement of and consent to this notice
 */
package com.cotiviti.c2i.utils.configs;

import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Import;

import com.cotiviti.c2i.common.configs.C2iCommonConfig;
import com.cotiviti.c2i.security.configs.C2iSecurityConfig;
import com.cotiviti.c2i.validation.configs.C2iValidationConfig;

import lombok.extern.slf4j.Slf4j;
import springfox.documentation.swagger2.annotations.EnableSwagger2;

/**
 * This class sets up all the necessary plumbing for c2i web service to work
 * correctly.
 * 
 * Since we are using spring boot, the main class that starts the spring boot
 * application should extend this class and it will inject all required bean or
 * configuration into the application.
 * 
 * @author kchen
 *
 */
@Slf4j // Lombok annotation for logging
@Configuration
@EnableSwagger2
@Import({C2iSecurityConfig.class, C2iValidationConfig.class, C2iCommonConfig.class})
public class C2iConfig {
}
