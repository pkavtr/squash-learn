/**
 * Copyright (C) 2018 Cotiviti Digital (nexgen.admin@cotiviti.io)
 *
 * The software code contained herein is the property of Cotiviti Corporation
 * and its subsidiaries and affiliates (collectively, “Cotiviti”).
 * Access to this software code is being provided to you in the course of your
 * employment or affiliation with Cotiviti and may be used solely in the scope
 * and course of your work for Cotiviti, and is for internal Cotiviti use only.
 * Any unauthorized use, disclosure, copying, distribution, destruction of this
 * software code, or the taking of any unauthorized action in reliance on this
 * software code, is strictly prohibited.
 * If this information is viewed in error, immediately discontinue use of the
 * application.  Anyone using this software code and the applications will be
 * subject to monitoring for improper use, system maintenance and security
 * purposes, and is advised that if such monitoring reveals possible criminal
 * activity or policy violation, Cotiviti personnel may provide the evidence of
 * such monitoring to law enforcement or other officials, and the user may be
 * subject to disciplinary action by Cotiviti, up to and including termination
 * of employment.
 *
 * Use of this software code and any applications and information therein
 * constitutes acknowledgement of and consent to this notice
 */
package com.cotiviti.c2i.utils.annotations.test;

import static com.google.testing.compile.CompilationSubject.assertThat;
import static com.google.testing.compile.Compiler.javac;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.junit.runners.JUnit4;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.cotiviti.c2i.validation.processors.C2iApiFormatProcessor;
import com.google.testing.compile.Compilation;
import com.google.testing.compile.JavaFileObjects;

@RunWith(JUnit4.class)
public class C2iAPIFormatAnnotationTest {

	private static final String MAPPING_NOT_VALID = "defined in @RequestMapping of %s method is not a valid format.  The format should be \"^/v(\\d+)/(.*)\".";

	private static Logger log = LoggerFactory.getLogger(C2iAPIFormatAnnotationTest.class);

	@Test
	public void testWithCorrectVersionAndMediaType() {
		log.info("In testWithCorrectVersionAndMediaType() Test method");
		Compilation compilation = javac().withProcessors(new C2iApiFormatProcessor())
				.compile(JavaFileObjects.forResource("CustomerController.java"));
		assertThat(compilation).succeeded();
	}

	@Test
	public void testWithIncorrectVersionOnly() {
		log.info("In testWithIncorrectVersionOnly() Test method");
		Compilation compilation = javac().withProcessors(new C2iApiFormatProcessor())
				.compile(JavaFileObjects.forResource("CustomerControllerWithIncorrectVersion.java"));
		assertThat(compilation).failed();
		assertThat(compilation).hadErrorContaining(String.format(MAPPING_NOT_VALID, "findById(long)"));
		assertThat(compilation).hadErrorContaining(String.format(MAPPING_NOT_VALID, "findCustomer(long)"));
		assertThat(compilation).hadErrorContaining(String.format(MAPPING_NOT_VALID, "findCustomerVersion2(long)"));
		assertThat(compilation).hadErrorContaining(
				String.format(MAPPING_NOT_VALID, "findCustomerWithCorrectVersionAfterFirstPosition(long)"));
	}

	@Test
	public void testWithMissingVersion() {
		log.info("In testWithMissingVersion() Test method");
		Compilation compilation = javac().withProcessors(new C2iApiFormatProcessor())
				.compile(JavaFileObjects.forResource("CustomerControllerMissingVersion.java"));
		assertThat(compilation).failed();
		assertThat(compilation).hadErrorContaining(
				"method must be defined with non-empty strings.  The format of a string should be \"^/v(\\d+)/(.*)\".");
	}

	/**
	 * Test correct value for "consumes" annotation (i.e., consumes="application/json")
	 */
	@Test
	public void testWithIncorrectConsumeMediaType() {
		log.info("In testWithIncorrectConsumeMediaType() Test method");
		Compilation compilation = javac().withProcessors(new C2iApiFormatProcessor())
				.compile(JavaFileObjects.forResource("CustomerControllerIncorrectMediaTypeForConsume.java"));
		assertThat(compilation).failed();
		assertThat(compilation).hadErrorContaining("method must be defined with consumes=\"application/json\" exactly.");
	}

	/**
	 * Test optional "consumes" in case there's no RequestBody Parameter
	 */
	@Test
	public void testWithEmptyConsumeMediaType() {
		log.info("In testWithEmptyConsumeMediaType() Test method");
		Compilation compilation = javac().withProcessors(new C2iApiFormatProcessor())
				.compile(JavaFileObjects.forResource("CustomerControllerEmptyConsumeMediaType.java"));
		assertThat(compilation).succeeded();
	}

	/**
	 * Test correct value for "produces" annotation (i.e., produces = "application/json")
	 */
	@Test
	public void testWithIncorrectProduceMediaType() {
		log.info("In testWithIncorrectProduceMediaType() Test method");
		Compilation compilation = javac().withProcessors(new C2iApiFormatProcessor())
				.compile(JavaFileObjects.forResource("CustomerControllerIncorrectMediaTypeForProduce.java"));
		assertThat(compilation).failed();
		assertThat(compilation).hadErrorContaining("method must be defined with produces=\"application/json\".");
	}

	/**
	 * Test mandatory "produces" annotation is always present.
	 */
	@Test
	public void testWithEmptyProduceMediaType() {
		log.info("In testWithEmptyProduceMediaType() Test method");
		Compilation compilation = javac().withProcessors(new C2iApiFormatProcessor())
				.compile(JavaFileObjects.forResource("CustomerControllerEmptyProduceMediaType.java"));
		assertThat(compilation).failed();
		assertThat(compilation).hadErrorContaining("method must be defined with produces=\"application/json\".");
	}

	/**
	 * Test in case of none of the C2iApiFormat fields are present.
	 */
	@Test
	public void testWithNoC2iApiFormatValues() {
		log.info("In testWithNoC2iApiFormatValues() Test method");
		Compilation compilation = javac().withProcessors(new C2iApiFormatProcessor())
				.compile(JavaFileObjects.forResource("CustomerControllerWithNoApiFormatValues.java"));
		assertThat(compilation).failed();
		assertThat(compilation).hadErrorCount(2); // 1 - Version, 2 - consumes, 3 - produces
	}
	
	/**
	 * Test "consumes" annotation is present when the "RequestBody" parameter is specified.
	 */
	@Test
	public void testWithOutConsumesMediaTypeWithRequestBodyParam() {
		log.info("In testWithOutConsumesMediaTypeWithRequestBodyParam() Test method");
		Compilation compilation = javac().withProcessors(new C2iApiFormatProcessor())
				.compile(JavaFileObjects.forResource("CustomerControllerEmptyConsumePostMethod.java"));
	
		assertThat(compilation).failed();
		assertThat(compilation).hadErrorContaining("method must be defined with consumes=\"application/json\" exactly.");
	}
}
