/**
 * Copyright (C) 2018 Cotiviti Digital (nexgen.admin@cotiviti.io)
 *
 * The software code contained herein is the property of Cotiviti Corporation
 * and its subsidiaries and affiliates (collectively, “Cotiviti”).
 * Access to this software code is being provided to you in the course of your
 * employment or affiliation with Cotiviti and may be used solely in the scope
 * and course of your work for Cotiviti, and is for internal Cotiviti use only.
 * Any unauthorized use, disclosure, copying, distribution, destruction of this
 * software code, or the taking of any unauthorized action in reliance on this
 * software code, is strictly prohibited.
 * If this information is viewed in error, immediately discontinue use of the
 * application.  Anyone using this software code and the applications will be
 * subject to monitoring for improper use, system maintenance and security
 * purposes, and is advised that if such monitoring reveals possible criminal
 * activity or policy violation, Cotiviti personnel may provide the evidence of
 * such monitoring to law enforcement or other officials, and the user may be
 * subject to disciplinary action by Cotiviti, up to and including termination
 * of employment.
 *
 * Use of this software code and any applications and information therein
 * constitutes acknowledgement of and consent to this notice
 */
package com.cotiviti.c2i.utils.annotations.test;

import org.json.JSONObject;
import org.junit.Test;
import org.springframework.http.MediaType;

import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultHandlers.print;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

public class BoxControllerTest extends AbstractControllerTest {

    @Test
    public void testPost() throws Exception {
        JSONObject jsonObject = new JSONObject();

        this.mvc.perform(
                post("/boxes")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(jsonObject.toString())
                        .accept(MediaType.APPLICATION_JSON))
                .andDo(print())
                //.andExpect(jsonPath("error.validation.field[0].code").value("required-field"))
                //.andExpect(jsonPath("error.validation.field[0].name").value("count"))
                .andExpect(status().is(422));
    }

    @Test
    public void testPostWithTypeMismatch() throws Exception {
        JSONObject jsonObject = new JSONObject();
        jsonObject.put("count", 12);
        jsonObject.put("id", "yes");

        this.mvc.perform(
                post("/boxes")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(jsonObject.toString())
                        .accept(MediaType.APPLICATION_JSON))
                //.andExpect(jsonPath("error.validation.field[0].code").value("invalid-property"))
                //.andExpect(jsonPath("error.validation.field[0].name").value("id"))
                .andDo(print())
                .andExpect(status().is(422));
    }

    //@Test
    public void testPostLaxly() throws Exception {
        JSONObject jsonObject = new JSONObject();

        this.mvc.perform(
                post("/boxes?laxly=true")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(jsonObject.toString())
                        .accept(MediaType.APPLICATION_JSON))
                .andDo(print())
                .andExpect(status().is(200));
    }


    //@Test
    public void testPostLaxlyWithBodyAndErrors() throws Exception {
        JSONObject jsonObject = new JSONObject();
        jsonObject.put("name", "smelly stuff");

        this.mvc.perform(
                post("/boxes?errors=true&laxly=true")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(jsonObject.toString())
                        .accept(MediaType.APPLICATION_JSON))
                //.andExpect(jsonPath("error.validation.field[0].code").value("nasty-box"))
                //.andExpect(jsonPath("error.validation.field[1].code").value("nasty-box"))
                .andDo(print())
                .andExpect(status().is(200));
    }

    @Test
    public void testPostWithUnavailableSchema() throws Exception {
        JSONObject jsonObject = new JSONObject();
        jsonObject.put("name", "smelly stuff");

        this.mvc.perform(
                post("/unavailable-schema")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(jsonObject.toString())
                        .accept(MediaType.APPLICATION_JSON))
                .andExpect(jsonPath("error.validation.global[0].message").value("Internal validation error"))
                .andDo(print())
                .andExpect(status().is(422));
    }

}