import com.cotiviti.c2i.validation.annotations.C2iApiFormat;
import com.cotiviti.c2i.validation.annotations.C2iRestController;

import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseStatus;

@C2iRestController
@C2iApiFormat
public class CustomerControllerMissingVersion {	
    public CustomerControllerMissingVersion() {
    }

    // API - read
    @RequestMapping(method = RequestMethod.GET, consumes="application/json", produces="application/json")
    public void findById(@PathVariable final long id) {
        return ;
    }
}