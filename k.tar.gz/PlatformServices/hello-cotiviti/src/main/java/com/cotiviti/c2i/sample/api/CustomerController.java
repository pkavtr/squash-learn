/**
 * Copyright (C) 2018 Cotiviti Digital (nexgen.admin@cotiviti.io)
 *
 * The software code contained herein is the property of Cotiviti Corporation
 * and its subsidiaries and affiliates (collectively, “Cotiviti”).
 * Access to this software code is being provided to you in the course of your
 * employment or affiliation with Cotiviti and may be used solely in the scope
 * and course of your work for Cotiviti, and is for internal Cotiviti use only.
 * Any unauthorized use, disclosure, copying, distribution, destruction of this
 * software code, or the taking of any unauthorized action in reliance on this
 * software code, is strictly prohibited.
 * If this information is viewed in error, immediately discontinue use of the
 * application.  Anyone using this software code and the applications will be
 * subject to monitoring for improper use, system maintenance and security
 * purposes, and is advised that if such monitoring reveals possible criminal
 * activity or policy violation, Cotiviti personnel may provide the evidence of
 * such monitoring to law enforcement or other officials, and the user may be
 * subject to disciplinary action by Cotiviti, up to and including termination
 * of employment.
 *
 * Use of this software code and any applications and information therein
 * constitutes acknowledgement of and consent to this notice
 */
package com.cotiviti.c2i.sample.api;

import static org.apache.commons.lang3.RandomStringUtils.randomNumeric;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseStatus;

import com.cotiviti.c2i.sample.model.Customer;
import com.cotiviti.c2i.sample.model.CustomerV2;
import com.cotiviti.c2i.validation.annotations.C2iApiFormat;
import com.cotiviti.c2i.validation.annotations.C2iRestController;
import com.github.javafaker.Faker;

@C2iRestController
@C2iApiFormat
public class CustomerController {

	private static Logger log = LoggerFactory.getLogger(CustomerController.class);	

	// API - read
	@RequestMapping(method = RequestMethod.GET, value = { "/v1/customers/{id}",
			"/v2/customers/{id}" }, produces = "application/json")
	public Customer findById(@PathVariable final long id) {

		log.debug("CustomerController:findById is called");

		Faker faker = new Faker();
		return new Customer(Long.parseLong(randomNumeric(9)), faker.name().fullName(), randomNumeric(12));
	}

	// API - write (version 1)
	@RequestMapping(method = RequestMethod.POST, value = "/v1/customers", produces = "application/json")
	@ResponseStatus(HttpStatus.CREATED)
	public Customer create() {
		log.debug("CustomerController:create is called");

		Faker faker = new Faker();
		return new Customer(Long.parseLong(randomNumeric(9)), faker.name().fullName(), "");
	}

	// API - write (latest version 2)
	@RequestMapping(method = RequestMethod.POST, value = "/v2/customers", produces = "application/json")
	@ResponseStatus(HttpStatus.CREATED)
	public CustomerV2 createV2Correct() {

		log.debug("CustomerController:createV2 is called");

		Faker faker = new Faker();
		// create ssn with "-". Brute force
		String ssn1 = randomNumeric(3);
		String ssn2 = randomNumeric(2);
		String ssn3 = randomNumeric(4);
		return new CustomerV2(ssn1 + "-" + ssn2 + "-" + ssn3, faker.name().fullName(), null);
	}
	
	// API - write (post one json object in request body)
	@RequestMapping(method = RequestMethod.POST, value = "/v1/one", consumes = "application/json", produces = "application/json")
	@ResponseStatus(HttpStatus.CREATED)
	public Customer handleOnJsonObject(@RequestBody Customer customer) {

		log.debug("CustomerController:createQA is called");

		return customer;
	}
	
	// API - write  (post list of json object in body)
	@RequestMapping(method = RequestMethod.POST, value = "/v1/list", consumes = "application/json", produces = "application/json")
	@ResponseStatus(HttpStatus.CREATED)
	public List<Customer> handleListOfJsonObjects(@RequestBody List<Customer> customers) {

		log.debug("CustomerController:createQA is called");

		return customers;
	}
}
