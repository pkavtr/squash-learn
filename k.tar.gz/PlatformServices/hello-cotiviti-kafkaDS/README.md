# Framework Web Service Sample - Kafka

## Introduction

This sample demonstrates how to create a service that reads messages from a Kafka topic periodically.  It also provides configuration parameter to set the concurrency number to handle number of Kafka partitions.

## Build Application

```
mvn clean install
```

## Run Application

### Pre-requisites

Since the sample application uses Kafka as the queuing mechanism and uses the schema registry service to store and retrieve Avro schemas, the Kafka server and schema registry service will need to be started first.  Confluent Kafka is used in our application and it comes with the Kafka server and registry service as well as some other services.  Following is the list of steps to install and start those services:

1. Download the Confluent Kafka zip file with this link: https://www.confluent.io/download/
2. Uncompress the downloaded zip file to a folder and mark down the path to this folder
3. Go to bin sub-folder in the folder above and issue "confluent start" command. This Confluent CLI command starts six services:
	* zookeeper server
	* kafka broker
	* schema-registry service
	* kafka-rest service
	* connect - kafka connect server
	* ksql-server
 
### Embedded Tomcat

To run the application with embedded tomcat,

```
mvn spring-boot:run
```

or

```
java -jar target/hello-cotiviti-kafkaWS-0.0.x-RELEASE.war
```

## Integration Tests

This sample only demonstrates Kafka consumer as a background service with a embedded tomcat to host it.  It needs to work with other sample applications to see how it works.  The only thing to make sure is the topic name in this project and whichever project will be used to integrate with it.  The easier one is the hello-cotiviti-kafkaWS project.  Once the topic in both projects are set to the same name, posting messages to hello-cotiviti-kafkaWS endpoint will trigger this service to read messages from the topic and write them to System.out for now (hope we can do more once we get time: write to file, use avro object).  