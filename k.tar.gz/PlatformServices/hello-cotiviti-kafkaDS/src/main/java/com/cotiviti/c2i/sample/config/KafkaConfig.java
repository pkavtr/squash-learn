/**
 * Copyright (C) 2018 Cotiviti Digital (nexgen.admin@cotiviti.io)
 *
 * The software code contained herein is the property of Cotiviti Corporation
 * and its subsidiaries and affiliates (collectively, “Cotiviti”).
 * Access to this software code is being provided to you in the course of your
 * employment or affiliation with Cotiviti and may be used solely in the scope
 * and course of your work for Cotiviti, and is for internal Cotiviti use only.
 * Any unauthorized use, disclosure, copying, distribution, destruction of this
 * software code, or the taking of any unauthorized action in reliance on this
 * software code, is strictly prohibited.
 * If this information is viewed in error, immediately discontinue use of the
 * application.  Anyone using this software code and the applications will be
 * subject to monitoring for improper use, system maintenance and security
 * purposes, and is advised that if such monitoring reveals possible criminal
 * activity or policy violation, Cotiviti personnel may provide the evidence of
 * such monitoring to law enforcement or other officials, and the user may be
 * subject to disciplinary action by Cotiviti, up to and including termination
 * of employment.
 *
 * Use of this software code and any applications and information therein
 * constitutes acknowledgement of and consent to this notice
 */
package com.cotiviti.c2i.sample.config;

import java.util.Map;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.kafka.annotation.EnableKafka;
import org.springframework.kafka.config.ConcurrentKafkaListenerContainerFactory;
import org.springframework.kafka.config.KafkaListenerContainerFactory;
import org.springframework.kafka.core.ConsumerFactory;
import org.springframework.kafka.core.DefaultKafkaConsumerFactory;
import org.springframework.kafka.listener.ConcurrentMessageListenerContainer;

import com.cotiviti.c2i.common.property.C2iConfigProperties;
import com.cotiviti.c2i.sample.service.Receiver;

/**
 * This configuration class is used to setup the required parameters that
 * are essential for kafka consumer to function correctly
 * 
 * @author kchen
 *
 */
@Configuration
@EnableKafka
public class KafkaConfig {
	
	@Value("${consumer.properties.concurrency:1}")
	private Integer concurrency;
	/**
	 * This bean reads the consumer key in application.yml to retrieve 
	 * all the parameters in a c2iConfigProperties object
	 * 
	 * @return C2iConfigProperties
	 */
	@Bean
	@ConfigurationProperties(prefix="consumer")
	public C2iConfigProperties consumerProperties() {
		
		C2iConfigProperties prop = new C2iConfigProperties();		
		return prop;
	}
	
	/**
	 * This bean uses the bean created in {@link #consumerProperties()} to get
	 * a map object that is used by KafkaConsumer class
	 * 
	 * @return Map<String, Object>
	 */
	@Bean
	public Map<String, Object> consumerConfigs() {
		
		Map<String, Object> props = consumerProperties().getFormattedProperties();
		return props;
	}
	
	/**
	 * This is the bean to instantiate the KafkaConsumerFactory the map retrieved
	 * from {@link #consumerConfigs()}
	 * 
	 * @return ConsumerFactory<String, String>
	 */
	@Bean
	public ConsumerFactory<String, String> consumerFactory() {
	    return new DefaultKafkaConsumerFactory<>(consumerConfigs());
	}

	/**
	 * This method instantiates a KafkaListenerContainerFactory using the bean
	 * created in {@link #consumerFactory()}
	 * 
	 * @return KafkaListenerContainerFactory<ConcurrentMessageListenerContainer<String, String>>
	 */
	@Bean
	public KafkaListenerContainerFactory<ConcurrentMessageListenerContainer<String, String>> kafkaListenerContainerFactory() {
	    ConcurrentKafkaListenerContainerFactory<String, String> factory =
	        new ConcurrentKafkaListenerContainerFactory<>();
	    factory.setConsumerFactory(consumerFactory());
	    factory.setConcurrency(concurrency);

	    return factory;
	}

	/**
	 * This method instantiates a Receiver bean to retrieve messages from a 
	 * topic
	 * 
	 * @return Receiver
	 */
	@Bean
	public Receiver receiver() {
	    return new Receiver();
	}
}
