/**
 * Copyright (C) 2018 Cotiviti Digital (nexgen.admin@cotiviti.io)
 *
 * The software code contained herein is the property of Cotiviti Corporation
 * and its subsidiaries and affiliates (collectively, “Cotiviti”).
 * Access to this software code is being provided to you in the course of your
 * employment or affiliation with Cotiviti and may be used solely in the scope
 * and course of your work for Cotiviti, and is for internal Cotiviti use only.
 * Any unauthorized use, disclosure, copying, distribution, destruction of this
 * software code, or the taking of any unauthorized action in reliance on this
 * software code, is strictly prohibited.
 * If this information is viewed in error, immediately discontinue use of the
 * application.  Anyone using this software code and the applications will be
 * subject to monitoring for improper use, system maintenance and security
 * purposes, and is advised that if such monitoring reveals possible criminal
 * activity or policy violation, Cotiviti personnel may provide the evidence of
 * such monitoring to law enforcement or other officials, and the user may be
 * subject to disciplinary action by Cotiviti, up to and including termination
 * of employment.
 *
 * Use of this software code and any applications and information therein
 * constitutes acknowledgement of and consent to this notice
 */
package com.cotiviti.c2i.validation.exception;

import org.everit.json.schema.ValidationException;
import org.springframework.core.convert.converter.Converter;
import org.springframework.validation.Errors;

/**
 * Converts {@link ValidationException} from Everit JSON Schema to Spring
 * {@link Errors} object.
 * <p>
 * Since the {@link Errors} instance might already contain some errors, we
 * cannot use the {@link Converter} API. Instead, we will contribute errors to
 * the instance provided in the second parameter.
 * </p>
 */
public class C2iValidationExceptionMediator {

	/**
	 * Does the best effort to convert the validation exception to errors that will
	 * be contributed to the {@link Errors} instance
	 * 
	 * @param validationException
	 *            Everit JSON schema validation errors
	 * @param errors
	 *            binding errors that will be used in Spring MVC mechanism
	 */
	public void convert(ValidationException validationException, Errors errors) {
		if ("exclusiveMinimum".equals(validationException.getKeyword())) {
			String schemaLocation = validationException.getSchemaLocation();
			String field = schemaLocation.substring(schemaLocation.lastIndexOf("/") + 1);
			errors.rejectValue(field, "exclusive-minimum", validationException.getErrorMessage());
		}
		if ("required".equals(validationException.getKeyword())) {
			parseRequired(validationException, errors);
		}
		if ("type".equals(validationException.getKeyword())) {
			errors.reject("reject", validationException.getErrorMessage());
		}
		for (ValidationException nestedException : validationException.getCausingExceptions()) {
			if (isRequired(nestedException)) {
				parseRequired(nestedException, errors);
				continue;
			}
			errors.reject("reject", validationException.getErrorMessage());
		}
	}

	private boolean isRequired(ValidationException exception) {
		return exception.getErrorMessage().startsWith("required key");
	}

	private void parseRequired(ValidationException exception, Errors errors) {
		String message = exception.getMessage();
		int leftBracket = message.indexOf("[");
		int rightBracket = message.indexOf("]");
		String field = message.substring(leftBracket + 1, rightBracket);

		errors.rejectValue(field, "required-field", field+": Field is required");
	}
}
