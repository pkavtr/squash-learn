/**
 * Copyright (C) 2018 Cotiviti Digital (nexgen.admin@cotiviti.io)
 *
 * The software code contained herein is the property of Cotiviti Corporation
 * and its subsidiaries and affiliates (collectively, “Cotiviti”).
 * Access to this software code is being provided to you in the course of your
 * employment or affiliation with Cotiviti and may be used solely in the scope
 * and course of your work for Cotiviti, and is for internal Cotiviti use only.
 * Any unauthorized use, disclosure, copying, distribution, destruction of this
 * software code, or the taking of any unauthorized action in reliance on this
 * software code, is strictly prohibited.
 * If this information is viewed in error, immediately discontinue use of the
 * application.  Anyone using this software code and the applications will be
 * subject to monitoring for improper use, system maintenance and security
 * purposes, and is advised that if such monitoring reveals possible criminal
 * activity or policy violation, Cotiviti personnel may provide the evidence of
 * such monitoring to law enforcement or other officials, and the user may be
 * subject to disciplinary action by Cotiviti, up to and including termination
 * of employment.
 *
 * Use of this software code and any applications and information therein
 * constitutes acknowledgement of and consent to this notice
 */
package com.cotiviti.c2i.validation.configs;

import org.springframework.beans.factory.config.BeanPostProcessor;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import com.cotiviti.c2i.validation.processors.C2iJsonRequestBodyArgumentResolverRegisteringBeanPostProcessor;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
import com.fasterxml.jackson.databind.ObjectMapper;

/**
 * This class sets up validation configuration to allow Json validation
 * and enforce non-null value for a json node
 * 
 * @author kchen
 *
 */
@Configuration
public class C2iValidationConfig {
	/**
	 * This bean is used to enforce the standard that not returning null element in
	 * the response. It can be set through application.yml file in custom service
	 * but we enforce it in the library level so as long as this class being
	 * imported, the application will use the standard.
	 * 
	 * @return
	 */
	@Bean
	public ObjectMapper buildObjectMapper() {
		return new ObjectMapper().setSerializationInclusion(Include.NON_NULL);
	}

	@Bean
	static BeanPostProcessor c2iJsonRequestBodyArgumentResolverRegisteringBeanPostProcessor() {
		return new C2iJsonRequestBodyArgumentResolverRegisteringBeanPostProcessor();
	}
}
