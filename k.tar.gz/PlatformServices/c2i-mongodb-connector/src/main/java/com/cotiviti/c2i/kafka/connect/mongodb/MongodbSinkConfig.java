/**
 * Copyright (C) 2018 Cotiviti Digital (nexgen.admin@cotiviti.io)
 *
 * The software code contained herein is the property of Cotiviti Corporation
 * and its subsidiaries and affiliates (collectively, “Cotiviti”).
 * Access to this software code is being provided to you in the course of your
 * employment or affiliation with Cotiviti and may be used solely in the scope
 * and course of your work for Cotiviti, and is for internal Cotiviti use only.
 * Any unauthorized use, disclosure, copying, distribution, destruction of this
 * software code, or the taking of any unauthorized action in reliance on this
 * software code, is strictly prohibited.
 * If this information is viewed in error, immediately discontinue use of the
 * application.  Anyone using this software code and the applications will be
 * subject to monitoring for improper use, system maintenance and security
 * purposes, and is advised that if such monitoring reveals possible criminal
 * activity or policy violation, Cotiviti personnel may provide the evidence of
 * such monitoring to law enforcement or other officials, and the user may be
 * subject to disciplinary action by Cotiviti, up to and including termination
 * of employment.
 *
 * Use of this software code and any applications and information therein
 * constitutes acknowledgement of and consent to this notice
 */
package com.cotiviti.c2i.kafka.connect.mongodb;

import org.apache.kafka.common.config.AbstractConfig;
import org.apache.kafka.common.config.ConfigDef;
import org.apache.kafka.common.config.ConfigDef.Type;
import org.apache.kafka.common.config.ConfigDef.Importance;

import java.util.Map;

/**
 * Config variables for Mongodb sink connector
 * 
 * @author kchen
 *
 */
public class MongodbSinkConfig extends AbstractConfig {
    public static final String HOST = "host";
    private static final String HOST_DOC = "Host url of mongodb";
    public static final String PORT = "port";
    private static final String PORT_DOC = "Port of mongodb";
    public static final String URI = "uri";
    private static final String URI_DOC = "uri of mongodb";
    public static final String BULK_SIZE = "bulk.size";
    private static final String BULK_SIZE_DOC = "Count of documents in each polling";
    public static final String TOPICS = "topics";
    private static final String TOPIC_PREFIX_DOC = "Topics";
    public static final String DATABASE = "mongodb.database";
    private static final String DATABASE_DOC = "Database of mongodb";
    public static final String COLLECTIONS = "mongodb.collections";
    private static final String COLLECTIONS_DOC = "Collections of mongodb";

    public static ConfigDef config = new ConfigDef()
    		.define(URI, Type.STRING, Importance.HIGH, URI_DOC)
            .define(HOST, Type.STRING, Importance.HIGH, HOST_DOC)
            .define(PORT, Type.INT, Importance.HIGH, PORT_DOC)
            .define(BULK_SIZE, Type.INT, Importance.HIGH, BULK_SIZE_DOC)
            .define(TOPICS, Type.STRING, Importance.LOW, TOPIC_PREFIX_DOC)
            .define(DATABASE, Type.STRING, Importance.LOW, DATABASE_DOC)
            .define(COLLECTIONS, Type.STRING, Importance.LOW, COLLECTIONS_DOC);

    public MongodbSinkConfig(Map<String, String> props) {
        super(config, props);
    }
}
