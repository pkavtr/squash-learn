#!/bin/bash
#
# Copyright (C) 2018 Cotiviti Labs (nexgen.admin@cotiviti.io)
#
# The software code contained herein is the property of Cotiviti Corporation
# and its subsidiaries and affiliates (collectively, “Cotiviti”).
# Access to this software code is being provided to you in the course of your
# employment or affiliation with Cotiviti and may be used solely in the scope
# and course of your work for Cotiviti, and is for internal Cotiviti use only.
# Any unauthorized use, disclosure, copying, distribution, destruction of this
# software code, or the taking of any unauthorized action in reliance on this
# software code, is strictly prohibited.
# If this information is viewed in error, immediately discontinue use of the
# application.  Anyone using this software code and the applications will be
# subject to monitoring for improper use, system maintenance and security
# purposes, and is advised that if such monitoring reveals possible criminal
# activity or policy violation, Cotiviti personnel may provide the evidence of
# such monitoring to law enforcement or other officials, and the user may be
# subject to disciplinary action by Cotiviti, up to and including termination
# of employment.
#
# Use of this software code and any applications and information therein
# constitutes acknowledgement of and consent to this notice
#


echo "installing docker"
apt-get update
apt-get install -y \
    apt-transport-https \
    ca-certificates \
    curl \
    software-properties-common
curl -fsSL https://download.docker.com/linux/ubuntu/gpg | apt-key add -
add-apt-repository \
   "deb https://download.docker.com/linux/$(. /etc/os-release; echo "$ID") \
   $(lsb_release -cs) \
   stable"
apt-get update && apt-get install -y docker.io

echo "installing kubernetes"
apt-get update && apt-get install -y apt-transport-https
curl -s https://packages.cloud.google.com/apt/doc/apt-key.gpg | apt-key add -
cat <<EOF >/etc/apt/sources.list.d/kubernetes.list
deb http://apt.kubernetes.io/ kubernetes-xenial main
EOF
apt-get update
apt-get install -y kubelet=1.11.3-00 kubeadm=1.11.3-00 kubectl=1.11.3-00 kubernetes-cni=0.6.0-00

echo "deploying kubernetes (with calico)..."
kubeadm init --pod-network-cidr=192.168.0.0/16 --apiserver-cert-extra-sans="$5" --token 8c2350.f55343444a6ffc46 # add --apiserver-advertise-address="ip" if you want to use a different IP address than the main server IP

mkdir -p $HOME/.kube
cp -i /etc/kubernetes/admin.conf $HOME/.kube/config
chown ubuntu:ubuntu $HOME/.kube/config

export KUBECONFIG=/etc/kubernetes/admin.conf

# deploy the kubernetes pod networks
kubectl apply -f \
https://docs.projectcalico.org/v3.2/getting-started/kubernetes/installation/hosted/etcd.yaml
kubectl apply -f \
https://docs.projectcalico.org/v3.2/getting-started/kubernetes/installation/rbac.yaml
kubectl apply -f \
https://docs.projectcalico.org/v3.2/getting-started/kubernetes/installation/hosted/calico.yaml

# installing dashboard and its full admin privileges
kubectl apply -f /tmp/kubernetes/dashboard/dashboard-admin.yaml
kubectl apply -f https://raw.githubusercontent.com/kubernetes/dashboard/master/src/deploy/recommended/kubernetes-dashboard.yaml

if [ "$4" = "nginx" ]; then
    # deploy nginx ingress controller - from NGINX
    kubectl apply -f /tmp/kubernetes/nginx-ingress-controller/common/ns-and-sa.yaml
    kubectl apply -f /tmp/kubernetes/nginx-ingress-controller/common/default-server-secret.yaml
    kubectl apply -f /tmp/kubernetes/nginx-ingress-controller/common/nginx-config.yaml
    kubectl apply -f /tmp/kubernetes/nginx-ingress-controller/rbac/rbac.yaml
    kubectl apply -f /tmp/kubernetes/nginx-ingress-controller/deployment/nginx-ingress.yaml
    kubectl apply -f /tmp/kubernetes/nginx-ingress-controller/service/loadbalancer-aws-elb.yaml
fi
if [ "$4" = "kubernetes" ]; then
    # deploy ingress nginx controller - from Kubernetes 
    kubectl apply -f /tmp/kubernetes/ingress-nginx-controller/mandatory.yaml
    kubectl apply -f /tmp/kubernetes/ingress-nginx-controller/service-l4.yaml
    kubectl apply -f /tmp/kubernetes/ingress-nginx-controller/patch-configmap-l4.yaml
fi
if [ "$4" = "custom" ]; then
    # will put in the custom stuff soon
    echo "put custom stuff in"
    kubectl apply -Rf /tmp/kubernetes/custom-nginx-controller
fi

# deploy metrics server to allow horizontal pod autoscaling
kubectl apply -f /tmp/kubernetes/metrics-server/

# setup secrets to communicate with docker.io
kubectl create secret docker-registry userregistrykey \
  --docker-server=docker.io \
  --docker-username="$1" \
  --docker-password="$2" \
  --docker-email="$3"

# deploy default ingress
kubectl apply -f /tmp/kubernetes/applications/default-secret.yaml
kubectl apply -f /tmp/kubernetes/applications/default-master-ingress.yaml

# deploy hello-node ingress
kubectl apply -f /tmp/kubernetes/applications/hello-node-ingress.yaml

# deploy sample nodejs deployment and service
kubectl run hello-world --replicas=2 --labels="run=load-balancer-example" --image=gcr.io/google-samples/node-hello:1.0  --port=8080
kubectl apply -f /tmp/kubernetes/applications/hello-node-service.yaml
