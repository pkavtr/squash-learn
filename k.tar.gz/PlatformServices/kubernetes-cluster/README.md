# Prototype on Using Terraform to Create Kubernetes Cluster in AWS with Integration of c2i Web Services

## Introduction

This is a prototype that uses AWS, Terraform, and Kubernetes with integration of c2i sample "hello-cotiviti" service.  "Kubernetes is an open-source system for automating deployment, scaling, and management of containerrized applications" quoted from [Kubernetes](https://kubernetes.io) home page.  We may use Kubernetes as our container orchestration tool to deploy our applications.  hello-activiti project has been enhanced and is now able to be deployed to a kubernetes cluster with familiar and simple maven command.

<br />
This prototype uses HashiCorp Terraform to create a kubernetes clusters with one master and two worker nodes at the minimum and 3 worker nodes at the maximum in AWS.  Then, it installs all necessary kubernetes applications and deploys the required kubernetes modules to the clusters.  Finally, it creates two instances of the sample nodejs application to the kubernetes cluster and install a NGINX Ingress controller to expose the sample nodejs application endpoint as well as other web services required to be exposed to external connections.

## Pre-requisites

Since it uses HashiCorp Terraform to create the Kubernetes cluster, Terraform must be installed in the envrionment to execute the terraform script in this folder.  Please see [terraform](https://www.terraform.io) page to install it.  Also, AWS CLI is used to work with Terraform to manage AWS services, it will need to be installed in the environment.  However,  the setup script will continue to setup the cluster regardlessly.  Please refer to [AWS CLI](https://aws.amazon.com/cli/?sc_channel=PS&sc_campaign=acquisition_US&sc_publisher=google&sc_medium=ACQ-P%7CPS-GO%7CBrand%7CDesktop%7CSU%7CManagement%20Tools%7CCommand%20Line%7CUS%7CEN%7CText&sc_content=aws_cli_e&sc_detail=aws%20cli&sc_category=Management%20Tools&sc_segment=293653699084&sc_matchtype=e&sc_country=US&s_kwcid=AL!4422!3!293653699084!e!!g!!aws%20cli&ef_id=W7Iy7gAABFigKD9G:20181001144747:s) for the detail of its installation and quick usage.  Please note that, the Kubernetes CLI is used to manage kubernetes resources and will be installed by "kubernetes-cluster-setup.sh" script if it is not installed.  User should modify the "~/.bashrc" or "~/.bash_profile" to export the path to kubernetes CLI installed folder to allow other new terminal sessions to use this CLI.

## Build Kubernetes Cluster in AWS

Following is the list of steps to build the cluster,

1. Please do back up the "~/.kube/config" file if there is one already because the setup script will override it;
2. Go to https://www.ip-adress.com in a browser and write down the your IP address.  This IP address will be used to setup AWS security group for EC2 instances so only computer with this IP address can access the services created in AWS using the terraform scripts here;
3. Get a AWS access key and secret.  Refer to https://aws.amazon.com/blogs/security/wheres-my-secret-access-key/ to create a new secret access key for an IAM user;
4. In a terminal, issue ``git clone https://github.com/cotiviti/PlatformServices.git`` command to pull down the latest source code;
5. Go into "PlatformServices“ folder in the terminal and issue ``git checkout prototype/terraformkube`` command to switch the branch;
6. Change to "kubernetes-cluster" folder and make sure "kubernetes-cluster-setup.sh" and "kubernetes-cluster-destroy.sh" are executable by issuing ``chmod +x kubernetes-cluster-*.sh`` command;
7. Change to "terraform" folder and add a file called "terraform.tfvars" with following content,<br />``AWS_ACCESS_KEY            = <your-AWS-access-key-obtained-in-step-2>``<br />
  ``AWS_SECRET_KEY            = <your-AWS-secret-key-obtained-in-step-2>``<br />
  ``DOCKER_USER_NAME          = <your-docker-hub-user-name>``<br />
  ``DOCKER_PASSWORD           = <your-docker-hub-password>``<br />
  ``DOCKER_USER_EMAIL         = <your-docker-hub-email>``<br />
  ``MY_ENVIRONMENT_IP_ADDRESS = <your-ip-address-obtained-in-step-1>``<br />
  ``AWS_REGION                = <aws-region-most-fit-your-area>``<br />
  ``AWS_INSTANCE_TYPE         = <type-of-EC2-instance-for-the-cluster>``

8. Change back to "kubernetes-cluster" folder again and issue ``./kubernetes-cluster-setup.sh`` to start the cluster configuration.  The setup process can take 5 to 10 mininutes and please pay attention to the messages at the end of the configuration.  It outlines tests you can run to confirm if the cluster has been setup and configured correctly.  Please note, all the pods (applications) in the kubernetes cluster may not be initialized completely even the setup command returned.  You should use ``kubectl get pods --all-namespaces --watch`` to watch the updating states or use ``kubectl get pods --all-namespaces`` command to check if all pods are in "Running" state;
9. After the cluster is up and running, you can deploy "hello-cotiviti" service to it now.  But before deploying "hello-cotiviti" to kubernetes cluster, docker engine has to be installed in this environment since maven command below uses docker engine to create "hello-cotiviti" docker image and then upload the image to docker hub. After installing docker engine, issue ``mvn clean install`` to build the parent and every projects in "PlatformServices" repo and then change to "hello-cotiviti" project folder and issue ``mvn clean package dockerfile:build dockerfile:push fabric8:apply`` commad to build and deploy the service to the cluster.  Once the deployment completes, users can send test with the same curl command output in step 7 with replacement of "kube" with "hello/actuator/info" to check the deployment.  To delete everything deployed for "hello-cotivti" project, issue ``kubectl delete all --selector="run=hello-cotiviti"``  command.  This step is an optional step for kubernetes cluster setup, but it is an important step for our team to understand the architecture for deploying c2i Web Service Framework compliant applications to a kubernetes cluster if kubernetes is the chosen infrastructure for deployment.  
10. When you have done with the cluster, you can tear it down by issuing ``./kubernetes-cluster-destroy.sh`` command in "kubernetes-cluster" folder.

## Testing & Troubleshooting

* Sometimes, terraform script will throw exception and stop in the middle of the configuration process.  If it happens, the easist way to deal with it is to ``Ctr+C`` to stop the process and then issue ``./kubernetes-cluster-destroy.sh`` to clean up all the resources have been installed in AWS;
* If two many applications or pods have been deployed to a cluster with AWS t2.micro, the cluster will become non-responsive and pods will crash and restart.  One of the example is that, after deployed Metrics Server to a cluster with t2.micro, the cluster became non-usable.  If too many pods will be deployed, t2.medium works well for the cluster;
* Currently, the Horizontal Pod Autoscaler has been configured for "hello-cotiviti" project.  It will scale up the number of pods for "hello-cotiviti" if the pod average CPU usage in last 5 minutes is more than 5% (to demonstrate the point) and it will scale down if the pod average CPU usage in last 5 miniutes is less than 2%. The maximun number of pods is set to 20.  All thess parameters can be changed through "pom.xml" in "hello-cotiviti" project.  Test experience the scaling process, open several terminals and run following script ``while true; do curl --resolve c2i.cotiviti.com:30112:<ip-address-of-worker-node#1> https://c2i.cotiviti.com:30112/hello/v1/customers/1 --insecure; done`` in these terminals.  You can see the number of pods being added either through ``kubectl get pods --all-namespaces -w`` or ``kubectl get hpa -w`` after sometime.  AWS auto scaling group may also get triggered by AWS auto scaling policy set in terriform script if average CPU usage in last 3 minutes is more than 10%.  AWS auto scaling group will also terminate running instances if average CPU usage in last 3 minute is less than 5%. You can monitor the alarms from AWS CloudWatch service;
* In case you forget the ip addresses or the curl command, you can always re-execute the ``./kubernetes-cluster-setup.sh`` command under "kubernetes-cluster" folder to retrieve the these information.  This command does not rebuild the cluster if the cluster is there already and it just retrieves the info and display it;
* If you are using Labs Nexus for your "~/.m2/settings.xml", you will need to change ``<mirrorOf>*,!confluent</mirrorOf>``
to ``<mirrorOf>*,!confluent,!fabric8</mirrorOf>`` and add <br /> ``<mirror>``<br />
      ``<mirrorOf>fabric8</mirrorOf>``<br />
      ``<name>fabric8-repo</name>``<br />
      ``<url>https://mvnrepository.com/artifact/</url>``<br />
      ``<id>fabric8</id>``<br />
    ``</mirror>`` <br /> under the ``<mirrors>`` node.  This is because Labs Nexus does not have fabric8 repository in it yet.
    
## Features

The following features have been implemented in the current stage,

* Kubernetes cluster with one master and 2 worker nodes at startup and 3 worker nodes if CPU utilization in worker nodes are more than 10% (to illustrate the point) in last 300 seconds.  It will reduce the number of worker nodes to minimum if CPU utilization is less than 5% in last 300 seconds.  The min and max of worker nodes can be changed in "var.tf" terraform file;
* NGINX Ingress controller to map request paths to proper web services. So, there is no need to install AWS load balancer for the cluster;
* Integration with "hello-cotiviti" sample application to allow deploying "hello-cotiviti" web service to a kubernetes cluster.  Developers should be able to use "hello-cotiviti" as the template project to create custom web service without knowing the detail of the integration with a kubernetes cluster (in theory);
* Combining #2 and #3 above, service registry and discovery have been handled nicely.  Also, NGINX Ingress controller is acting as an API gateway to send requests to proper web services deployed to the cluster;
* Kubernetes Horizontal Pod Autoscaling (HPA) has been added to "hello-cotiviti".  HPA combines with AWS EC2 autoscaling group to make the infrastructure to have a very powerful strategy to deal with resource scalability;
* Using its own VPC instead of using the default VPC.

With the features listed above, the prototype validates that a kubernetes cluster can fit micro-service architecture as being designed for.

The following features will be evaluated later to add extra benefits to a kubernetes cluster:

* Integrate with Jenkins pipeline;
* Enhance other sample projects to work with kubernetes cluster;
* Have more granular security groups for different types of resources;
* Use Labs Nexus as the docker registry.