#!/bin/bash
#
# Copyright (C) 2018 Cotiviti Labs (nexgen.admin@cotiviti.io)
#
# The software code contained herein is the property of Cotiviti Corporation
# and its subsidiaries and affiliates (collectively, “Cotiviti”).
# Access to this software code is being provided to you in the course of your
# employment or affiliation with Cotiviti and may be used solely in the scope
# and course of your work for Cotiviti, and is for internal Cotiviti use only.
# Any unauthorized use, disclosure, copying, distribution, destruction of this
# software code, or the taking of any unauthorized action in reliance on this
# software code, is strictly prohibited.
# If this information is viewed in error, immediately discontinue use of the
# application.  Anyone using this software code and the applications will be
# subject to monitoring for improper use, system maintenance and security
# purposes, and is advised that if such monitoring reveals possible criminal
# activity or policy violation, Cotiviti personnel may provide the evidence of
# such monitoring to law enforcement or other officials, and the user may be
# subject to disciplinary action by Cotiviti, up to and including termination
# of employment.
#
# Use of this software code and any applications and information therein
# constitutes acknowledgement of and consent to this notice
#


# check if kubectl is installed
if ! [ -x "$(command -v kubectl)" ]; then
  printf "\nKubernetes CLI not found.  Installing Kubernetes CLI\n"
  UNAME_OUT="$(uname -s)"
  if [ "$UNAME_OUT" = "Darwin" ]; then
    curl -LO https://storage.googleapis.com/kubernetes-release/release/$(curl -s https://storage.googleapis.com/kubernetes-release/release/stable.txt)/bin/darwin/amd64/kubectl
  fi
  if [ "$UNAME_OUT" = "Linux" ]; then
    curl -LO https://storage.googleapis.com/kubernetes-release/release/$(curl -s https://storage.googleapis.com/kubernetes-release/release/stable.txt)/bin/linux/amd64/kubectl
  fi
  chmod +x ./kubectl
  mkdir -p ~/.kube
  printf "\nKubernetes CLI has been installed locally in $PWD folder\n"
fi
RUN_AWS=true
# check if aws clis is installed
if ! [ -x "$(command -v aws)" ]; then
  RUN_AWS=false
  printf "\nAWS CLI not found.  Please install AWS CLI or no test information will be displayed\n"
fi
# check if docker is installed
if ! [ -x "$(command -v docker)" ]; then
  printf "\nDocker not found.  Please install docker engine or this system cannot deploy hello-cotiviti web service to the kubernetes cluster that is setting up now\n"
fi
# check if maven is installed
if ! [ -x "$(command -v mvn)" ]; then
  printf "\nMaven not found.  Please install maven or this system cannot deploy hello-cotiviti web service to the kubernetes cluster that is setting up now\n"
fi

cd ./terraform
chmod 400 mykey
terraform init
terraform apply -auto-approve=true -var USERNAME=$USER
eval "publicIp=$(terraform output master-public-ip)"
eval "privateIp=$(terraform output master-private-ip)"
eval "awsRegion=$(terraform output aws-region)"
eval "awsKey=$(terraform output aws-key)"
eval "awsSecretKey=$(terraform output aws-secret-key)"
scp -o StrictHostKeyChecking=no -i mykey ubuntu@"$publicIp":.kube/config ~/.kube/config.original > /dev/null
sed "s/$privateIp/$publicIp/g" ~/.kube/config.original > ~/.kube/config
cd ..
# if aws cli is not installed, stop execute the following command
if [ "$RUN_AWS" = true ]; then
  export AWS_ACCESS_KEY_ID=$awsKey
  export AWS_SECRET_ACCESS_KEY=$awsSecretKey
  BGreen='\033[1;32m'
  echo 
  echo -e "${BGreen}Use the follow curl command to test if the setup succeed:"
  for i in `aws autoscaling describe-auto-scaling-groups --auto-scaling-group-name $USER-kube-autoscaling --region $awsRegion | grep -i instanceid  | awk '{ print $2}' | cut -d',' -f1| sed -e 's/"//g'`
  do
  eval "workerIp=$(aws ec2 describe-instances --instance-ids $i --region $awsRegion | grep -i PublicIp | awk '{ print $2 }' | head -1 | cut -d"," -f1)"
  echo "  curl --resolve c2i.cotiviti.com:30112:${workerIp} https://c2i.cotiviti.com:30112/kube --insecure"
  done;
  echo "One of them should return 'Hello Kubernetes!' to indicate if cluster setup successfully"
  printf "\e[0m\n"
fi