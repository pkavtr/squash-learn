# Platform Services

## Introduction

This modules and libraries in this project have been developed to serve the phase I goal of c2i Web Service Framework.  They will enforce the patterns based on the published "Digital - Web Services - Standard_v1.0" document.

## Building Application

To build all projects, perform following command: 

```
mvn clean install
```

## Start Web Service

To start the hello-cotiviti sample web service, use command: 

```
java -jar hello-cotiviti/target/hello-cotiviti-0.0.1-RELEASE.war
```

To deploy the hello-cotiviti sample web service to stand-alond tomcat,

1. Copy  hello-cotiviti/target/hello-cotiviti-0.0.1-RELEASE.war file into $TOMCAT_HOME/webapps/hello directory.  $TOMCAT_HOME is the location of the stand-alone tomcat;
2. Start the stand-alone tomcat with the command: ```$TOMCAT_HOME/bin/shutdown.sh``` in linux or ```$TOMCAT_HOME/bin/shutdown.bat``` in Windows

## Tests

Send requests with following command with correponding port (default port for embedded tomcat is 9081):

```
curl http://localhost:9081/hello/v1/customers/1
```

```
curl http://localhost:9081/hello/v2/customers/1
```

```
curl -X POST http://localhost:9081/hello/v1/customers
```

```
curl -X POST http://localhost:9081/hello/v2/customers
```

Please note, all above tests except the second test will return "Forbidden" error with "Access Denied" message since we do not have a service account and service principal name yet and any end points requiring security with failed.  I intentionally disabled the security of the end point in the second test to allow developers to gain some inside about spring security.  Also, developers will be able to use a browser to see, 

* Info end point: http://localhost:9081/hello/actuator/info
* Health end point: http://localhost:9081/hello/actuator/health
* API Documents: http://localhost:9081/hello/swagger-ui.html 


## Jenkins Pipeline
Please see [Creating Jenkins Pipeline](Creating_Jenkins_Pipeline.md) for instructions on creating a build pipeline on Jenkins.
