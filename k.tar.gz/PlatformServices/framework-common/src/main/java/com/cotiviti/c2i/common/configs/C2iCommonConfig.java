/**
 * Copyright (C) 2018 Cotiviti Digital (nexgen.admin@cotiviti.io)
 *
 * The software code contained herein is the property of Cotiviti Corporation
 * and its subsidiaries and affiliates (collectively, “Cotiviti”).
 * Access to this software code is being provided to you in the course of your
 * employment or affiliation with Cotiviti and may be used solely in the scope
 * and course of your work for Cotiviti, and is for internal Cotiviti use only.
 * Any unauthorized use, disclosure, copying, distribution, destruction of this
 * software code, or the taking of any unauthorized action in reliance on this
 * software code, is strictly prohibited.
 * If this information is viewed in error, immediately discontinue use of the
 * application.  Anyone using this software code and the applications will be
 * subject to monitoring for improper use, system maintenance and security
 * purposes, and is advised that if such monitoring reveals possible criminal
 * activity or policy violation, Cotiviti personnel may provide the evidence of
 * such monitoring to law enforcement or other officials, and the user may be
 * subject to disciplinary action by Cotiviti, up to and including termination
 * of employment.
 *
 * Use of this software code and any applications and information therein
 * constitutes acknowledgement of and consent to this notice
 */
package com.cotiviti.c2i.common.configs;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.Ordered;
import org.springframework.core.annotation.Order;
import org.springframework.stereotype.Component;

import com.cotiviti.c2i.common.property.C2iConfigProperties;
import com.google.common.base.Predicates;

import springfox.documentation.builders.ParameterBuilder;
import springfox.documentation.builders.PathSelectors;
import springfox.documentation.builders.RequestHandlerSelectors;
import springfox.documentation.schema.ModelRef;
import springfox.documentation.service.Parameter;
import springfox.documentation.spi.DocumentationType;
import springfox.documentation.spring.web.plugins.Docket;
import springfox.documentation.swagger2.annotations.EnableSwagger2;

/**
 * This class sets up all the necessary plumbing for c2i web service to work
 * correctly.
 * 
 * Since we are using spring boot, the main class that starts the spring boot
 * application should extend this class and it will inject all required bean or
 * configuration into the application.
 * 
 * @author kchen
 *
 */
@Configuration
@EnableSwagger2
public class C2iCommonConfig {

	private static Logger log = LoggerFactory.getLogger(C2iCommonConfig.class);

	private static final String DEFAULT_SWAGGER_BASE_PACKAGE = "com.cotiviti.c2i";

	@Component
	@Order(Ordered.HIGHEST_PRECEDENCE)
	public class CorsFilter implements Filter {

		@Override
		public void doFilter(ServletRequest req, ServletResponse res, FilterChain chain)
				throws IOException, ServletException {
			log.debug("CorsFilter.doFilter method is called");
			final HttpServletResponse response = (HttpServletResponse) res;
			Map<String, Object> corsFilterProps = corsFilterProperties().getProperties();

			// Iterate through the corsFilter property and set them on the response header
			for (Map.Entry<String, Object> entry : corsFilterProps.entrySet())
				response.setHeader("Access-Control-" + entry.getKey(), entry.getValue().toString());

			if ("OPTIONS".equalsIgnoreCase(((HttpServletRequest) req).getMethod())) {
				response.setStatus(HttpServletResponse.SC_OK);
			} else {
				chain.doFilter(req, res);
			}
		}

		@Override
		public void destroy() {
		}

		@Override
		public void init(FilterConfig config) throws ServletException {
		}
	}

	@Bean
	@ConfigurationProperties(prefix = "cors-filter")
	public C2iConfigProperties corsFilterProperties() {
		C2iConfigProperties prop = new C2iConfigProperties();
		return prop;
	}

	@Bean
	@ConfigurationProperties(prefix = "web-service")
	public C2iConfigProperties webServiceProperties() {
		C2iConfigProperties prop = new C2iConfigProperties();
		return prop;
	}

	/**
	 * This bean is used to setup the swagger UI to provide api docs for client side
	 * developers
	 * 
	 * API developers will need to specify the controller namespace in the
	 * application.yml file, under the key named webService.swaggerBasePackage, to
	 * allow swagger UI to scan through the controller to generate the api docs. All
	 * controllers should be placed in the same namespace.
	 * 
	 * @return
	 */
	@Bean
	public Docket api() {
		String swaggerBasePackage = (String) webServiceProperties().getProperties().get("swaggerBasePackage");
		if (swaggerBasePackage == null)
			swaggerBasePackage = DEFAULT_SWAGGER_BASE_PACKAGE;
		Parameter auth_parameter = new ParameterBuilder().name("authorization")
				.description("authorization header is optional for c2i request").modelRef(new ModelRef("string"))
				.parameterType("header").required(false).build();
		List<Parameter> list = new ArrayList<Parameter>();
		list.add(auth_parameter);
		return new Docket(DocumentationType.SWAGGER_2).select()
				.apis(RequestHandlerSelectors.basePackage(swaggerBasePackage))
				.apis(Predicates.not(RequestHandlerSelectors.basePackage("com.cotiviti.c2i.utils.controllers")))
				.paths(PathSelectors.any()).build().globalOperationParameters(list);
	}

}
