# Creating CI/CD Process

## Introduction

This document outlines the required components and their related access credentials to build a Jenkins CI/CD job with the current provided C2i development infrastructure.

## Components

To create a complete automated CI/CD process, an automation server is needed to integrate with many componentes and services, such as build tools, a runtime virtual machine, a source code repository service, a source code analysis and reporting service, a security and vulnerability scanning service, an artifact repository service, a testing server/service, and etc.  With the current C2i infrastrcuture, the provided services are

* C2i Jenkins Server <https://c2i-jenkins.cotiviti.com/> - This is used as the automation server to integrate different components or modules together;
* Apache Maven - This is used as our build automation tool for Java projects.  Since the Maven build tool has been configured for global use, a Jenkins job can use "Maven-3.5.4" as the Maven build agent to build Java applications in the C2i Jenkins Server;
* JDK 8 - This is the virtual machine currently set for Java projects.  Please use "JDK8" as the JDK for building Java applications in the current C2i Jenkins Server.  The exact version of this JDK is 8u172;
* Github <https://github.com/cotiviti> - This serves as the source code repository and version control service;
* SonarQube <http://10.170.34.233:9090> - This analyzes the source code of a project and provides a report on duplicated code, coding standards, unit tests, code coverage, code complexity, comments, bugs, and security vulnerabilities;
* Veracode - This scans through the built artifacts to find any security vulnerabililies;
* Labs Nexus <https://artifacts.cotiviti.io> - This is used as the repository to store built artfacts and other dependent artifacts;
* norgenhdpdev04.ccaintranet.com - This temporarily serves as the development server for deploying the resulting artifacts to validate the deployment process.  The future C2i infrastructure should consist of new development servers, QA servers, and staging servers.

## Access Accounts for Different Components

From the description above, a basic Jenkins job will need to use and/or access several services or servers. Therefore, the following user and/or service accounts for these services/servers will need to be requested and created:

* User account with the JobAdmin role for the C2i Jenkins instance <https://c2i-jenkins.cotiviti.com/> - Please send a message using the Slack #dig_jenkins_admins channel to request access.  You must have an account to access Jenkins to create or configure a Jenkins job;
* Github service & individual user accounts to access the the github repository that a Jenkins job is created for.  Please note: The individual user account is used by an individual developer to pull source code from github, and the service account is used by Jenkins CI/CD jobs to pull source code.  In general, the service account should have no expiration time.  You must have this account to access github to pull down the source code;
* Service account for accessing SonarQube server.  If you are part of Digital, you should use the service account credential already configured in C2i Jenkins with ID of "SonarSecuirty" (sorry for the mis-spelling).  Otherwise, please contact the security team to request a SonarQube service account and create a new credential in Jenkins with this new account for the Jenkins CI/CD job;
* Service account to upload built artifacts to Veracode to scan security vulnerabilities.  If you are part of Digital, you should use the service account credential already confgiured in C2i Jenkins (ID: VeracodeUser).  Otherwise, you should contact the security team to request a new service account and create a new credential in C2i Jenkins with this new account for the Jenkins CI/CD job; 
* Service & individual user accounts with proper roles to download/upload artifacts from/to Labs Nexus repository (https://artifacts.cotiviti.io) - Please contact the Labs team to obtain these accounts.  Please note: The individual user account is used for local build processes and the service account is used by the Jenkins CI/CD job.  In general, the service account should have no expiration time.  If you are part of Digital, you should use the service account credential already configured in Jenkins (ID: nexus_labs).  If you are not, you should have a Jenkins administrator add credentials for your service account to Jenkins, since these credentials should NEVER be stored in configuration files in github. You will still need a user account to access Nexus to download artifacts for your local build.
* User & service accounts to access norgenhdpdev04.ccaintranet.com (or any new development, QA, or staging servers if they are ready).  These accounts must have privileges to scp files to the tomcat webapp folder and restart the tomcat service.  You must have this account to access the server;

## Preparation

Before creating a new Jenkins CI/CD process, do these steps for a better development experience:

* Create an SSH key so a developer can use it to setup accesses to different repositories and servers without the need of a user password.  Please refer to  <https://www.digitalocean.com/community/tutorials/how-to-configure-ssh-key-based-authentication-on-a-linux-server> to generate the SSH key;
* To access github with the SSH key without using a user password, please follow the instructions in <https://help.github.com/articles/adding-a-new-ssh-key-to-your-github-account/> to configure it using the public key generated in the above bullet point.  To set up a service account to access github with the account SSH key, a github administrator must be involved;
* To configure a user's (or service account's) access to the norgenhdpdev04.ccaintranet.com development server with an SSH key, refer to the section of "How To Copy a Public Key to your Server" in <https://www.digitalocean.com/community/tutorials/how-to-configure-ssh-key-based-authentication-on-a-linux-server>;
* To set up a developer's workstation to download artifacts from Labs' Nexus with the developer's credentials, download the maven settings file from <https://github.com/cotiviti/PlatformServices/blob/develop/c2i-framework-mvn-settings.xml> and replace the "add-nexus-userid-here" with the user's username and "add-nexus-password-here" with user's password.  There are two pairs of these that must be replaced in the file.  After the modifications, copy the file into maven's ".m2" folder with the name "settings.xml".  In Linux systems, the ".m2" folder should be under the user's home directory.  In Windows systems, the ".m2" folder should be in the C:\Users\<user.name>\ directory.

## Jenkins Configuration

The last task is to create the Jenkins process in the C2i Jenkins instance <https://c2i-jenkins.cotiviti.com/>.  Please refer to ["Creating_c2i_Web_Framework_Jenkins_Pipeline"](Creating_c2i_Web_Framework_Jenkins_Pipeline.md) for an example of creating a Jenkins CI/CD pipeline.
