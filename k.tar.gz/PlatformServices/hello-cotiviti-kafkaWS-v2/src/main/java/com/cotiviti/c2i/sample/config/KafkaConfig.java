/**
 * Copyright (C) 2018 Cotiviti Digital (nexgen.admin@cotiviti.io)
 *
 * The software code contained herein is the property of Cotiviti Corporation
 * and its subsidiaries and affiliates (collectively, “Cotiviti”).
 * Access to this software code is being provided to you in the course of your
 * employment or affiliation with Cotiviti and may be used solely in the scope
 * and course of your work for Cotiviti, and is for internal Cotiviti use only.
 * Any unauthorized use, disclosure, copying, distribution, destruction of this
 * software code, or the taking of any unauthorized action in reliance on this
 * software code, is strictly prohibited.
 * If this information is viewed in error, immediately discontinue use of the
 * application.  Anyone using this software code and the applications will be
 * subject to monitoring for improper use, system maintenance and security
 * purposes, and is advised that if such monitoring reveals possible criminal
 * activity or policy violation, Cotiviti personnel may provide the evidence of
 * such monitoring to law enforcement or other officials, and the user may be
 * subject to disciplinary action by Cotiviti, up to and including termination
 * of employment.
 *
 * Use of this software code and any applications and information therein
 * constitutes acknowledgement of and consent to this notice
 */
package com.cotiviti.c2i.sample.config;

import java.util.Map;

import org.apache.kafka.clients.consumer.Consumer;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.kafka.core.DefaultKafkaProducerFactory;
import org.springframework.kafka.core.KafkaTemplate;

import com.cotiviti.c2i.common.property.C2iConfigProperties;
import com.cotiviti.c2i.common.queuing.kafka.C2iKafkaConsumer;
import com.cotiviti.c2i.sample.model.AvroClient;

@Configuration
public class KafkaConfig {
	@Bean
	@ConfigurationProperties(prefix="producer")
	public C2iConfigProperties producerProperties() {
		
		C2iConfigProperties prop = new C2iConfigProperties();		
		return prop;
	}
	
	@Bean
    public KafkaTemplate<String, AvroClient> kafkaTemplate() {
		Map<String, Object> props = producerProperties().getFormattedProperties();
        KafkaTemplate<String, AvroClient> kafkaTemplate = new KafkaTemplate<>(new DefaultKafkaProducerFactory<>(props));
        kafkaTemplate.setDefaultTopic((String)props.get("topicName"));
        return kafkaTemplate;
    }
	
	@Bean
	@ConfigurationProperties(prefix="consumer")
	public C2iConfigProperties consumerProperties() {
		
		C2iConfigProperties prop = new C2iConfigProperties();		
		return prop;
	}
	
	@Bean
	public Consumer<String, AvroClient> consumer() {
		
		C2iKafkaConsumer<String, AvroClient> c2iKafkaConsumer 
			= new C2iKafkaConsumer<String, AvroClient>(consumerProperties().getFormattedProperties());
		Consumer<String, AvroClient> clientConsumer = c2iKafkaConsumer.createConsumer();
		return clientConsumer;
	}
}
