/*******************************************************************************
 * Copyright (C) 2018 Cotiviti Digital (nexgen.admin@cotiviti.io)
 * 
 * The software code contained herein is the property of Cotiviti Corporation
 * and its subsidiaries and affiliates (collectively, “Cotiviti”).
 * Access to this software code is being provided to you in the course of your
 * employment or affiliation with Cotiviti and may be used solely in the scope
 * and course of your work for Cotiviti, and is for internal Cotiviti use only.
 * Any unauthorized use, disclosure, copying, distribution, destruction of this
 * software code, or the taking of any unauthorized action in reliance on this
 * software code, is strictly prohibited.
 * If this information is viewed in error, immediately discontinue use of the
 * application.  Anyone using this software code and the applications will be
 * subject to monitoring for improper use, system maintenance and security
 * purposes, and is advised that if such monitoring reveals possible criminal
 * activity or policy violation, Cotiviti personnel may provide the evidence of
 * such monitoring to law enforcement or other officials, and the user may be
 * subject to disciplinary action by Cotiviti, up to and including termination
 * of employment.
 * 
 * Use of this software code and any applications and information therein
 * constitutes acknowledgement of and consent to this notice
 ******************************************************************************/
package com.cotiviti.c2i.kafkaconnectintegrationtests;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotSame;
import static org.junit.Assert.assertNull;

import java.util.*;
import java.util.concurrent.ExecutionException;

import javax.transaction.Transactional;

import org.json.JSONException;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.context.SpringBootTest.WebEnvironment;
import org.springframework.boot.test.web.client.TestRestTemplate;
import org.springframework.boot.web.server.LocalServerPort;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.test.context.junit4.SpringRunner;

import com.cotiviti.c2i.kafkaconnectintegrationtests.config.DatabaseContextHolder;
import com.cotiviti.c2i.kafkaconnectintegrationtests.config.DatabaseEnvironment;

import com.cotiviti.c2i.kafkaconnectintegrationtests.model.C2iJsonClient;
import com.cotiviti.c2i.kafkaconnectintegrationtests.model.SourceModel;
import com.cotiviti.c2i.kafkaconnectintegrationtests.repository.SourceRepo;
import com.cotiviti.c2i.kafkaconnectintegrationtests.service.C2iKafkaService;


@RunWith(SpringRunner.class)
@SpringBootTest(webEnvironment=WebEnvironment.RANDOM_PORT)
public class KafkaConnectOracleTests {

	@LocalServerPort
	private int port;

	
	
	private static Logger log = LoggerFactory.getLogger(KafkaConnectOracleTests.class);
	
	@Autowired
	private C2iKafkaService ks;
	
	@Autowired
	private SourceRepo sourceRepository;
	
		
	/**
	 * Test if oracle is up and running
	 */
	@Test
	public void oracleDBTest()
	{
		DatabaseContextHolder.set(DatabaseEnvironment.ORACLE);
		SourceModel sample = new SourceModel(1, "OracleTest");
		sourceRepository.save(sample);
		
		List<SourceModel> Records = sourceRepository.findByName("OracleTest");
		assertEquals(Records.isEmpty(),false);
		assertEquals(Records.get(Records.size()-1).getName(),"OracleTest");
	}
	@Test
	public void oracleSourceTest() throws InterruptedException
	{
		//Write to oracle
		DatabaseContextHolder.set(DatabaseEnvironment.ORACLE);
		SourceModel sample = new SourceModel(2, "SourceTest");
		sourceRepository.save(sample);
	
		Thread.sleep(11000);
		
		//Read from kafka
		List<String> Records = ks.consume();
		String name =  Records.get(Records.size()-1).toString();
		assertEquals(name,"Struct{ID=2,NAME=SourceTest}" );
		}
	
	

}


